( function( $ ){
	$( document ).ready( function() {
		/******************* Add Code Below *******************/
	});
})( jQuery );