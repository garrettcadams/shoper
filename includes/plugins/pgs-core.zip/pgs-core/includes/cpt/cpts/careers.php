<?php
/* Job Listing Post Type will work after set theme supports in theme */
if(current_theme_supports('pgs_job_listing')){
	/*
	 * Register Post Type for Career
	 */
	add_action( 'init', 'pgscore_cpt_career');
	function pgscore_cpt_career() {
		if ( post_type_exists( "job_listing" ) )
			return;
		
		/************************************************************************
		 * 
		 * Post types
		 * 
		 ************************************************************************/
		$cpt_name_singular  = esc_html__( 'Job', 'pgs-core' );
		$cpt_name_plural    = esc_html__( 'Jobs', 'pgs-core' );
		
		$cpt_job_listing_args = array(
			'labels' => array(
				'name' 					=> $cpt_name_plural,
				'singular_name' 		=> $cpt_name_singular,
				'menu_name'             => esc_html__( 'Job Listings', 'pgs-core' ),
				'all_items'             => sprintf( esc_html__( 'All %s', 'pgs-core' ), $cpt_name_plural ),
				'add_new' 				=> esc_html__( 'Add New', 'pgs-core' ),
				'add_new_item' 			=> sprintf( esc_html__( 'Add %s', 'pgs-core' ), $cpt_name_singular ),
				'edit' 					=> esc_html__( 'Edit', 'pgs-core' ),
				'edit_item' 			=> sprintf( esc_html__( 'Edit %s', 'pgs-core' ), $cpt_name_singular ),
				'new_item' 				=> sprintf( esc_html__( 'New %s', 'pgs-core' ), $cpt_name_singular ),
				'view' 					=> sprintf( esc_html__( 'View %s', 'pgs-core' ), $cpt_name_singular ),
				'view_item' 			=> sprintf( esc_html__( 'View %s', 'pgs-core' ), $cpt_name_singular ),
				'search_items' 			=> sprintf( esc_html__( 'Search %s', 'pgs-core' ), $cpt_name_plural ),
				'not_found' 			=> sprintf( esc_html__( 'No %s found', 'pgs-core' ), $cpt_name_plural ),
				'not_found_in_trash' 	=> sprintf( esc_html__( 'No %s found in trash', 'pgs-core' ), $cpt_name_plural ),
				'parent' 				=> sprintf( esc_html__( 'Parent %s', 'pgs-core' ), $cpt_name_singular ),
				'featured_image'        => esc_html__( 'Company Logo', 'pgs-core' ),
				'set_featured_image'    => esc_html__( 'Set company logo', 'pgs-core' ),
				'remove_featured_image' => esc_html__( 'Remove company logo', 'pgs-core' ),
				'use_featured_image'    => esc_html__( 'Use as company logo', 'pgs-core' ),
			),
			'description'           => sprintf( esc_html__( 'This is where you can create and manage %s.', 'pgs-core' ), $cpt_name_plural ),
			'public' 				=> true,
			'show_ui' 				=> true,
			'map_meta_cap'          => true,
			'publicly_queryable' 	=> false,
			'exclude_from_search' 	=> false,
			'hierarchical' 			=> false,
			'rewrite' 				=> array(
				'slug'       => 'job',
				'with_front' => false,
				'feeds'      => true,
				'pages'      => false
			),
			'query_var' 			=> true,
			'supports' 				=> array( 'title', 'editor' ),
			'has_archive' 			=> false,
			'show_in_nav_menus' 	=> false
		);
		
		$cpt_job_listing_args = apply_filters( 'pgscore_register_cpt_job_listing',  $cpt_job_listing_args );
		register_post_type( "job_listing", $cpt_job_listing_args );
		
		/************************************************************************
		 * 
		 * Taxonomies
		 * 
		 ************************************************************************/
		// Job category
		$tax_name_category_singular  = esc_html__( 'Job category', 'pgs-core' );
		$tax_name_category_plural    = esc_html__( 'Job categories', 'pgs-core' );
		
		$job_listing_category_args = array(
			'hierarchical' 			=> true,
			'update_count_callback' => '_update_post_term_count',
			'label' 				=> $tax_name_category_plural,
			'labels' => array(
				'name'              => $tax_name_category_plural,
				'singular_name'     => $tax_name_category_singular,
				'menu_name'         => ucwords( $tax_name_category_plural ),
				'search_items'      => sprintf( esc_html__( 'Search %s', 'pgs-core' ), $tax_name_category_plural ),
				'all_items'         => sprintf( esc_html__( 'All %s', 'pgs-core' ), $tax_name_category_plural ),
				'parent_item'       => sprintf( esc_html__( 'Parent %s', 'pgs-core' ), $tax_name_category_singular ),
				'parent_item_colon' => sprintf( esc_html__( 'Parent %s:', 'pgs-core' ), $tax_name_category_singular ),
				'edit_item'         => sprintf( esc_html__( 'Edit %s', 'pgs-core' ), $tax_name_category_singular ),
				'update_item'       => sprintf( esc_html__( 'Update %s', 'pgs-core' ), $tax_name_category_singular ),
				'add_new_item'      => sprintf( esc_html__( 'Add New %s', 'pgs-core' ), $tax_name_category_singular ),
				'new_item_name'     => sprintf( esc_html__( 'New %s Name', 'pgs-core' ),  $tax_name_category_singular )
			),
			'show_ui' 				=> true,
			'show_tagcloud'			=> false,
			'show_admin_column'     => true,
			'public' 	     		=> false,
			'rewrite' 				=> array(
				'slug'         => 'job-category',
				'with_front'   => false,
				'hierarchical' => false
			),
		);
		
		$job_listing_category_args = apply_filters( 'pgscore_register_taxonomy_job_listing_category', $job_listing_category_args, 'job_listing' );
		register_taxonomy( "job_listing_category", 'job_listing', $job_listing_category_args );
		
		// Job type
		$tax_name_type_singular  = esc_html__( 'Job type', 'pgs-core' );
		$tax_name_type_plural    = esc_html__( 'Job types', 'pgs-core' );

		$job_listing_type_args = array(
			'hierarchical' 			=> true,
			'label' 				=> $tax_name_type_plural,
			'labels' => array(
				'name' 				=> $tax_name_type_plural,
				'singular_name' 	=> $tax_name_type_singular,
				'menu_name'         => ucwords( $tax_name_type_plural ),
				'search_items' 		=> sprintf( esc_html__( 'Search %s', 'pgs-core' ), $tax_name_type_plural ),
				'all_items' 		=> sprintf( esc_html__( 'All %s', 'pgs-core' ), $tax_name_type_plural ),
				'parent_item' 		=> sprintf( esc_html__( 'Parent %s', 'pgs-core' ), $tax_name_type_singular ),
				'parent_item_colon' => sprintf( esc_html__( 'Parent %s:', 'pgs-core' ), $tax_name_type_singular ),
				'edit_item' 		=> sprintf( esc_html__( 'Edit %s', 'pgs-core' ), $tax_name_type_singular ),
				'update_item' 		=> sprintf( esc_html__( 'Update %s', 'pgs-core' ), $tax_name_type_singular ),
				'add_new_item' 		=> sprintf( esc_html__( 'Add New %s', 'pgs-core' ), $tax_name_type_singular ),
				'new_item_name' 	=> sprintf( esc_html__( 'New %s Name', 'pgs-core' ),  $tax_name_type_singular )
			),
			'show_ui' 				=> true,
			'show_tagcloud'			=> false,
			'show_admin_column'     => true,
			'public' 			    => false,
			'rewrite' 				=> array(
				'slug'         => 'job-type',
				'with_front'   => false,
				'hierarchical' => false
			),
		);
		
		$job_listing_type_args = apply_filters( 'pgscore_register_taxonomy_job_listing_type', $job_listing_type_args, 'job_listing' );
		register_taxonomy( "job_listing_type", 'job_listing', $job_listing_type_args );
		
		// Add Job Type Terms
		pgscore_career_default_job_listing_types();
	}
	function pgscore_career_default_job_listing_types() {
		if ( get_option( 'pgscore_job_manager_tax_job_listing_type_installed_terms' ) == 1 ) {
			return;
		}

		$taxonomies = array(
			'job_listing_type' => array(
				'Full Time',
				'Part Time',
				'Temporary',
				'Freelance',
				'Internship'
			)
		);

		foreach ( $taxonomies as $taxonomy => $terms ) {
			foreach ( $terms as $term ) {
				if ( ! get_term_by( 'slug', sanitize_title( $term ), $taxonomy ) ) {
					wp_insert_term( $term, $taxonomy );
				}
			}
		}

		update_option( 'pgscore_job_manager_tax_job_listing_type_installed_terms', 1 );
	}

	function pgscore_cpt_remove_careers_metaboxes(){
		remove_meta_box( 'job_listing_categorydiv', 'job_listing', 'side' );
		remove_meta_box( 'job_listing_typediv', 'job_listing', 'side' );
	}
	add_action( 'do_meta_boxes', 'pgscore_cpt_remove_careers_metaboxes' );
}