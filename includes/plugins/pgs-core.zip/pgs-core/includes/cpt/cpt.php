<?php
add_action( 'init', 'pgscore_cpt_loader', 2 );
function pgscore_cpt_loader(){
	add_image_size( 'pgscore-50x50', 50, 50 );
	
	include trailingslashit(PGSCORE_PATH) . 'includes/cpt/cpts/careers.php';
	include trailingslashit(PGSCORE_PATH) . 'includes/cpt/cpts/faqs.php';
	include trailingslashit(PGSCORE_PATH) . 'includes/cpt/cpts/portfolio.php';
	include trailingslashit(PGSCORE_PATH) . 'includes/cpt/cpts/teams.php';
	include trailingslashit(PGSCORE_PATH) . 'includes/cpt/cpts/testimonials.php';
}