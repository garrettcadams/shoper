<?php
function pgscore_banner_images($image_path = true){
	$pgscore_banners_path = trailingslashit(PGSCORE_PATH) . 'images/bg/';
	$pgscore_banners_url  = trailingslashit(PGSCORE_URL) . 'images/bg/';
	
	$pgscore_banners_new = array();
	
	if ( is_dir( $pgscore_banners_path ) ) {
		$pgscore_banners_data = pgscore_get_file_list( 'jpg,png', $pgscore_banners_path );
		
		if( !empty($pgscore_banners_data) ){
			foreach( $pgscore_banners_data as $pgscore_banner_path ) {
				if( $image_path ){
					$pgscore_banners_new[$pgscore_banners_url.basename($pgscore_banner_path)] = array(
						'alt'   => basename($pgscore_banner_path),
						'img'   => $pgscore_banners_url.basename($pgscore_banner_path),
						'height'=> 25,
						'width' => 100,
					);
				}else{
					$pgscore_banners_new[] = array(
						'alt'   => basename($pgscore_banner_path),
						'img'   => $pgscore_banners_url.basename($pgscore_banner_path),
						'height'=> 25,
						'width' => 100,
					);
				}
			}
		}
	}
	if( !$image_path ){
		array_unshift($pgscore_banners_new, null);
		unset($pgscore_banners_new[0]);
	}
	return $pgscore_banners_new;
}
function pgscore_banner_images_default(){
	$imgs = pgscore_banner_images();
	foreach($imgs as $img => $img_data){
		return $img;
	}
}

function pgscore_is_plugin_installed($search){
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$plugins = get_plugins();
	$plugins = array_filter( array_keys($plugins), function($k){
		if( strpos( $k, '/' ) !== false ) return true;
	});
	$plugins_stat = function($plugins, $search){
		$new_plugins = array();
		foreach($plugins as $plugin){
			$new_plugins_data = explode( '/', $plugin );
			$new_plugins[] = $new_plugins_data[0];
		}
		return in_array($search,$new_plugins);
	};
	return $plugins_stat($plugins, $search);
}

function pgscore_is_plugin_active($plugin){
	if( empty($plugin) ){
		return false;
	}
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	return is_plugin_active($plugin);
}

// Filter out hard-coded width, height attributes on all captions (wp-caption class)
add_shortcode( 'wp_caption', 'pgscore_fixed_img_caption_shortcode' );
add_shortcode( 'caption', 'pgscore_fixed_img_caption_shortcode' );
function pgscore_fixed_img_caption_shortcode($attr, $content = null) {
	if ( ! isset( $attr['caption'] ) ) {
		if ( preg_match( '#((?:<a [^>]+>\s*)?<img [^>]+>(?:\s*</a>)?)(.*)#is', $content, $matches ) ) {
			$content = $matches[1];
			$attr['caption'] = trim( $matches[2] );
		}
	}
	$output = apply_filters( 'img_caption_shortcode', '', $attr, $content);
	if ( $output != '' ) return $output;
	extract(shortcode_atts(array(
		'id' => '',
		'align' => 'alignnone',
		'width' => '',
		'caption' => ''
	), $attr));
	if ( 1 > (int) $width || empty($caption) ) return $content;
	if ( $id ) $id = 'id="' . esc_attr($id) . '" ';
	return '<div ' . $id . 'class="wp-caption ' . esc_attr($align) . '" >'
	. do_shortcode( $content ) . '<p class="wp-caption-text">' . $caption . '</p></div>';
}

/**
 * Filter out hard-coded width, height attributes on all captions (wp-caption class)
 *
 * @since PGS Core 1.0
 */
function pgscore_fix_img_caption_shortcode( $attr, $content = null ) {
	if ( ! isset( $attr['caption'] ) ) {
		if ( preg_match( '#((?:<a [^>]+>\s*)?<img [^>]+>(?:\s*</a>)?)(.*)#is', $content, $matches ) ) {
			$content = $matches[1];
			$attr['caption'] = trim( $matches[2] );
		}
	}
	$output = apply_filters( 'img_caption_shortcode', '', $attr, $content );
	if ( $output != '' ) return $output;
	extract( shortcode_atts( array(
		'id' => '',
		'align' => 'alignnone',
		'width' => '',
		'caption' => ''
	), $attr ) );
	if ( 1 > (int) $width || empty( $caption ) ) return $content;
	if ( $id ) $id = 'id="' . esc_attr( $id ) . '" ';
	return '<figure ' . $id . 'class="wp-caption ' . esc_attr($align) . '" >' . do_shortcode( $content ) . '<figcaption class="wp-caption-text">' . $caption . '</figcaption></figure>';
}
add_shortcode( 'wp_caption', 'pgscore_fix_img_caption_shortcode' );
add_shortcode( 'caption', 'pgscore_fix_img_caption_shortcode' );

function pgscore_get_excerpt_max_charlength($charlength, $excerpt = null) {
	if( empty($excerpt) ){
		$excerpt = get_the_excerpt();
	}
	$charlength++;
	
	if ( mb_strlen( $excerpt ) > $charlength ) {
		$subex = mb_substr( $excerpt, 0, $charlength - 5 );
		$exwords = explode( ' ', $subex );
		$excut = - ( mb_strlen( $exwords[ count( $exwords ) - 1 ] ) );
		
		$new_excerpt = '';
		if ( $excut < 0 ) {
			$new_excerpt = mb_substr( $subex, 0, $excut );
		} else {
			$new_excerpt = $subex;
		}
		$new_excerpt .= '[...]';
		return $new_excerpt;
	} else {
		return $excerpt;
	}
}
function pgscore_the_excerpt_max_charlength($charlength, $excerpt = null) {
	$new_excerpt = pgscore_get_excerpt_max_charlength($charlength, $excerpt);
	echo $new_excerpt;
}

/**
 * Truncate String with or without ellipsis.
 *
 * @param string $string      String to truncate
 * @param int    $maxLength   Maximum length of string
 * @param bool   $addEllipsis if True, "..." is added in the end of the string, default true
 * @param bool   $wordsafe    if True, Words will not be cut in the middle
 *
 * @return string Shotened Text
 */
function pgscore_shortenString($string = '', $maxLength, $addEllipsis = true, $wordsafe = false){
	if( empty($string) ){
		$string;
	}
	$ellipsis = '';
	$maxLength = max($maxLength, 0);
	if (mb_strlen($string) <= $maxLength) {
		return $string;
	}
	if ($addEllipsis) {
		$ellipsis = mb_substr( '...', 0, $maxLength);
		$maxLength -= mb_strlen($ellipsis);
		$maxLength = max($maxLength, 0);
	}
	if ($wordsafe) {
		$string = preg_replace( '/\s+?(\S+)?$/', '', mb_substr($string, 0, $maxLength));
	} else {
		$string = mb_substr($string, 0, $maxLength);
	}
	if ($addEllipsis) {
		$string .= $ellipsis;
	}

	return $string;
}

function pgscore_array_sort_by_column(&$array, $column, $direction = SORT_ASC) {
    $reference_array = array();	
    foreach($array as $key => $row) {
		if(isset($row[$column])){
			$reference_array[$key] = $row[$column];
		}
    }	
	if(sizeof($reference_array) == sizeof($array) ){
		array_multisort($reference_array, $array, $direction);
	}
}

function pgscore_get_file_list( $extensions = '', $path = '' ){
	
	$pgscore_files = false;

	// Return if any paramater is blank
	if( empty($extensions) || empty($path) ){
		return $pgscore_files;
	}
	
	// Prepare Transient Key
	$extensions_trans = ( is_array($extensions) ) ? implode('-', $extensions) : $extensions;
	$pgscore_get_file_list_transient_key = 'pgscore_files_'.md5(sanitize_text_field($extensions_trans.'_'.$path));
	
	// Check if debug mode is not enabled or transient found
	if ( WP_DEBUG || false === ( $pgscore_files = get_transient( $pgscore_get_file_list_transient_key ) ) ) {
		
		// Convert to array if string is provided
		if( !is_array($extensions) ){
			$extensions = array_filter( explode(',', $extensions) );
		}
		
		// Fix trailing slash if not provided.
		$path = rtrim( $path, '/\\' ) . '/';
		
		if ( defined( 'GLOB_BRACE' ) ){
			if( count($extensions) == 1 && $extensions[0] == '*' ){
				$files_with_glob = glob( $path."*", GLOB_BRACE );
			}else{
				$extensions_with_glob_brace = "{". implode(',',$extensions)."}"; // file extensions pattern
				$files_with_glob = glob( $path."*.$extensions_with_glob_brace", GLOB_BRACE );
			}
			
			$pgscore_files = $files_with_glob;
		}else{
			if( count($extensions) == 1 && $extensions[0] == '*' ){
				$files_without_glob = glob( $path."*" );
			}else{
				$extensions_without_glob = implode('|',$extensions); // file extensions pattern
				
				$files_without_glob_all = glob( $path.'*.*' ); // Get all files
				
				$files_without_glob = array_values( preg_grep("~\.($extensions_without_glob)$~", $files_without_glob_all) ); // Filter files with pattern
			}
			$pgscore_files = $files_without_glob;
		}
		
		// Set transient
		set_transient( $pgscore_get_file_list_transient_key, $pgscore_files, 12 * HOUR_IN_SECONDS );
	}
	
	return $pgscore_files;
}

/**
 * Get shortcode template parts.
 */
function pgscore_get_shortcode_templates( $slug, $name = '' ) {
	$template = '';
	
	$template_path = 'template-parts/shortcodes/';
	$plugin_path = trailingslashit( PGSCORE_PATH );

	// Look in yourtheme/template-parts/shortcodes/slug-name.php
	if ( $name ) {
		$template = locate_template( array(
			$template_path . "{$slug}-{$name}.php",
		) );
	}
	
	// Get default slug-name.php
	if ( ! $template && $name && file_exists( $plugin_path . "templates/{$slug}-{$name}.php" ) ) {
		$template = $plugin_path . "templates/{$slug}-{$name}.php";
	}
	
	// If template file doesn't exist, look in yourtheme/template-parts/shortcodes/slug.php
	if ( ! $template ) {
		$template = locate_template( array(
			$template_path . "{$slug}.php"
		) );
	}
	
	// Get default slug.php
	if ( ! $template && file_exists( $plugin_path . "templates/{$slug}.php" ) ) {
		$template = $plugin_path . "templates/{$slug}.php";
	}
	
	// Allow 3rd party plugins to filter template file from their plugin.
	$template = apply_filters( 'pgscore_get_shortcode_templates', $template, $slug, $name );
	
	if ( $template ) {
		load_template( $template, false );
	}
}

function pgscore_class_builder( $class = '' ){
	$classes = array();
	
	if ( $class ) {
		if ( ! is_array( $class ) ) {
			$class = preg_split( '#\s+#', $class );
		}
		$classes = array_map( 'esc_attr', $class );
	} else {
		// Ensure that we always coerce class to being an array.
		$class = array();
	}
	$classes = array_map( 'esc_attr', $classes );
	
	return implode( ' ', array_filter( array_unique( $classes ) ) );
}

function pgscore_shortcode_id( $atts ){
	extract( $atts );
	
	if( !empty($element_id) ){
		$element_id = (preg_match('/^\d/', $element_id) === 1) ? $shortcode_handle.'_'.$element_id : $element_id;
	}
	
	// bail, if no valid id found.
	if( !isset($element_id) || $element_id == '' ) return;
	
	echo 'id="'.esc_attr( $element_id ).'"';
}