<?php
// Enable shortcodes in widgets
add_filter('widget_text', 'do_shortcode');

/*
 * Shortcodes Loader New
 */
function pgscore_shortcodes_loader(){
	
	// Return if vc is not active
	if ( !class_exists( 'WPBakeryVisualComposerAbstract' ) ) return false;
	
	// Return if no shortcode support
	if( !current_theme_supports('pgscore_shortcodes') ) return false;
	
	// Get supported shortcodes list
	$enabled_shortcodes = get_theme_support('pgscore_shortcodes');
	$enabled_shortcodes = $enabled_shortcodes[0];
	
	if( is_array($enabled_shortcodes) && !empty($enabled_shortcodes)  ){
		
		foreach( $enabled_shortcodes as $shortcode_tag ) {
			
			$shortcode_name = str_replace('pgscore_', '', $shortcode_tag); // Shortcode tag without 'pgscore_' prefix
			$shortcode_path_plugin = trailingslashit(PGSCORE_PATH) . 'includes/shortcodes/'.$shortcode_name.'.php';
			
			$shortcode_path = locate_template( array(
				"includes/shortcodes/fields/"."{$shortcode_name}.php",
			) );
			
			if ( !$shortcode_path && file_exists( $shortcode_path_plugin ) ) {
				$shortcode_path = $shortcode_path_plugin;
			}
			
			if( file_exists($shortcode_path) ){
			
				// Add must required fields
				add_filter( 'pgscore_shortcode_fields-'.$shortcode_tag, 'pgscore_shortcode_must_require_fields', 20, 2 );
				
				include_once($shortcode_path);

				add_shortcode( $shortcode_tag, 'pgscore_shortcode_'.$shortcode_name );
				
				// Add must required atts
				add_filter( "pgscore_shortcode_atts-{$shortcode_tag}", 'pgscore_shortcode_must_require_atts', 20, 2 );
				
				add_filter( "shortcode_atts_{$shortcode_tag}", 'pgscore_shortcode_atts_shortcode_handle', 10, 4 );
				
			}
		}
	}
}
add_action( 'init', 'pgscore_shortcodes_loader', 12 );

// Add shortcode handle to attributes
function pgscore_shortcode_atts_shortcode_handle( $out, $pairs, $atts, $shortcode ){
	
	$out['shortcode_handle'] = $shortcode;
	
	return $out;
}

// Add must required atts
function pgscore_shortcode_must_require_atts( $atts, $shortcode_handle ){
	
	// Must Required
	$atts['element_css']   = '';
	$atts['element_id']    = '';
	$atts['element_class'] = '';
	
	return $atts;
}

function pgscore_shortcode_must_require_fields( $shortcode_fields, $shortcode_tag ){
	
	$el_id_desc = sprintf( wp_kses( __( 'Enter ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>)', 'pgs-core' ), array(
			'a' => array(
				'href' => true,
				'target' => true,
			),
		) ),
		'http://www.w3schools.com/tags/att_global_id.asp'
	)
	.'<br><span class="pgs-core-red">'.
	sprintf( wp_kses( __( 'Important : If ID starts with number, it will be prefixed with "%s".', 'pgs-core' ), array(
			'atrong' => true,
		) ),
		'<strong>'.$shortcode_tag.'_'.'</strong>'
	)
	.'</span>';

	// Merge all fields groups
	$shortcode_fields = array_merge(
		$shortcode_fields,
		array(
			array(
				'type'      => 'css_editor',
				'heading'   => esc_html__( 'CSS box', 'pgs-core' ),
				'param_name'=> 'element_css',
				'group'     => esc_html__( 'Design Options', 'pgs-core' ),
			),
			array(
				'type'       => 'el_id',
				'heading'    => esc_html__( 'ID', 'pgs-core' ),
				'param_name' => 'element_id',
				'description'=> $el_id_desc,
				'settings'   => array(
					// 'auto_generate'=> true,
				),
				'group'      => esc_html__('ID/Class', 'pgs-core'),
			),
			array(
				"type"        => "textfield",
				"heading"     => esc_html__("Extra class name", 'pgs-core'),
				"param_name"  => "element_class",
				"description" => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'pgs-core'),
				'group'       => esc_html__('ID/Class', 'pgs-core'),
			),
		)
	);

	return $shortcode_fields;
}

if ( ! function_exists( 'pgscore_get_year' ) ){
	function pgscore_get_year( $atts ) {
		
		$atts = shortcode_atts( array(
			'year'   => date("Y"),
		), $atts );
		
		extract( $atts );
		
		return $year;
	}
}
add_shortcode('pgscore-year', 'pgscore_get_year');

if ( ! function_exists( 'pgscore_get_site_title' ) ){
	function pgscore_get_site_title( $atts ) {
		
		// default parameters
		
		$atts = shortcode_atts( array(
			'site'   	=> get_bloginfo(),
			'site_url' 	=> get_site_url(),
		), $atts );
		
		extract( $atts );
		
		if( !empty($site) && !empty($site_url) ){
			$site_name = sprintf( wp_kses( '<a href="%1$s" target="_blank">%2$s</a>', array(
						'a' => array(
							'href'  => true,
							'target'=> true,
						),
					)
				),
				$site_url,
				$site
			);
		}
		return $site_name;
	}
}
add_shortcode('pgscore-site-title', 'pgscore_get_site_title');

if ( ! function_exists( 'pgscore_get_footer_menu' ) ){
	function pgscore_get_footer_menu( $atts ) {
		
		$atts = shortcode_atts( array(
			'class' => 'list-inline text-right',
		), $atts );
		
		extract($atts);
	
		if( has_nav_menu('footer_menu') ) {
			wp_nav_menu( apply_filters( 'pgscore_footer_menu_shortcode', array(
				'theme_location'=> 'footer_menu',
				'menu_class'    => $class,
				'menu_id'       => 'footer-menu',
				'depth'         => 1,
			) ) );
		}
	}
}
add_shortcode('pgscore-footer-menu', 'pgscore_get_footer_menu');

// Shortcode for Promopoup close
if ( ! function_exists( 'pgscore_popup_close' ) ){
	function pgscore_popup_close( $atts ) {
		
		// default parameters
		$atts = shortcode_atts( array(
			'message' => esc_html__("Don't show this popup again",'ciya-shop')
		), $atts );
		
		extract( $atts );
		$popup_close='';
		if( !empty($message) ){
			$popup_close = '<label for="hide_promo_popup"><input type="checkbox" name="hide_promo_popup" id="hide_promo_popup" />&nbsp;'.$message.'</label>';
		}
		
		return $popup_close;
	}
}
add_shortcode('pgscore-popup-close', 'pgscore_popup_close');