<?php
require_once trailingslashit(PGSCORE_PATH) . 'includes/globals_datas_vars.php';      // Globals
require_once trailingslashit(PGSCORE_PATH) . 'includes/widgets.php';                 // Widgets
require_once trailingslashit(PGSCORE_PATH) . 'includes/welcome/welcome.php';         // Welcome Panel

add_action( 'init', 'pgscore_file_inclusions', 1 );
function pgscore_file_inclusions(){
	require_once trailingslashit(PGSCORE_PATH) . 'includes/helper_functions.php';        // Helper Functions
	require_once trailingslashit(PGSCORE_PATH) . 'includes/scripts_and_styles.php';      // CSS & Javascript
	require_once trailingslashit(PGSCORE_PATH) . 'includes/cpt/cpt.php';                 // CPTs
	require_once trailingslashit(PGSCORE_PATH) . 'includes/importer/importer.php';       // Importer
	require_once trailingslashit(PGSCORE_PATH) . 'includes/acf/acf-init.php';            // ACF

	require_once trailingslashit(PGSCORE_PATH) . 'includes/redux/redux-init.php';        // Redux

	require_once trailingslashit(PGSCORE_PATH) . 'includes/vc/vc.php';                   // Visual Composer
	require_once trailingslashit(PGSCORE_PATH) . 'includes/shortcode.php';               // Shortcodes
	require_once trailingslashit(PGSCORE_PATH) . 'includes/mailchimp.php';               // mailchimp
	require_once trailingslashit(PGSCORE_PATH) . 'includes/admin-notices.php';           // Admin Notices
	require_once trailingslashit(PGSCORE_PATH) . 'includes/sample_data/sample_data.php'; // Admin Notices
}