<?php
if( !current_theme_supports('pgs_faqs') ) return;

$group_575e871dd92a4_field_data = array (
	'key' => 'group_575e871dd92a4',
	'title' => 'FAQ Page Settings',
	'fields' => array (
		array (
			'key' => 'field_575e871de8167',
			'label' => 'FAQ Layout',
			'name' => 'faq_layout',
			'type' => 'radio',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array (
				'width' => '',
				'class' => 'acf-image-radio',
				'id' => '',
			),
			'choices' => array (
				'multi_category' => 'multi_category',
				'single_category' => 'single_category',
			),
			'allow_null' => 0,
			'other_choice' => 0,
			'save_other_choice' => 0,
			'default_value' => 'multi_category',
			'layout' => 'horizontal',
			'return_format' => 'value',
		),
		array (
			'key' => 'field_57ce560905b98',
			'label' => 'Category Source',
			'name' => 'multi_category_cat_source',
			'type' => 'radio',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => array (
				array (
					array (
						'field' => 'field_575e871de8167',
						'operator' => '==',
						'value' => 'multi_category',
					),
				),
			),
			'wrapper' => array (
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'choices' => array (
				'all' => 'All',
				'selected' => 'Selected',
			),
			'allow_null' => 0,
			'other_choice' => 0,
			'save_other_choice' => 0,
			'default_value' => 'all',
			'layout' => 'horizontal',
			'return_format' => 'value',
		),
		array (
			'key' => 'field_57ce568605b9a',
			'label' => 'Categories',
			'name' => 'multi_category_categories',
			'type' => 'taxonomy',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => array (
				array (
					array (
						'field' => 'field_575e871de8167',
						'operator' => '==',
						'value' => 'multi_category',
					),
					array (
						'field' => 'field_57ce560905b98',
						'operator' => '==',
						'value' => 'selected',
					),
				),
			),
			'wrapper' => array (
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'taxonomy' => 'faq-category',
			'field_type' => 'multi_select',
			'allow_null' => 0,
			'add_term' => 1,
			'save_terms' => 0,
			'load_terms' => 0,
			'return_format' => 'id',
			'multiple' => 0,
		),
		array (
			'key' => 'field_57ce56d005b9c',
			'label' => 'Category',
			'name' => 'single_category_category',
			'type' => 'taxonomy',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => array (
				array (
					array (
						'field' => 'field_575e871de8167',
						'operator' => '==',
						'value' => 'single_category',
					),
				),
			),
			'wrapper' => array (
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'taxonomy' => 'faq-category',
			'field_type' => 'select',
			'allow_null' => 0,
			'add_term' => 1,
			'save_terms' => 0,
			'load_terms' => 0,
			'return_format' => 'id',
			'multiple' => 0,
		),
	),
	'location' => array (
		array (
			array (
				'param' => 'post_type',
				'operator' => '==',
				'value' => 'page',
			),
			array (
				'param' => 'page_template',
				'operator' => '==',
				'value' => 'templates/template-faq.php',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'normal',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'field',
	'hide_on_screen' => '',
	'active' => 1,
	'description' => '',
	'modified' => 1487679066,
);
acf_add_local_field_group( apply_filters( 'faq_page_settings_group_575e871dd92a4', $group_575e871dd92a4_field_data ) );
?>