<?php
if( !current_theme_supports('pgs_sidebar') ) return;

$group_57593c27830d8_field_data = array (
	'key' => 'group_57593c27830d8',
	'title' => 'Sidebar',
	'fields' => array (
		array (
			'key' => 'field_57593c2796f1a',
			'label' => 'Sidebar',
			'name' => 'sidebar',
			'type' => 'radio',
			'instructions' => '',
			'required' => 0,
			'conditional_logic' => 0,
			'wrapper' => array (
				'width' => '',
				'class' => 'acf-image-radio acf_field_name-sidebar acf_field_name-pgs_sidebar acf_field_name-pgs_sidebar acf_field_name-sidebar',
				'id' => '',
			),
			'choices' => array (
			),
			'allow_null' => 0,
			'other_choice' => 0,
			'save_other_choice' => 0,
			'default_value' => '',
			'layout' => 'horizontal',
			'return_format' => 'value',
		),
	),
	'location' => array (
		array (
			array (
				'param' => 'post_type',
				'operator' => '==',
				'value' => 'post',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'normal',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'field',
	'hide_on_screen' => '',
	'active' => 1,
	'description' => '',
	'modified' => 1487676264,
);
acf_add_local_field_group( apply_filters( 'sidebar_group_57593c27830d8', $group_57593c27830d8_field_data ) );
?>