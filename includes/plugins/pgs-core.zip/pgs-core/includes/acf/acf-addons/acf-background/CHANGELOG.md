# Changelog

#### 1.6.0
* Add required check

#### 1.5.0
* Compatible with [Github Updater](https://github.com/afragen/github-updater)
* Add language pot file
* Add changelog file

#### 1.4.0
* Add: RGBA color

#### 1.3.0
* Add: text color

#### 1.2.2
* Bug fix: send background image width as a value

#### 1.2.1
* Bug fix: remove button

#### 1.2.0
* Add: Style for display fields

#### 1.1.1
* Bug fix Live Preview.

#### 1.1.0
* Add default value.
* Bug fix Preview JS.

#### 1.0.0
* Initial Release.