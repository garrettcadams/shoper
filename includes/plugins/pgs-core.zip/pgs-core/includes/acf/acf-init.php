<?php
if(defined( 'ACF_DEV' ) && ACF_DEV){
	// return;
}

require_once trailingslashit(PGSCORE_PATH) . 'includes/acf/acf-addons/acf-background/acf-background.php';
require_once trailingslashit(PGSCORE_PATH) . 'includes/acf/acf-addons/advanced-custom-fields-number-slider/acf-number-slider.php';

function pgscore_acf_fields_loader_new(){
	$acf_fields_path = trailingslashit(PGSCORE_PATH).'includes/acf/fields/';
	
	if ( is_dir( $acf_fields_path ) ) {
		$acf_fields = pgscore_get_file_list( 'php', $acf_fields_path );
		
		$acf_fields = apply_filters( 'pgscore_acf_fieldsets', $acf_fields );
		
		if( is_array($acf_fields) && !empty($acf_fields) ){
			foreach( $acf_fields as $acf_field ) {
				include_once($acf_field);
			}
		}
	}
}

if( !defined( 'ACF_DEV' ) || (defined( 'ACF_DEV' ) && !ACF_DEV) ) {
	
	// 4. Hide ACF field group menu item
	add_filter( 'acf/settings/show_admin', '__return_false' );
}

if( function_exists('acf_add_local_field_group') ){
	add_action( 'init', 'pgscore_acf_fields_loader_new' );
}

add_filter( 'acf/load_field/name=banner_image_bg', 'pgscore_acf_load_field_banner_image_bg' );
function pgscore_acf_load_field_banner_image_bg( $field ) {
	
	// Return field without save image data in database
	$field_post = get_post($field['ID']);
	if( $field_post->post_type == 'acf-field' ){
		return $field;
	}
	
	if( empty($field['wrapper']['class']) ){
		$field['wrapper']['class'] = 'acf_field_name-banner_image_bg';
	}
	
	$banner_images = pgscore_banner_images();
	
	foreach( $banner_images as $banner_image ){
		$field['choices'][$banner_image['img']] = '<img src="'.esc_url($banner_image['img']).'" alt="'.esc_attr($banner_image['alt']).'" height="75" />';
	}
	return $field;
}

/*********************************************************************************
 * 
 * Add custom class based on field name
 * 
*********************************************************************************/
add_filter( 'acf/prepare_field', 'pgscore_acf_add_field_name_class' );
function pgscore_acf_add_field_name_class( $field ) {
	
	// Return field without save image data in database
	$field_post = get_post($field['ID']);
	if( isset($field_post->post_type) &&  $field_post->post_type == 'acf-field' ){
		return $field;
	}

	$name = $field['_name'];
	$acf_class = 'acf_field_name-'.$name;
	
	if( empty($field['wrapper']['class']) ){
		$field['wrapper']['class'] = $acf_class;
	}else{
		$classes = explode( ' ', $field['wrapper']['class']);
		$classes = array_filter( array_unique( $classes ) );
		if( !in_array($acf_class, $classes) ){
			$classes[] = $acf_class;
		}
		$classes = implode( ' ', $classes );
		
		$field['wrapper']['class'] = $classes;
	}
	return $field;
}

/*********************************************************************************
 * 
 * Set images for radio-buttons
 * 
 *********************************************************************************/
add_filter('acf/prepare_field/type=radio', 'pgscore_acf_radio_image');
function pgscore_acf_radio_image( $field ) {
	
	// Return field without save image data in database
	$field_post = get_post($field['ID']);
	if( isset($field_post->post_type) &&  $field_post->post_type == 'acf-field' ){
		return $field;
	}
	
	$name = $field['_name'];
	
	// Populate field with class
	$class = $field['wrapper']['class'];
	$classes = explode( ' ', $class);
	
	if( !in_array( 'acf-image-radio', $classes) ){
		return $field;
	}
	
	$pgscore_banners_path = trailingslashit(PGSCORE_PATH) . 'images/radio-button-imgs/'.$name.'/';
	$pgscore_banners_url  = trailingslashit(PGSCORE_URL) . 'images/radio-button-imgs/'.$name.'/';
	
	$pgscore_banners_new = array();
	if ( is_dir( $pgscore_banners_path ) ) {
		$pgscore_banners_data = pgscore_get_file_list( 'jpg,png', $pgscore_banners_path );
		if( !empty($pgscore_banners_data) ){
			$default_files = pgscore_get_file_list( 'default', $pgscore_banners_path );
			if( !empty($default_files) && is_array($default_files) ){
				$default_file  = pathinfo($default_files[0]);
				$default_file_filename = $default_file['filename'];
				if( !isset($field['value']) || ( isset($field['value']) && empty($field['value']) ) ){
					$field['value'] = $default_file_filename;
				}
			}
			foreach( $pgscore_banners_data as $pgscore_banner_path ) {
				$file_data = pathinfo($pgscore_banner_path);
				$opt_title = $file_data['filename'];
				$opt_title = ucfirst( str_replace( "_", " ", $opt_title ) );
				
				$field['choices'][$file_data['filename']] = '<img src="'.esc_url($pgscore_banners_url.basename($pgscore_banner_path)).'" alt="'.esc_attr($opt_title).'" /><span class="radio_btn_title">'.ucwords($opt_title).'</span>';
			}
		}
	}
    return $field;
}

/*********************************************************************************
 * 
 * Set Font Awesome Icons
 * 
 *********************************************************************************/
add_filter('acf/prepare_field/type=select', 'pgscore_acf_font_awesome');
function pgscore_acf_font_awesome( $field ) {
	
	// Return field without save image data in database
	$field_post = get_post($field['ID']);
	if( isset($field_post->post_type) &&  $field_post->post_type == 'acf-field' ){
		return $field;
	}
	
	$name = $field['_name'];
	
	// Populate field with class
	$class = $field['wrapper']['class'];
	$classes = explode( ' ', $class);
	
	if( !in_array( 'acf_pgs_fontawesome', $classes) ){
		return $field;
	}
	
	$fa_icons = pgscore_fa_icons();
	
	$field['choices'] = array();
	foreach( $fa_icons as $fa_icon_k => $fa_icon_v ) {
		// $opt_title = ucwords( str_replace( "-", " ", str_replace( "fa-", "", $fa_icon_k ) ) );
		
		$field['choices'][$fa_icon_k] = $fa_icon_v;
	}
	
	$field['allow_null'] = 0;
	$field['multiple'] = 0;
	$field['ui'] = 1;
	$field['ajax'] = 0;
	$field['return_format'] = 'array';
	
    return $field;
}

function pgscore_fa_icons(){
	$fa_icons = array(
		'fa-500px'                               => '&#xf26e; 500px',
		'fa-address-book'                        => '&#xf2b9; Address Book',
		'fa-address-book-o'                      => '&#xf2ba; Address Book (Outlined)',
		'fa-address-card'                        => '&#xf2bb; Address Card',
		'fa-address-card-o'                      => '&#xf2bc; Address Card (Outlined)',
		'fa-adjust'                              => '&#xf042; Adjust',
		'fa-adn'                                 => '&#xf170; App.net',
		'fa-align-center'                        => '&#xf037; Align Center',
		'fa-align-justify'                       => '&#xf039; Align Justify',
		'fa-align-left'                          => '&#xf036; Align Left',
		'fa-align-right'                         => '&#xf038; Align Right',
		'fa-amazon'                              => '&#xf270; Amazon',
		'fa-ambulance'                           => '&#xf0f9; Ambulance',
		'fa-american-sign-language-interpreting' => '&#xf2a3; American Sign Language Interpreting',
		'fa-anchor'                              => '&#xf13d; Anchor',
		'fa-android'                             => '&#xf17b; Android',
		'fa-angellist'                           => '&#xf209; AngelList',
		'fa-angle-double-down'                   => '&#xf103; Angle Double Down',
		'fa-angle-double-left'                   => '&#xf100; Angle Double Left',
		'fa-angle-double-right'                  => '&#xf101; Angle Double Right',
		'fa-angle-double-up'                     => '&#xf102; Angle Double Up',
		'fa-angle-down'                          => '&#xf107; Angle Down',
		'fa-angle-left'                          => '&#xf104; Angle Left',
		'fa-angle-right'                         => '&#xf105; Angle Right',
		'fa-angle-up'                            => '&#xf106; Angle Up',
		'fa-apple'                               => '&#xf179; Apple',
		'fa-archive'                             => '&#xf187; Archive',
		'fa-area-chart'                          => '&#xf1fe; Area Chart',
		'fa-arrow-circle-down'                   => '&#xf0ab; Arrow Circle Down',
		'fa-arrow-circle-left'                   => '&#xf0a8; Arrow Circle Left',
		'fa-arrow-circle-o-down'                 => '&#xf01a; Arrow Circle Outlined Down',
		'fa-arrow-circle-o-left'                 => '&#xf190; Arrow Circle Outlined Left',
		'fa-arrow-circle-o-right'                => '&#xf18e; Arrow Circle Outlined Right',
		'fa-arrow-circle-o-up'                   => '&#xf01b; Arrow Circle Outlined Up',
		'fa-arrow-circle-right'                  => '&#xf0a9; Arrow Circle Right',
		'fa-arrow-circle-up'                     => '&#xf0aa; Arrow Circle Up',
		'fa-arrow-down'                          => '&#xf063; Arrow Down',
		'fa-arrow-left'                          => '&#xf060; Arrow Left',
		'fa-arrow-right'                         => '&#xf061; Arrow Right',
		'fa-arrow-up'                            => '&#xf062; Arrow Up',
		'fa-arrows'                              => '&#xf047; Arrows',
		'fa-arrows-alt'                          => '&#xf0b2; Arrows (Alternate)',
		'fa-arrows-h'                            => '&#xf07e; Arrows Horizontal',
		'fa-arrows-v'                            => '&#xf07d; Arrows Vertical',
		'fa-asl-interpreting'                    => '&#xf2a3; Asl Interpreting',
		'fa-assistive-listening-systems'         => '&#xf2a2; Assistive Listening Systems',
		'fa-asterisk'                            => '&#xf069; Asterisk',
		'fa-at'                                  => '&#xf1fa; at',
		'fa-audio-description'                   => '&#xf29e; Audio Description',
		'fa-automobile'                          => '&#xf1b9; Automobile',
		'fa-backward'                            => '&#xf04a; Backward',
		'fa-balance-scale'                       => '&#xf24e; Balance Scale',
		'fa-ban'                                 => '&#xf05e; Ban',
		'fa-bandcamp'                            => '&#xf2d5; Bandcamp',
		'fa-bank'                                => '&#xf19c; Bank',
		'fa-bar-chart'                           => '&#xf080; Bar Chart',
		'fa-bar-chart-o'                         => '&#xf080; Bar Chart (Outlined)',
		'fa-barcode'                             => '&#xf02a; Barcode',
		'fa-bars'                                => '&#xf0c9; Bars',
		'fa-bath'                                => '&#xf2cd; Bath',
		'fa-bathtub'                             => '&#xf2cd; Bathtub',
		'fa-battery'                             => '&#xf240; Battery',
		'fa-battery-0'                           => '&#xf244; Battery 0',
		'fa-battery-1'                           => '&#xf243; Battery 1',
		'fa-battery-2'                           => '&#xf242; Battery 2',
		'fa-battery-3'                           => '&#xf241; Battery 3',
		'fa-battery-4'                           => '&#xf240; Battery 4',
		'fa-battery-empty'                       => '&#xf244; Battery Empty',
		'fa-battery-full'                        => '&#xf240; Battery Full',
		'fa-battery-half'                        => '&#xf242; Battery 1/2 Full',
		'fa-battery-quarter'                     => '&#xf243; Battery 1/4 Full',
		'fa-battery-three-quarters'              => '&#xf241; Battery 3/4 Full',
		'fa-bed'                                 => '&#xf236; Bed',
		'fa-beer'                                => '&#xf0fc; Beer',
		'fa-behance'                             => '&#xf1b4; Behance',
		'fa-behance-square'                      => '&#xf1b5; Behance Square',
		'fa-bell'                                => '&#xf0f3; Bell',
		'fa-bell-o'                              => '&#xf0a2; Bell (Outlined)',
		'fa-bell-slash'                          => '&#xf1f6; Bell Slash',
		'fa-bell-slash-o'                        => '&#xf1f7; Bell Slash (Outlined)',
		'fa-bicycle'                             => '&#xf206; Bicycle',
		'fa-binoculars'                          => '&#xf1e5; Binoculars',
		'fa-birthday-cake'                       => '&#xf1fd; Birthday Cake',
		'fa-bitbucket'                           => '&#xf171; Bitbucket',
		'fa-bitbucket-square'                    => '&#xf172; Bitbucket Square',
		'fa-bitcoin'                             => '&#xf15a; Bitcoin',
		'fa-black-tie'                           => '&#xf27e; Font Awesome Black Tie',
		'fa-blind'                               => '&#xf29d; Blind',
		'fa-bluetooth'                           => '&#xf293; Bluetooth',
		'fa-bluetooth-b'                         => '&#xf294; Bluetooth',
		'fa-bold'                                => '&#xf032; Bold',
		'fa-bolt'                                => '&#xf0e7; Lightning Bolt',
		'fa-bomb'                                => '&#xf1e2; Bomb',
		'fa-book'                                => '&#xf02d; Book',
		'fa-bookmark'                            => '&#xf02e; Bookmark',
		'fa-bookmark-o'                          => '&#xf097; Bookmark (Outlined)',
		'fa-braille'                             => '&#xf2a1; Braille',
		'fa-briefcase'                           => '&#xf0b1; Briefcase',
		'fa-btc'                                 => '&#xf15a; Bitcoin (BTC)',
		'fa-bug'                                 => '&#xf188; Bug',
		'fa-building'                            => '&#xf1ad; Building',
		'fa-building-o'                          => '&#xf0f7; Building (Outlined)',
		'fa-bullhorn'                            => '&#xf0a1; Bullhorn',
		'fa-bullseye'                            => '&#xf140; Bullseye',
		'fa-bus'                                 => '&#xf207; Bus',
		'fa-buysellads'                          => '&#xf20d; BuySellAds',
		'fa-cab'                                 => '&#xf1ba; Cab',
		'fa-calculator'                          => '&#xf1ec; Calculator',
		'fa-calendar'                            => '&#xf073; Calendar',
		'fa-calendar-check-o'                    => '&#xf274; Calendar Check (Outlined)',
		'fa-calendar-minus-o'                    => '&#xf272; Calendar Minus (Outlined)',
		'fa-calendar-o'                          => '&#xf133; Calendar (Outlined)',
		'fa-calendar-plus-o'                     => '&#xf271; Calendar Plus (Outlined)',
		'fa-calendar-times-o'                    => '&#xf273; Calendar Times (Outlined)',
		'fa-camera'                              => '&#xf030; Camera',
		'fa-camera-retro'                        => '&#xf083; Camera Retro',
		'fa-car'                                 => '&#xf1b9; Car',
		'fa-caret-down'                          => '&#xf0d7; Caret Down',
		'fa-caret-left'                          => '&#xf0d9; Caret Left',
		'fa-caret-right'                         => '&#xf0da; Caret Right',
		'fa-caret-square-o-down'                 => '&#xf150; Caret Square Outlined Down',
		'fa-caret-square-o-left'                 => '&#xf191; Caret Square Outlined Left',
		'fa-caret-square-o-right'                => '&#xf152; Caret Square Outlined Right',
		'fa-caret-square-o-up'                   => '&#xf151; Caret Square Outlined Up',
		'fa-caret-up'                            => '&#xf0d8; Caret Up',
		'fa-cart-arrow-down'                     => '&#xf218; Shopping Cart Arrow Down',
		'fa-cart-plus'                           => '&#xf217; Add To Shopping Cart',
		'fa-cc'                                  => '&#xf20a; Closed Captions',
		'fa-cc-amex'                             => '&#xf1f3; American Express Credit Card',
		'fa-cc-diners-club'                      => '&#xf24c; Diner\'s Club Credit Card',
		'fa-cc-discover'                         => '&#xf1f2; Discover Credit Card',
		'fa-cc-jcb'                              => '&#xf24b; JCB Credit Card',
		'fa-cc-mastercard'                       => '&#xf1f1; MasterCard Credit Card',
		'fa-cc-paypal'                           => '&#xf1f4; Paypal Credit Card',
		'fa-cc-stripe'                           => '&#xf1f5; Stripe Credit Card',
		'fa-cc-visa'                             => '&#xf1f0; Visa Credit Card',
		'fa-certificate'                         => '&#xf0a3; Certificate',
		'fa-chain'                               => '&#xf0c1; Chain',
		'fa-chain-broken'                        => '&#xf127; Chain Broken',
		'fa-check'                               => '&#xf00c; Check',
		'fa-check-circle'                        => '&#xf058; Check Circle',
		'fa-check-circle-o'                      => '&#xf05d; Check Circle (Outlined)',
		'fa-check-square'                        => '&#xf14a; Check Square',
		'fa-check-square-o'                      => '&#xf046; Check Square (Outlined)',
		'fa-chevron-circle-down'                 => '&#xf13a; Chevron Circle Down',
		'fa-chevron-circle-left'                 => '&#xf137; Chevron Circle Left',
		'fa-chevron-circle-right'                => '&#xf138; Chevron Circle Right',
		'fa-chevron-circle-up'                   => '&#xf139; Chevron Circle Up',
		'fa-chevron-down'                        => '&#xf078; Chevron Down',
		'fa-chevron-left'                        => '&#xf053; Chevron Left',
		'fa-chevron-right'                       => '&#xf054; Chevron Right',
		'fa-chevron-up'                          => '&#xf077; Chevron Up',
		'fa-child'                               => '&#xf1ae; Child',
		'fa-chrome'                              => '&#xf268; Chrome',
		'fa-circle'                              => '&#xf111; Circle',
		'fa-circle-o'                            => '&#xf10c; Circle (Outlined)',
		'fa-circle-o-notch'                      => '&#xf1ce; Circle (Outlined Notched)',
		'fa-circle-thin'                         => '&#xf1db; Circle (Outlined Thin)',
		'fa-clipboard'                           => '&#xf0ea; Clipboard',
		'fa-clock-o'                             => '&#xf017; Clock (Outlined)',
		'fa-clone'                               => '&#xf24d; Clone',
		'fa-close'                               => '&#xf00d; Close',
		'fa-cloud'                               => '&#xf0c2; Cloud',
		'fa-cloud-download'                      => '&#xf0ed; Cloud Download',
		'fa-cloud-upload'                        => '&#xf0ee; Cloud Upload',
		'fa-cny'                                 => '&#xf157; cny',
		'fa-code'                                => '&#xf121; Code',
		'fa-code-fork'                           => '&#xf126; Code Fork',
		'fa-codepen'                             => '&#xf1cb; Codepen',
		'fa-codiepie'                            => '&#xf284; Codie Pie',
		'fa-coffee'                              => '&#xf0f4; Coffee',
		'fa-cog'                                 => '&#xf013; Cog',
		'fa-cogs'                                => '&#xf085; Cogs',
		'fa-columns'                             => '&#xf0db; Columns',
		'fa-comment'                             => '&#xf075; Comment',
		'fa-comment-o'                           => '&#xf0e5; Comment (Outlined)',
		'fa-commenting'                          => '&#xf27a; Commenting',
		'fa-commenting-o'                        => '&#xf27b; Commenting (Outlined)',
		'fa-comments'                            => '&#xf086; Comments',
		'fa-comments-o'                          => '&#xf0e6; Comments (Outlined)',
		'fa-compass'                             => '&#xf14e; Compass',
		'fa-compress'                            => '&#xf066; Compress',
		'fa-connectdevelop'                      => '&#xf20e; Connect Develop',
		'fa-contao'                              => '&#xf26d; Contao',
		'fa-copy'                                => '&#xf0c5; Copy',
		'fa-copyright'                           => '&#xf1f9; Copyright',
		'fa-creative-commons'                    => '&#xf25e; Creative Commons',
		'fa-credit-card'                         => '&#xf09d; Credit Card',
		'fa-credit-card-alt'                     => '&#xf283; Credit Card',
		'fa-crop'                                => '&#xf125; Crop',
		'fa-crosshairs'                          => '&#xf05b; Crosshairs',
		'fa-css3'                                => '&#xf13c; CSS 3 Logo',
		'fa-cube'                                => '&#xf1b2; Cube',
		'fa-cubes'                               => '&#xf1b3; Cubes',
		'fa-cut'                                 => '&#xf0c4; Cut',
		'fa-cutlery'                             => '&#xf0f5; Cutlery',
		'fa-dashboard'                           => '&#xf0e4; Dashboard',
		'fa-dashcube'                            => '&#xf210; DashCube',
		'fa-database'                            => '&#xf1c0; Database',
		'fa-deaf'                                => '&#xf2a4; Deaf',
		'fa-deafness'                            => '&#xf2a4; Deafness',
		'fa-dedent'                              => '&#xf03b; Dedent',
		'fa-delicious'                           => '&#xf1a5; Delicious Logo',
		'fa-desktop'                             => '&#xf108; Desktop',
		'fa-deviantart'                          => '&#xf1bd; DeviantART',
		'fa-diamond'                             => '&#xf219; Diamond',
		'fa-digg'                                => '&#xf1a6; Digg Logo',
		'fa-dollar'                              => '&#xf155; Dollar',
		'fa-dot-circle-o'                        => '&#xf192; Dot Circle (Outlined)',
		'fa-download'                            => '&#xf019; Download',
		'fa-dribbble'                            => '&#xf17d; Dribbble',
		'fa-drivers-license'                     => '&#xf2c2; Drivers License',
		'fa-drivers-license-o'                   => '&#xf2c3; Drivers License (Outlined)',
		'fa-dropbox'                             => '&#xf16b; Dropbox',
		'fa-drupal'                              => '&#xf1a9; Drupal Logo',
		'fa-edge'                                => '&#xf282; Edge Browser',
		'fa-edit'                                => '&#xf044; Edit',
		'fa-eercast'                             => '&#xf2da; Eercast',
		'fa-eject'                               => '&#xf052; Eject',
		'fa-ellipsis-h'                          => '&#xf141; Ellipsis Horizontal',
		'fa-ellipsis-v'                          => '&#xf142; Ellipsis Vertical',
		'fa-empire'                              => '&#xf1d1; Galactic Empire',
		'fa-envelope'                            => '&#xf0e0; Envelope',
		'fa-envelope-o'                          => '&#xf003; Envelope (Outlined)',
		'fa-envelope-open'                       => '&#xf2b6; Envelope Open',
		'fa-envelope-open-o'                     => '&#xf2b7; Envelope Open (Outlined)',
		'fa-envelope-square'                     => '&#xf199; Envelope Square',
		'fa-envira'                              => '&#xf299; Envira Gallery',
		'fa-eraser'                              => '&#xf12d; Eraser',
		'fa-etsy'                                => '&#xf2d7; Etsy',
		'fa-eur'                                 => '&#xf153; Euro (EUR)',
		'fa-euro'                                => '&#xf153; Euro',
		'fa-exchange'                            => '&#xf0ec; Exchange',
		'fa-exclamation'                         => '&#xf12a; Exclamation',
		'fa-exclamation-circle'                  => '&#xf06a; Exclamation Circle',
		'fa-exclamation-triangle'                => '&#xf071; Exclamation Triangle',
		'fa-expand'                              => '&#xf065; Expand',
		'fa-expeditedssl'                        => '&#xf23e; ExpeditedSSL',
		'fa-external-link'                       => '&#xf08e; External Link',
		'fa-external-link-square'                => '&#xf14c; External Link Square',
		'fa-eye'                                 => '&#xf06e; Eye',
		'fa-eye-slash'                           => '&#xf070; Eye Slash',
		'fa-eyedropper'                          => '&#xf1fb; Eyedropper',
		'fa-fa'                                  => '&#xf2b4; fa',
		'fa-facebook'                            => '&#xf09a; Facebook',
		'fa-facebook-f'                          => '&#xf09a; Facebook-f',
		'fa-facebook-official'                   => '&#xf230; Facebook Official',
		'fa-facebook-square'                     => '&#xf082; Facebook Square',
		'fa-fast-backward'                       => '&#xf049; Fast Backward',
		'fa-fast-forward'                        => '&#xf050; Fast Forward',
		'fa-fax'                                 => '&#xf1ac; Fax',
		'fa-feed'                                => '&#xf09e; Feed',
		'fa-female'                              => '&#xf182; Female',
		'fa-fighter-jet'                         => '&#xf0fb; Fighter Jet',
		'fa-file'                                => '&#xf15b; File',
		'fa-file-archive-o'                      => '&#xf1c6; Archive File (Outlined)',
		'fa-file-audio-o'                        => '&#xf1c7; Audio File (Outlined)',
		'fa-file-code-o'                         => '&#xf1c9; Code File (Outlined)',
		'fa-file-excel-o'                        => '&#xf1c3; Excel File (Outlined)',
		'fa-file-image-o'                        => '&#xf1c5; Image File (Outlined)',
		'fa-file-movie-o'                        => '&#xf1c8; File Movie (Outlined)',
		'fa-file-o'                              => '&#xf016; File (Outlined)',
		'fa-file-pdf-o'                          => '&#xf1c1; PDF File (Outlined)',
		'fa-file-photo-o'                        => '&#xf1c5; File Photo (Outlined)',
		'fa-file-picture-o'                      => '&#xf1c5; File Picture (Outlined)',
		'fa-file-powerpoint-o'                   => '&#xf1c4; Powerpoint File (Outlined)',
		'fa-file-sound-o'                        => '&#xf1c7; File Sound (Outlined)',
		'fa-file-text'                           => '&#xf15c; File Text',
		'fa-file-text-o'                         => '&#xf0f6; File Text (Outlined)',
		'fa-file-video-o'                        => '&#xf1c8; Video File (Outlined)',
		'fa-file-word-o'                         => '&#xf1c2; Word File (Outlined)',
		'fa-file-zip-o'                          => '&#xf1c6; File Zip (Outlined)',
		'fa-files-o'                             => '&#xf0c5; Files (Outlined)',
		'fa-film'                                => '&#xf008; Film',
		'fa-filter'                              => '&#xf0b0; Filter',
		'fa-fire'                                => '&#xf06d; Fire',
		'fa-fire-extinguisher'                   => '&#xf134; Fire Extinguisher',
		'fa-firefox'                             => '&#xf269; Firefox',
		'fa-first-order'                         => '&#xf2b0; First Order',
		'fa-flag'                                => '&#xf024; Flag',
		'fa-flag-checkered'                      => '&#xf11e; Flag Checkered',
		'fa-flag-o'                              => '&#xf11d; Flag (Outlined)',
		'fa-flash'                               => '&#xf0e7; Flash',
		'fa-flask'                               => '&#xf0c3; Flask',
		'fa-flickr'                              => '&#xf16e; Flickr',
		'fa-floppy-o'                            => '&#xf0c7; Floppy (Outlined)',
		'fa-folder'                              => '&#xf07b; Folder',
		'fa-folder-o'                            => '&#xf114; Folder (Outlined)',
		'fa-folder-open'                         => '&#xf07c; Folder Open',
		'fa-folder-open-o'                       => '&#xf115; Folder Open (Outlined)',
		'fa-font'                                => '&#xf031; Font',
		'fa-font-awesome'                        => '&#xf2b4; Font Awesome',
		'fa-fonticons'                           => '&#xf280; Fonticons',
		'fa-fort-awesome'                        => '&#xf286; Fort Awesome',
		'fa-forumbee'                            => '&#xf211; Forumbee',
		'fa-forward'                             => '&#xf04e; Forward',
		'fa-foursquare'                          => '&#xf180; Foursquare',
		'fa-free-code-camp'                      => '&#xf2c5; Free Code Camp',
		'fa-frown-o'                             => '&#xf119; Frown (Outlined)',
		'fa-futbol-o'                            => '&#xf1e3; Futbol (Outlined)',
		'fa-gamepad'                             => '&#xf11b; Gamepad',
		'fa-gavel'                               => '&#xf0e3; Gavel',
		'fa-gbp'                                 => '&#xf154; GBP',
		'fa-ge'                                  => '&#xf1d1; ge',
		'fa-gear'                                => '&#xf013; Gear',
		'fa-gears'                               => '&#xf085; Gears',
		'fa-genderless'                          => '&#xf22d; Genderless',
		'fa-get-pocket'                          => '&#xf265; Get Pocket',
		'fa-gg'                                  => '&#xf260; GG Currency',
		'fa-gg-circle'                           => '&#xf261; GG Currency Circle',
		'fa-gift'                                => '&#xf06b; Gift',
		'fa-git'                                 => '&#xf1d3; Git',
		'fa-git-square'                          => '&#xf1d2; Git Square',
		'fa-github'                              => '&#xf09b; GitHub',
		'fa-github-alt'                          => '&#xf113; GitHub (Alternate)',
		'fa-github-square'                       => '&#xf092; GitHub Square',
		'fa-gitlab'                              => '&#xf296; GitLab',
		'fa-gittip'                              => '&#xf184; Gittip',
		'fa-glass'                               => '&#xf000; Glass',
		'fa-glide'                               => '&#xf2a5; Glide',
		'fa-glide-g'                             => '&#xf2a6; Glide-g',
		'fa-globe'                               => '&#xf0ac; Globe',
		'fa-google'                              => '&#xf1a0; Google Logo',
		'fa-google-plus'                         => '&#xf0d5; Google Plus',
		'fa-google-plus-circle'                  => '&#xf2b3; Google Plus Circle',
		'fa-google-plus-official'                => '&#xf2b3; Google Plus Official',
		'fa-google-plus-square'                  => '&#xf0d4; Google Plus Square',
		'fa-google-wallet'                       => '&#xf1ee; Google Wallet',
		'fa-graduation-cap'                      => '&#xf19d; Graduation Cap',
		'fa-gratipay'                            => '&#xf184; Gratipay (Gittip)',
		'fa-grav'                                => '&#xf2d6; Grav',
		'fa-group'                               => '&#xf0c0; Group',
		'fa-h-square'                            => '&#xf0fd; H-Square',
		'fa-hacker-news'                         => '&#xf1d4; Hacker News',
		'fa-hand-grab-o'                         => '&#xf255; Hand Grab (Outlined)',
		'fa-hand-lizard-o'                       => '&#xf258; Lizard (Hand)',
		'fa-hand-o-down'                         => '&#xf0a7; Hand Outlined Down',
		'fa-hand-o-left'                         => '&#xf0a5; Hand Outlined Left',
		'fa-hand-o-right'                        => '&#xf0a4; Hand Outlined Right',
		'fa-hand-o-up'                           => '&#xf0a6; Hand Outlined Up',
		'fa-hand-paper-o'                        => '&#xf256; Paper (Hand)',
		'fa-hand-peace-o'                        => '&#xf25b; Hand Peace',
		'fa-hand-pointer-o'                      => '&#xf25a; Hand Pointer',
		'fa-hand-rock-o'                         => '&#xf255; Rock (Hand)',
		'fa-hand-scissors-o'                     => '&#xf257; Scissors (Hand)',
		'fa-hand-spock-o'                        => '&#xf259; Spock (Hand)',
		'fa-hand-stop-o'                         => '&#xf256; Hand Stop (Outlined)',
		'fa-handshake-o'                         => '&#xf2b5; Handshake (Outlined)',
		'fa-hard-of-hearing'                     => '&#xf2a4; Hard Of Hearing',
		'fa-hashtag'                             => '&#xf292; Hashtag',
		'fa-hdd-o'                               => '&#xf0a0; HDD',
		'fa-header'                              => '&#xf1dc; Header',
		'fa-headphones'                          => '&#xf025; Headphones',
		'fa-heart'                               => '&#xf004; Heart',
		'fa-heart-o'                             => '&#xf08a; Heart (Outlined)',
		'fa-heartbeat'                           => '&#xf21e; Heartbeat',
		'fa-history'                             => '&#xf1da; History',
		'fa-home'                                => '&#xf015; Home',
		'fa-hospital-o'                          => '&#xf0f8; Hospital (Outlined)',
		'fa-hotel'                               => '&#xf236; Hotel',
		'fa-hourglass'                           => '&#xf254; Hourglass',
		'fa-hourglass-1'                         => '&#xf251; Hourglass 1',
		'fa-hourglass-2'                         => '&#xf252; Hourglass 2',
		'fa-hourglass-3'                         => '&#xf253; Hourglass 3',
		'fa-hourglass-end'                       => '&#xf253; Hourglass End',
		'fa-hourglass-half'                      => '&#xf252; Hourglass Half',
		'fa-hourglass-o'                         => '&#xf250; Hourglass (Outlined)',
		'fa-hourglass-start'                     => '&#xf251; Hourglass Start',
		'fa-houzz'                               => '&#xf27c; Houzz',
		'fa-html5'                               => '&#xf13b; HTML5',
		'fa-i-cursor'                            => '&#xf246; I Beam Cursor',
		'fa-id-badge'                            => '&#xf2c1; Identification Badge',
		'fa-id-card'                             => '&#xf2c2; Identification Card',
		'fa-id-card-o'                           => '&#xf2c3; Identification Card (Outlined)',
		'fa-ils'                                 => '&#xf20b; Shekel (ILS)',
		'fa-image'                               => '&#xf03e; Image',
		'fa-imdb'                                => '&#xf2d8; IMDB',
		'fa-inbox'                               => '&#xf01c; Inbox',
		'fa-indent'                              => '&#xf03c; Indent',
		'fa-industry'                            => '&#xf275; Industry',
		'fa-info'                                => '&#xf129; Info',
		'fa-info-circle'                         => '&#xf05a; Info Circle',
		'fa-inr'                                 => '&#xf156; Indian Rupee (INR)',
		'fa-instagram'                           => '&#xf16d; Instagram',
		'fa-institution'                         => '&#xf19c; Institution',
		'fa-internet-explorer'                   => '&#xf26b; Internet Explorer',
		'fa-intersex'                            => '&#xf224; Intersex',
		'fa-ioxhost'                             => '&#xf208; Ioxhost',
		'fa-italic'                              => '&#xf033; Italic',
		'fa-joomla'                              => '&#xf1aa; Joomla Logo',
		'fa-jpy'                                 => '&#xf157; Japanese Yen (JPY)',
		'fa-jsfiddle'                            => '&#xf1cc; JsFiddle',
		'fa-key'                                 => '&#xf084; Key',
		'fa-keyboard-o'                          => '&#xf11c; Keyboard (Outlined)',
		'fa-krw'                                 => '&#xf159; Korean Won (KRW)',
		'fa-language'                            => '&#xf1ab; Language',
		'fa-laptop'                              => '&#xf109; Laptop',
		'fa-lastfm'                              => '&#xf202; Last.fm',
		'fa-lastfm-square'                       => '&#xf203; Last.fm Square',
		'fa-leaf'                                => '&#xf06c; Leaf',
		'fa-leanpub'                             => '&#xf212; Leanpub',
		'fa-legal'                               => '&#xf0e3; Legal',
		'fa-lemon-o'                             => '&#xf094; Lemon (Outlined)',
		'fa-level-down'                          => '&#xf149; Level Down',
		'fa-level-up'                            => '&#xf148; Level Up',
		'fa-life-bouy'                           => '&#xf1cd; Life Bouy',
		'fa-life-buoy'                           => '&#xf1cd; Life Buoy',
		'fa-life-ring'                           => '&#xf1cd; Life Ring',
		'fa-life-saver'                          => '&#xf1cd; Life Saver',
		'fa-lightbulb-o'                         => '&#xf0eb; Lightbulb (Outlined)',
		'fa-line-chart'                          => '&#xf201; Line Chart',
		'fa-link'                                => '&#xf0c1; Link',
		'fa-linkedin'                            => '&#xf0e1; LinkedIn',
		'fa-linkedin-square'                     => '&#xf08c; LinkedIn Square',
		'fa-linode'                              => '&#xf2b8; Linode',
		'fa-linux'                               => '&#xf17c; Linux',
		'fa-list'                                => '&#xf03a; List',
		'fa-list-alt'                            => '&#xf022; List (Alternate)',
		'fa-list-ol'                             => '&#xf0cb; List OL',
		'fa-list-ul'                             => '&#xf0ca; List UL',
		'fa-location-arrow'                      => '&#xf124; Location Arrow',
		'fa-lock'                                => '&#xf023; Lock',
		'fa-long-arrow-down'                     => '&#xf175; Long Arrow Down',
		'fa-long-arrow-left'                     => '&#xf177; Long Arrow Left',
		'fa-long-arrow-right'                    => '&#xf178; Long Arrow Right',
		'fa-long-arrow-up'                       => '&#xf176; Long Arrow Up',
		'fa-low-vision'                          => '&#xf2a8; Low Vision',
		'fa-magic'                               => '&#xf0d0; Magic',
		'fa-magnet'                              => '&#xf076; Magnet',
		'fa-mail-forward'                        => '&#xf064; Mail Forward',
		'fa-mail-reply'                          => '&#xf112; Mail Reply',
		'fa-mail-reply-all'                      => '&#xf122; Mail Reply All',
		'fa-male'                                => '&#xf183; Male',
		'fa-map'                                 => '&#xf279; Map',
		'fa-map-marker'                          => '&#xf041; Map Marker',
		'fa-map-o'                               => '&#xf278; Map (Outlined)',
		'fa-map-pin'                             => '&#xf276; Map Pin',
		'fa-map-signs'                           => '&#xf277; Map Signs',
		'fa-mars'                                => '&#xf222; Mars',
		'fa-mars-double'                         => '&#xf227; Mars Double',
		'fa-mars-stroke'                         => '&#xf229; Mars Stroke',
		'fa-mars-stroke-h'                       => '&#xf22b; Mars Stroke Horizontal',
		'fa-mars-stroke-v'                       => '&#xf22a; Mars Stroke Vertical',
		'fa-maxcdn'                              => '&#xf136; MaxCDN',
		'fa-meanpath'                            => '&#xf20c; Meanpath',
		'fa-medium'                              => '&#xf23a; Medium',
		'fa-medkit'                              => '&#xf0fa; Medkit',
		'fa-meetup'                              => '&#xf2e0; Meetup',
		'fa-meh-o'                               => '&#xf11a; Meh (Outlined)',
		'fa-mercury'                             => '&#xf223; Mercury',
		'fa-microchip'                           => '&#xf2db; Microchip',
		'fa-microphone'                          => '&#xf130; Microphone',
		'fa-microphone-slash'                    => '&#xf131; Microphone Slash',
		'fa-minus'                               => '&#xf068; Minus',
		'fa-minus-circle'                        => '&#xf056; Minus Circle',
		'fa-minus-square'                        => '&#xf146; Minus Square',
		'fa-minus-square-o'                      => '&#xf147; Minus Square (Outlined)',
		'fa-mixcloud'                            => '&#xf289; Mixcloud',
		'fa-mobile'                              => '&#xf10b; Mobile Phone',
		'fa-mobile-phone'                        => '&#xf10b; Mobile Phone',
		'fa-modx'                                => '&#xf285; MODX',
		'fa-money'                               => '&#xf0d6; Money',
		'fa-moon-o'                              => '&#xf186; Moon (Outlined)',
		'fa-mortar-board'                        => '&#xf19d; Mortar Board',
		'fa-motorcycle'                          => '&#xf21c; Motorcycle',
		'fa-mouse-pointer'                       => '&#xf245; Mouse Pointer',
		'fa-music'                               => '&#xf001; Music',
		'fa-navicon'                             => '&#xf0c9; Navicon',
		'fa-neuter'                              => '&#xf22c; Neuter',
		'fa-newspaper-o'                         => '&#xf1ea; Newspaper (Outlined)',
		'fa-object-group'                        => '&#xf247; Object Group',
		'fa-object-ungroup'                      => '&#xf248; Object Ungroup',
		'fa-odnoklassniki'                       => '&#xf263; Odnoklassniki',
		'fa-odnoklassniki-square'                => '&#xf264; Odnoklassniki Square',
		'fa-opencart'                            => '&#xf23d; OpenCart',
		'fa-openid'                              => '&#xf19b; OpenID',
		'fa-opera'                               => '&#xf26a; Opera',
		'fa-optin-monster'                       => '&#xf23c; Optin Monster',
		'fa-outdent'                             => '&#xf03b; Outdent',
		'fa-pagelines'                           => '&#xf18c; Pagelines',
		'fa-paint-brush'                         => '&#xf1fc; Paint Brush',
		'fa-paper-plane'                         => '&#xf1d8; Paper Plane',
		'fa-paper-plane-o'                       => '&#xf1d9; Paper Plane (Outlined)',
		'fa-paperclip'                           => '&#xf0c6; Paperclip',
		'fa-paragraph'                           => '&#xf1dd; Paragraph',
		'fa-paste'                               => '&#xf0ea; Paste',
		'fa-pause'                               => '&#xf04c; Pause',
		'fa-pause-circle'                        => '&#xf28b; Pause Circle',
		'fa-pause-circle-o'                      => '&#xf28c; Pause Circle (Outlined)',
		'fa-paw'                                 => '&#xf1b0; Paw',
		'fa-paypal'                              => '&#xf1ed; Paypal',
		'fa-pencil'                              => '&#xf040; Pencil',
		'fa-pencil-square'                       => '&#xf14b; Pencil Square',
		'fa-pencil-square-o'                     => '&#xf044; Pencil Square (Outlined)',
		'fa-percent'                             => '&#xf295; Percent',
		'fa-phone'                               => '&#xf095; Phone',
		'fa-phone-square'                        => '&#xf098; Phone Square',
		'fa-photo'                               => '&#xf03e; Photo',
		'fa-picture-o'                           => '&#xf03e; Picture (Outlined)',
		'fa-pie-chart'                           => '&#xf200; Pie Chart',
		'fa-pied-piper'                          => '&#xf2ae; Pied Piper Logo',
		'fa-pied-piper-alt'                      => '&#xf1a8; Pied Piper Alternate Logo',
		'fa-pied-piper-pp'                       => '&#xf1a7; Pied Piper PP Logo (Old)',
		'fa-pinterest'                           => '&#xf0d2; Pinterest',
		'fa-pinterest-p'                         => '&#xf231; Pinterest P',
		'fa-pinterest-square'                    => '&#xf0d3; Pinterest Square',
		'fa-plane'                               => '&#xf072; Plane',
		'fa-play'                                => '&#xf04b; Play',
		'fa-play-circle'                         => '&#xf144; Play Circle',
		'fa-play-circle-o'                       => '&#xf01d; Play Circle (Outlined)',
		'fa-plug'                                => '&#xf1e6; Plug',
		'fa-plus'                                => '&#xf067; Plus',
		'fa-plus-circle'                         => '&#xf055; Plus Circle',
		'fa-plus-square'                         => '&#xf0fe; Plus Square',
		'fa-plus-square-o'                       => '&#xf196; Plus Square (Outlined)',
		'fa-podcast'                             => '&#xf2ce; Podcast',
		'fa-power-off'                           => '&#xf011; Power Off',
		'fa-print'                               => '&#xf02f; Print',
		'fa-product-hunt'                        => '&#xf288; Product Hunt',
		'fa-puzzle-piece'                        => '&#xf12e; Puzzle Piece',
		'fa-qq'                                  => '&#xf1d6; QQ',
		'fa-qrcode'                              => '&#xf029; Qrcode',
		'fa-question'                            => '&#xf128; Question',
		'fa-question-circle'                     => '&#xf059; Question Circle',
		'fa-question-circle-o'                   => '&#xf29c; Question Circle (Outlined)',
		'fa-quora'                               => '&#xf2c4; Quora',
		'fa-quote-left'                          => '&#xf10d; Quote Left',
		'fa-quote-right'                         => '&#xf10e; Quote Right',
		'fa-ra'                                  => '&#xf1d0; RA',
		'fa-random'                              => '&#xf074; Random',
		'fa-ravelry'                             => '&#xf2d9; Ravelry',
		'fa-rebel'                               => '&#xf1d0; Rebel Alliance',
		'fa-recycle'                             => '&#xf1b8; Recycle',
		'fa-reddit'                              => '&#xf1a1; Reddit Logo',
		'fa-reddit-alien'                        => '&#xf281; Reddit Alien',
		'fa-reddit-square'                       => '&#xf1a2; Reddit Square',
		'fa-refresh'                             => '&#xf021; Refresh',
		'fa-registered'                          => '&#xf25d; Registered Trademark',
		'fa-remove'                              => '&#xf00d; Remove',
		'fa-renren'                              => '&#xf18b; Renren',
		'fa-reorder'                             => '&#xf0c9; Reorder',
		'fa-repeat'                              => '&#xf01e; Repeat',
		'fa-reply'                               => '&#xf112; Reply',
		'fa-reply-all'                           => '&#xf122; Reply All',
		'fa-resistance'                          => '&#xf1d0; Resistance',
		'fa-retweet'                             => '&#xf079; Retweet',
		'fa-rmb'                                 => '&#xf157; rmb',
		'fa-road'                                => '&#xf018; Road',
		'fa-rocket'                              => '&#xf135; Rocket',
		'fa-rotate-left'                         => '&#xf0e2; Rotate Left',
		'fa-rotate-right'                        => '&#xf01e; Rotate Right',
		'fa-rouble'                              => '&#xf158; Rouble',
		'fa-rss'                                 => '&#xf09e; Rss',
		'fa-rss-square'                          => '&#xf143; RSS Square',
		'fa-rub'                                 => '&#xf158; Russian Ruble (RUB)',
		'fa-ruble'                               => '&#xf158; Ruble',
		'fa-rupee'                               => '&#xf156; Rupee',
		'fa-s15'                                 => '&#xf2cd; S15',
		'fa-safari'                              => '&#xf267; Safari',
		'fa-save'                                => '&#xf0c7; Save',
		'fa-scissors'                            => '&#xf0c4; Scissors',
		'fa-scribd'                              => '&#xf28a; Scribd',
		'fa-search'                              => '&#xf002; Search',
		'fa-search-minus'                        => '&#xf010; Search Minus',
		'fa-search-plus'                         => '&#xf00e; Search Plus',
		'fa-sellsy'                              => '&#xf213; Sellsy',
		'fa-send'                                => '&#xf1d8; Send',
		'fa-send-o'                              => '&#xf1d9; Send (Outlined)',
		'fa-server'                              => '&#xf233; Server',
		'fa-share'                               => '&#xf064; Share',
		'fa-share-alt'                           => '&#xf1e0; Share (Alternate)',
		'fa-share-alt-square'                    => '&#xf1e1; Share (Alternate) Square',
		'fa-share-square'                        => '&#xf14d; Share Square',
		'fa-share-square-o'                      => '&#xf045; Share Square (Outlined)',
		'fa-shekel'                              => '&#xf20b; Shekel',
		'fa-sheqel'                              => '&#xf20b; Sheqel',
		'fa-shield'                              => '&#xf132; Shield',
		'fa-ship'                                => '&#xf21a; Ship',
		'fa-shirtsinbulk'                        => '&#xf214; Shirts In Bulk',
		'fa-shopping-bag'                        => '&#xf290; Shopping Bag',
		'fa-shopping-basket'                     => '&#xf291; Shopping Basket',
		'fa-shopping-cart'                       => '&#xf07a; Shopping Cart',
		'fa-shower'                              => '&#xf2cc; Shower',
		'fa-sign-in'                             => '&#xf090; Sign In',
		'fa-sign-language'                       => '&#xf2a7; Sign Language',
		'fa-sign-out'                            => '&#xf08b; Sign Out',
		'fa-signal'                              => '&#xf012; Signal',
		'fa-signing'                             => '&#xf2a7; Signing',
		'fa-simplybuilt'                         => '&#xf215; SimplyBuilt',
		'fa-sitemap'                             => '&#xf0e8; Sitemap',
		'fa-skyatlas'                            => '&#xf216; Skyatlas',
		'fa-skype'                               => '&#xf17e; Skype',
		'fa-slack'                               => '&#xf198; Slack Logo',
		'fa-sliders'                             => '&#xf1de; Sliders',
		'fa-slideshare'                          => '&#xf1e7; Slideshare',
		'fa-smile-o'                             => '&#xf118; Smile (Outlined)',
		'fa-snapchat'                            => '&#xf2ab; Snapchat',
		'fa-snapchat-ghost'                      => '&#xf2ac; Snapchat Ghost',
		'fa-snapchat-square'                     => '&#xf2ad; Snapchat Square',
		'fa-snowflake-o'                         => '&#xf2dc; Snowflake (Outlined)',
		'fa-soccer-ball-o'                       => '&#xf1e3; Soccer Ball (Outlined)',
		'fa-sort'                                => '&#xf0dc; Sort',
		'fa-sort-alpha-asc'                      => '&#xf15d; Sort Alpha Ascending',
		'fa-sort-alpha-desc'                     => '&#xf15e; Sort Alpha Descending',
		'fa-sort-amount-asc'                     => '&#xf160; Sort Amount Ascending',
		'fa-sort-amount-desc'                    => '&#xf161; Sort Amount Descending',
		'fa-sort-asc'                            => '&#xf0de; Sort Ascending',
		'fa-sort-desc'                           => '&#xf0dd; Sort Descending',
		'fa-sort-down'                           => '&#xf0dd; Sort Down',
		'fa-sort-numeric-asc'                    => '&#xf162; Sort Numeric Ascending',
		'fa-sort-numeric-desc'                   => '&#xf163; Sort Numeric Descending',
		'fa-sort-up'                             => '&#xf0de; Sort Up',
		'fa-soundcloud'                          => '&#xf1be; SoundCloud',
		'fa-space-shuttle'                       => '&#xf197; Space Shuttle',
		'fa-spinner'                             => '&#xf110; Spinner',
		'fa-spoon'                               => '&#xf1b1; Spoon',
		'fa-spotify'                             => '&#xf1bc; Spotify',
		'fa-square'                              => '&#xf0c8; Square',
		'fa-square-o'                            => '&#xf096; Square (Outlined)',
		'fa-stack-exchange'                      => '&#xf18d; Stack Exchange',
		'fa-stack-overflow'                      => '&#xf16c; Stack Overflow',
		'fa-star'                                => '&#xf005; Star',
		'fa-star-half'                           => '&#xf089; Star Half',
		'fa-star-half-empty'                     => '&#xf123; Star Half Empty',
		'fa-star-half-full'                      => '&#xf123; Star Half Full',
		'fa-star-half-o'                         => '&#xf123; Star Half (Outlined)',
		'fa-star-o'                              => '&#xf006; Star (Outlined)',
		'fa-steam'                               => '&#xf1b6; Steam',
		'fa-steam-square'                        => '&#xf1b7; Steam Square',
		'fa-step-backward'                       => '&#xf048; Step Backward',
		'fa-step-forward'                        => '&#xf051; Step Forward',
		'fa-stethoscope'                         => '&#xf0f1; Stethoscope',
		'fa-sticky-note'                         => '&#xf249; Sticky Note',
		'fa-sticky-note-o'                       => '&#xf24a; Sticky Note (Outlined)',
		'fa-stop'                                => '&#xf04d; Stop',
		'fa-stop-circle'                         => '&#xf28d; Stop Circle',
		'fa-stop-circle-o'                       => '&#xf28e; Stop Circle (Outlined)',
		'fa-street-view'                         => '&#xf21d; Street View',
		'fa-strikethrough'                       => '&#xf0cc; Strikethrough',
		'fa-stumbleupon'                         => '&#xf1a4; StumbleUpon Logo',
		'fa-stumbleupon-circle'                  => '&#xf1a3; StumbleUpon Circle',
		'fa-subscript'                           => '&#xf12c; Subscript',
		'fa-subway'                              => '&#xf239; Subway',
		'fa-suitcase'                            => '&#xf0f2; Suitcase',
		'fa-sun-o'                               => '&#xf185; Sun (Outlined)',
		'fa-superpowers'                         => '&#xf2dd; Superpowers',
		'fa-superscript'                         => '&#xf12b; Superscript',
		'fa-support'                             => '&#xf1cd; Support',
		'fa-table'                               => '&#xf0ce; Table',
		'fa-tablet'                              => '&#xf10a; Tablet',
		'fa-tachometer'                          => '&#xf0e4; Tachometer',
		'fa-tag'                                 => '&#xf02b; Tag',
		'fa-tags'                                => '&#xf02c; Tags',
		'fa-tasks'                               => '&#xf0ae; Tasks',
		'fa-taxi'                                => '&#xf1ba; Taxi',
		'fa-telegram'                            => '&#xf2c6; Telegram',
		'fa-television'                          => '&#xf26c; Television',
		'fa-tencent-weibo'                       => '&#xf1d5; Tencent Weibo',
		'fa-terminal'                            => '&#xf120; Terminal',
		'fa-text-height'                         => '&#xf034; Text Height',
		'fa-text-width'                          => '&#xf035; Text Width',
		'fa-th'                                  => '&#xf00a; Th',
		'fa-th-large'                            => '&#xf009; Th Large',
		'fa-th-list'                             => '&#xf00b; Th List',
		'fa-themeisle'                           => '&#xf2b2; ThemeIsle',
		'fa-thermometer'                         => '&#xf2c7; Thermometer',
		'fa-thermometer-0'                       => '&#xf2cb; Thermometer 0',
		'fa-thermometer-1'                       => '&#xf2ca; Thermometer 1',
		'fa-thermometer-2'                       => '&#xf2c9; Thermometer 2',
		'fa-thermometer-3'                       => '&#xf2c8; Thermometer 3',
		'fa-thermometer-4'                       => '&#xf2c7; Thermometer 4',
		'fa-thermometer-empty'                   => '&#xf2cb; Thermometer Empty',
		'fa-thermometer-full'                    => '&#xf2c7; Thermometer Full',
		'fa-thermometer-half'                    => '&#xf2c9; Thermometer 1/2 Full',
		'fa-thermometer-quarter'                 => '&#xf2ca; Thermometer 1/4 Full',
		'fa-thermometer-three-quarters'          => '&#xf2c8; Thermometer 3/4 Full',
		'fa-thumb-tack'                          => '&#xf08d; Thumb Tack',
		'fa-thumbs-down'                         => '&#xf165; Thumbs Down',
		'fa-thumbs-o-down'                       => '&#xf088; Thumbs Down (Outlined)',
		'fa-thumbs-o-up'                         => '&#xf087; Thumbs Up (Outlined)',
		'fa-thumbs-up'                           => '&#xf164; Thumbs Up',
		'fa-ticket'                              => '&#xf145; Ticket',
		'fa-times'                               => '&#xf00d; Times',
		'fa-times-circle'                        => '&#xf057; Times Circle',
		'fa-times-circle-o'                      => '&#xf05c; Times Circle (Outlined)',
		'fa-times-rectangle'                     => '&#xf2d3; Times Rectangle',
		'fa-times-rectangle-o'                   => '&#xf2d4; Times Rectangle (Outlined)',
		'fa-tint'                                => '&#xf043; Tint',
		'fa-toggle-down'                         => '&#xf150; Toggle Down',
		'fa-toggle-left'                         => '&#xf191; Toggle Left',
		'fa-toggle-off'                          => '&#xf204; Toggle Off',
		'fa-toggle-on'                           => '&#xf205; Toggle On',
		'fa-toggle-right'                        => '&#xf152; Toggle Right',
		'fa-toggle-up'                           => '&#xf151; Toggle Up',
		'fa-trademark'                           => '&#xf25c; Trademark',
		'fa-train'                               => '&#xf238; Train',
		'fa-transgender'                         => '&#xf224; Transgender',
		'fa-transgender-alt'                     => '&#xf225; Transgender (Alternate)',
		'fa-trash'                               => '&#xf1f8; Trash',
		'fa-trash-o'                             => '&#xf014; Trash (Outlined)',
		'fa-tree'                                => '&#xf1bb; Tree',
		'fa-trello'                              => '&#xf181; Trello',
		'fa-tripadvisor'                         => '&#xf262; TripAdvisor',
		'fa-trophy'                              => '&#xf091; Trophy',
		'fa-truck'                               => '&#xf0d1; Truck',
		'fa-try'                                 => '&#xf195; Turkish Lira (TRY)',
		'fa-tty'                                 => '&#xf1e4; TTY',
		'fa-tumblr'                              => '&#xf173; Tumblr',
		'fa-tumblr-square'                       => '&#xf174; Tumblr Square',
		'fa-turkish-lira'                        => '&#xf195; Turkish Lira',
		'fa-tv'                                  => '&#xf26c; TV',
		'fa-twitch'                              => '&#xf1e8; Twitch',
		'fa-twitter'                             => '&#xf099; Twitter',
		'fa-twitter-square'                      => '&#xf081; Twitter Square',
		'fa-umbrella'                            => '&#xf0e9; Umbrella',
		'fa-underline'                           => '&#xf0cd; Underline',
		'fa-undo'                                => '&#xf0e2; Undo',
		'fa-universal-access'                    => '&#xf29a; Universal Access',
		'fa-university'                          => '&#xf19c; University',
		'fa-unlink'                              => '&#xf127; Unlink',
		'fa-unlock'                              => '&#xf09c; Unlock',
		'fa-unlock-alt'                          => '&#xf13e; Unlock (Alternate)',
		'fa-unsorted'                            => '&#xf0dc; Unsorted',
		'fa-upload'                              => '&#xf093; Upload',
		'fa-usb'                                 => '&#xf287; USB',
		'fa-usd'                                 => '&#xf155; US Dollar',
		'fa-user'                                => '&#xf007; User',
		'fa-user-circle'                         => '&#xf2bd; User Circle',
		'fa-user-circle-o'                       => '&#xf2be; User Circle (Outlined)',
		'fa-user-md'                             => '&#xf0f0; User Md',
		'fa-user-o'                              => '&#xf2c0; User (Outlined)',
		'fa-user-plus'                           => '&#xf234; Add User',
		'fa-user-secret'                         => '&#xf21b; User Secret',
		'fa-user-times'                          => '&#xf235; Remove User',
		'fa-users'                               => '&#xf0c0; Users',
		'fa-vcard'                               => '&#xf2bb; Vcard',
		'fa-vcard-o'                             => '&#xf2bc; Vcard (Outlined)',
		'fa-venus'                               => '&#xf221; Venus',
		'fa-venus-double'                        => '&#xf226; Venus Double',
		'fa-venus-mars'                          => '&#xf228; Venus Mars',
		'fa-viacoin'                             => '&#xf237; Viacoin (VIA)',
		'fa-viadeo'                              => '&#xf2a9; Viadeo',
		'fa-viadeo-square'                       => '&#xf2aa; Viadeo Square',
		'fa-video-camera'                        => '&#xf03d; Video Camera',
		'fa-vimeo'                               => '&#xf27d; Vimeo',
		'fa-vimeo-square'                        => '&#xf194; Vimeo Square',
		'fa-vine'                                => '&#xf1ca; Vine',
		'fa-vk'                                  => '&#xf189; VK',
		'fa-volume-control-phone'                => '&#xf2a0; Volume Control Phone',
		'fa-volume-down'                         => '&#xf027; Volume Down',
		'fa-volume-off'                          => '&#xf026; Volume Off',
		'fa-volume-up'                           => '&#xf028; Volume Up',
		'fa-warning'                             => '&#xf071; Warning',
		'fa-wechat'                              => '&#xf1d7; Wechat',
		'fa-weibo'                               => '&#xf18a; Weibo',
		'fa-weixin'                              => '&#xf1d7; Weixin (WeChat)',
		'fa-whatsapp'                            => '&#xf232; WhatsApp',
		'fa-wheelchair'                          => '&#xf193; Wheelchair',
		'fa-wheelchair-alt'                      => '&#xf29b; Wheelchair (Alternate)',
		'fa-wifi'                                => '&#xf1eb; WiFi',
		'fa-wikipedia-w'                         => '&#xf266; Wikipedia W',
		'fa-window-close'                        => '&#xf2d3; Window Close',
		'fa-window-close-o'                      => '&#xf2d4; Window Close Outline',
		'fa-window-maximize'                     => '&#xf2d0; Window Maximize',
		'fa-window-minimize'                     => '&#xf2d1; Window Minimize',
		'fa-window-restore'                      => '&#xf2d2; Window Restore',
		'fa-windows'                             => '&#xf17a; Windows',
		'fa-won'                                 => '&#xf159; Won',
		'fa-wordpress'                           => '&#xf19a; WordPress Logo',
		'fa-wpbeginner'                          => '&#xf297; WPBeginner',
		'fa-wpexplorer'                          => '&#xf2de; WPExplorer',
		'fa-wpforms'                             => '&#xf298; WPForms',
		'fa-wrench'                              => '&#xf0ad; Wrench',
		'fa-xing'                                => '&#xf168; Xing',
		'fa-xing-square'                         => '&#xf169; Xing Square',
		'fa-y-combinator'                        => '&#xf23b; Y Combinator',
		'fa-y-combinator-square'                 => '&#xf1d4; Y Combinator Square',
		'fa-yahoo'                               => '&#xf19e; Yahoo Logo',
		'fa-yc'                                  => '&#xf23b; YC',
		'fa-yc-square'                           => '&#xf1d4; YC Square',
		'fa-yelp'                                => '&#xf1e9; Yelp',
		'fa-yen'                                 => '&#xf157; Yen',
		'fa-yoast'                               => '&#xf2b1; Yoast',
		'fa-youtube'                             => '&#xf167; YouTube',
		'fa-youtube-play'                        => '&#xf16a; YouTube Play',
		'fa-youtube-square'                      => '&#xf166; YouTube Square'
	);
	return $fa_icons;
}


// Hide upgrade notice for bundled plugin
function pgscore_remove_acfpro_update_($value) {
	global $pagenow;	
	if( isset($value->response) && $pagenow!='themes.php'){
		unset( $value->response[ 'advanced-custom-fields-pro/acf.php' ] );
	}
	return $value;
}
add_filter('site_transient_update_plugins', 'pgscore_remove_acfpro_update_');

/* Set the theme acf plugin path in update package */
add_filter('acf/updates/plugin_update', 'pgscore_update_acfpro_plugin', 11,2);
function pgscore_update_acfpro_plugin( $update, $transient){
	if( function_exists('acf_pro_is_license_active') && !acf_pro_is_license_active() && is_object($update) ) {
		$update->package = get_template_directory_uri() . '/includes/plugins/advanced-custom-fields-pro.zip';
	}
	
	
	return $update;
}