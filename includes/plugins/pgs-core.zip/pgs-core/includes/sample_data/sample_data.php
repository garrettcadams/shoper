<?php
global $pgscore_globals;

add_filter( 'pgscore_reduxframework_data', 'pgscore_sample_data_section', 9999 );
function pgscore_sample_data_section( $pgscore_reduxframework_data ){
	
	$sample_data_desc = '';
	
	$pgscore_sample_data_description = trim(pgscore_sample_data_description());
	if( !empty($pgscore_sample_data_description) ){
		$sample_data_desc = $pgscore_sample_data_description;
	}

	$sample_data_desc_mandetory = '<p><span style="color:#FF0000;">' . wp_kses( __( 'Please take a backup before importing any sample data to prevent any data loss during installation.', 'pgs-core' ),
		array(
			'br'    => array(),
			'strong'=> array(
				'style' => array(),
			),
		)
	).'</span></p>';

	$fields = array();
	$auth_token = Ciyashop_Theme_Activation::ciyashop_verify_theme();
	if($auth_token !== false ){
		$fields[] = array(
			'id'        => 'pgscore_sample_data_import',
			'type'      => 'tc_sample_import',
			'full_width'=> true,
		);
	}else{
		$fields[] = array(
			'id'    => 'sample_data_license_notice',
			'type'  => 'info',
			'style' => 'critical',
			'desc'  => esc_html__('To access sample data, please validate and activate the purchase code, received from ThemeForest while purchased the theme.', 'pgs-core' ),
			'icon'  => 'fa fa-exclamation-triangle',
		);
	}
	
	$pgscore_reduxframework_data['sections'][] = array(
		'title'  => esc_html__( 'Sample Data', 'pgs-core' ),
		'desc'   => $sample_data_desc.$sample_data_desc_mandetory,
		'id'     => 'sample_data',
		'icon'   => 'fa fa-database',			
		'fields' => $fields
	);
	
	return $pgscore_reduxframework_data;
}

function pgscore_sample_data_description(){
	$pgscore_sample_data_description = '';
	
	$pgscore_sample_data_description = apply_filters( 'pgscore_sample_data_description', '' );
	
	return $pgscore_sample_data_description;
}

function pgscore_theme_sample_import_field_completed(){
	echo '<div class="admin-demo-data-notice notice-green" style="display:none;"><strong>'.esc_html__( 'Successfully installed demo data.', 'pgs-core' ).'</strong>' . '</div>';
	echo '<div class="admin-demo-data-reload notice-red" style="display: none;"><strong>'.esc_html__( 'Please wait... reloading page to load changes.', 'pgs-core' ).'</strong></div>';
}
add_action( "redux/options/{$pgscore_globals['option_opt_name']}/settings/change",'pgscore_theme_sample_import_field_completed');

// Prepapre Sample Data folder details
function pgscore_theme_sample_datas(){
	
	return apply_filters( 'pgscore_theme_sample_datas', array() );
	
}

add_action( 'wp_ajax_theme_import_sample', 'pgscore_theme_import_sample' );
function pgscore_theme_import_sample(){
	global $pgscore_globals;
	
	$action_source = 'default';
	if( isset($_REQUEST['action_source']) && $_REQUEST['action_source'] == 'wizard' ){
		$action_source = 'wizard';
	}
	
	// First check the nonce, if it fails the function will break	
	if ( ! wp_verify_nonce( $_REQUEST['nonce'], "sample_data_security" ) ) {
		if( $action_source == 'wizard' ){
			esc_html_e( 'Something went wrong please try again.', 'pgs-core' );
		}else{
			echo json_encode( array(
				'status' => esc_html__( 'Invalid sample data security credential. Please reload the page and try again.', 'pgs-core' ),
				'action' => ''
			) );
		}
		die();
	}
	ob_start();
	// Nonce is checked, get the posted data and process further
	$sample_id = isset($_REQUEST['sample_id']) ? $_REQUEST['sample_id'] : '';
	
	if( empty($sample_id) ){
		if( $action_source == 'wizard' ){
			$ajax_msg = esc_html__( 'Something went wrong please try again.', 'pgs-core' );
		}else{
			$ajax_data = array(
				'status'      => false,
				'message'     => esc_html__('Invalid Sample.','pgs-core'),
				'message_type'=> 'warning',
			);
		}
	}else{
		global $wpdb;
		
		if ( current_user_can( 'manage_options' ) ) {
			
			if ( !defined('WP_LOAD_IMPORTERS') ) define('WP_LOAD_IMPORTERS', true); // we are loading importers

			if ( ! class_exists( 'WP_Importer' ) ) { // if main importer class doesn't exist
				$wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
				include $wp_importer;
			}
			
			$importer_path = trailingslashit(PGSCORE_PATH) . 'includes/importer/importer.php';
			if( file_exists( $importer_path ) ){
				require_once($importer_path);
			}
			
			if ( class_exists( 'WP_Importer' ) && class_exists( 'Pgscore_Helper_WP_Import' ) ) { // check for main import class and wp import class
				$pgscore_sample_datas = pgscore_theme_sample_datas();
				$sample_params =  $pgscore_sample_datas[$sample_id];
				
				// Prepapre Data Files
				$sample_data_main_data_file     = $sample_params['data_dir'].'sample_data.xml';
				$sample_data_redux_options_file = $sample_params['data_dir'].'theme_options.json';
				$sample_data_widget_file        = $sample_params['data_dir'].'widget_data.json';
				$sample_data_rev_path           = untrailingslashit($sample_params['data_dir']).'/revsliders/';
				
				/******************************************
				 * Import Main Data
				 ******************************************/
				// Import Data
				if( file_exists($sample_data_main_data_file) ){
					$importer = new Pgscore_Helper_WP_Import();
					
					// Import Posts, Pages, Portfolio Content, FAQ, Images, Menus
					$importer->fetch_attachments = true;
					
					$stat = $importer->import($sample_data_main_data_file);
					
					flush_rewrite_rules();
				
					// Import Menus
					// Set imported menus to registered theme locations
					$locations = get_theme_mod( 'nav_menu_locations' ); // registered menu locations in theme
					$registered_menus = wp_get_nav_menus(); // registered menus
					
					// Assign Menu Name to Registered menus as array keys
					$registered_menus_new = array();
					foreach( $registered_menus as $registered_menu ){
						$registered_menus_new[$registered_menu->name] = $registered_menu;
					}
					
					// Assgin Menus to provided locations
					if( !empty($sample_params['menus']) && is_array($sample_params['menus']) ){
						foreach( $sample_params['menus'] as $menu_loc => $menu_nm ){
							$reg_menu_data = $registered_menus_new[$menu_nm];
							$locations[$menu_loc] = $reg_menu_data->term_id;
						}
					}
					
					set_theme_mod( 'nav_menu_locations', $locations ); // set menus to locations
				}
				
				WP_Filesystem();
				global $wp_filesystem;
				
				/******************************************
				 * Import Theme Options
				 ******************************************/
				if( file_exists($sample_data_redux_options_file) ){
					$redux_options_json = $wp_filesystem->get_contents( $sample_data_redux_options_file );
					$redux_options = json_decode( $redux_options_json, true );
					
					global $pgscore_array_replace_data;
					$pgscore_array_replace_data['old'] = $sample_params['demo_url'];
					$pgscore_array_replace_data['new'] = home_url( '/' );
					$redux_options = array_map("pgscore_replace_array", $redux_options);
					
					update_option( $pgscore_globals['option_opt_name'], $redux_options );
					do_action( 'pgs_core_sample_data_import_theme_options', $redux_options );
				}
				
				/******************************************
				 * Import Widget Data
				 ******************************************/
				if( file_exists( $sample_data_widget_file ) ){
					if( !function_exists('pgscore_import_widget_data') ){
						$widget_import = trailingslashit(PGSCORE_PATH) . 'includes/lib/widget-importer-exporter/widget-import.php';
						if( file_exists( $importer_path ) ){
							include($widget_import);
						}
					}
					$widget_data_json = $wp_filesystem->get_contents( $sample_data_widget_file );
					$widget_data = json_decode( $widget_data_json );
					
					$pgscore_widget_import_results = pgscore_import_widget_data( $widget_data );
				}
				
				/******************************************
				 * Import Revolution Sliders
				******************************************/
				// Check if "revsliders" folder exists
				if( file_exists( $sample_data_rev_path ) && is_dir( $sample_data_rev_path ) ){
					$sample_data_rev_sliders_path = pgscore_get_file_list( 'zip', $sample_data_rev_path );
					if( is_array($sample_data_rev_sliders_path) && !empty($sample_data_rev_sliders_path) && class_exists('UniteFunctionsRev') ){
						$pgscore_revslider = new RevSlider();
						foreach( $sample_data_rev_sliders_path as $sample_data_rev_slider_path ) {
							ob_start();
							$pgscore_revslider->importSliderFromPost(true, false, $sample_data_rev_slider_path);
							ob_clean();
							ob_end_clean();
						}
					}
				}
				
				/******************************************
				 * Set Default Pages
				 ******************************************/
				// Home Page
				update_option('show_on_front', 'page');
				if( isset($sample_params['home_page']) ) {
					$sample_param_home_page = trim($sample_params['home_page']);
					if( !empty($sample_param_home_page) ){
						$home_page = get_page_by_title( $sample_param_home_page );
						if( isset($home_page) && $home_page->ID ) {
							update_option('page_on_front', $home_page->ID); // Front Page
						}
					}
				}
				// Blog Page
				if( isset($sample_params['blog_page']) ){
					$sample_param_blog_page = trim($sample_params['blog_page']);
					if( !empty($sample_param_blog_page) ){
						$blog_page = get_page_by_title( $sample_params['blog_page'] );
						if( isset($blog_page) && $blog_page->ID ) {
							update_option('page_for_posts', $blog_page->ID); // Posts Page
						}
					}
				}
				if( $action_source == 'wizard' ){
					$ajax_msg = esc_html__('Successfully imported!','pgs-core');
				}else{
					$ajax_data = array(
						'status'      => true,			
					);
				}
			}else{
				if( $action_source == 'wizard' ){
					$ajax_msg = esc_html__('Import class could not be loaded. Please use WordPress Importer to import sample XML manually located in theme folder.','pgs-core');
				}else{
					$ajax_data = array(
						'status'      => false,
						'message'     => esc_html__('Import class not found.', 'pgs-core'),
						'message_type'=> 'warning',
					);
				}
			}
		}else{
			if( $action_source == 'wizard' ){
				$ajax_msg = esc_html__('You are not allowed to perform this action.','pgs-core');
			}else{
				$ajax_data = array(
					'status'      => false,
					'message'     => esc_html__('You are not allowed to perform this action.','pgs-core'),
					'message_type'=> 'warning',
				);
			}
		}
	}
	$import_result = ob_get_clean();
	if( $action_source == 'wizard' ){
		// echo $ajax_msg;
		// echo $import_result;
	}
	$ajax_data['message'] = '<p><strong>'.esc_html__('Successfully imported!', 'pgs-core').'</strong></p>';
	// echo json_encode($ajax_data);
	wp_send_json($ajax_data);
    die();
}

function pgscore_replace_array($n){
	global $pgscore_array_replace_data;
	
	if( is_array($n) ){
		return array_map("pgscore_replace_array", $n);
	}else{
		if( !empty($pgscore_array_replace_data) && is_array($pgscore_array_replace_data) && isset($pgscore_array_replace_data['old'])&& isset($pgscore_array_replace_data['new']) ){
			if (strpos($n, $pgscore_array_replace_data['old']) !== false) {
				return str_replace($pgscore_array_replace_data['old'],$pgscore_array_replace_data['new'],$n);
			}else{
				return $n;
			}
		}else{
			return $n;
		}
	}
    return $n;
}

add_action( 'wp_update_nav_menu_item', 'pgscore_import_custom_menu_metafields', 10, 3 );
function pgscore_import_custom_menu_metafields( $menu_id, $menu_item_db_id, $args ){
	$pgscore_megamenu_data['tc_megamenu_enable'] = 1;
	update_term_meta($menu_id, '_tc_megamenu_settings', $pgscore_megamenu_data);
	
	$custom_fields = array(
		'disable_link',
		'mega_menu',
		'content_type',
		'menu_width',
		'column_count',
		'menu_alignment',
	);
	
	foreach( $custom_fields as $custom_field ){
		if( !empty($args[$custom_field]) ){
			update_post_meta( $menu_item_db_id, $custom_field, $args[$custom_field] );
		}
	}
}

function pgscore_sample_import_templates() {
	include_once trailingslashit(PGSCORE_PATH) . "includes/sample_data/templates/sample-import-alert.php";
}
add_action( "admin_footer", "pgscore_sample_import_templates" );

function pgscore_sample_data_requirements(){
	return apply_filters( 'pgscore_sample_data_requirements', array(
		'memory-limit'      => esc_html__( 'Memory Limit: 512mb', 'pgs-core' ),
		'max-execution-time'=> esc_html__( 'Max Execution Time: 600 Seconds', 'pgs-core' ),
	) );
}

function pgscore_sample_data_required_plugins_list(){
	global $pgscore_globals;
	
	$pgscore_tgmpa_plugins_data_func = str_replace('-', '_', $pgscore_globals['current_theme_slug']."_tgmpa_plugins_data" );
	
	$required_plugins_list = array();
	
	if( function_exists($pgscore_tgmpa_plugins_data_func) ){
		$pgscore_tgmpa_plugins_data = $pgscore_tgmpa_plugins_data_func();
		
		$pgscore_tgmpa_plugins_data_all = $pgscore_tgmpa_plugins_data['all'];
		foreach( $pgscore_tgmpa_plugins_data_all as $pgscore_tgmpa_plugins_data_k => $pgscore_tgmpa_plugins_data_v ){
			if( !$pgscore_tgmpa_plugins_data_v['required'] ){
				unset($pgscore_tgmpa_plugins_data_all[$pgscore_tgmpa_plugins_data_k]);
			}
		}
		
		if( !empty($pgscore_tgmpa_plugins_data_all) && is_array($pgscore_tgmpa_plugins_data_all) ){
			foreach( $pgscore_tgmpa_plugins_data_all as $pgscore_tgmpa_plugin ){
				$required_plugins_list[] = $pgscore_tgmpa_plugin['name'];
			}
		}
	}
	
	return $required_plugins_list;
}