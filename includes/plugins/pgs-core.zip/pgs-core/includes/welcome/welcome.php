<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Pgs_Core_System_Status' ) ) {
	require_once dirname( __FILE__ ) . '/inc/class.system-status.php';
}

// Don't duplicate me!
if ( ! class_exists( 'Pgs_Core_Welcome' ) ) {

	class Pgs_Core_Welcome {
		
		public $args            = array();
		public $sections        = array();
		public $theme_data      = array();
		
		protected $current_tab  = '';
		protected $system_status= '';
		
		public function __construct( $sections = array(), $args = array() ) {
			
			$current_template = get_template();
			$this->theme_data = wp_get_theme($current_template);
			$this->theme_slug = sanitize_title( $current_template );
			$this->theme_id   = str_replace( '-', '_', $current_template );
			
			// Set values
			$this->set_default_args();
			$this->args = wp_parse_args( $args, $this->args );
			
			if ( empty ( $this->args['slug'] ) ) {
				$this->args['slug'] = 'pgs-welcome';
			}
			
			if ( empty ( $this->args['menu_title'] ) ) {
				$this->args['menu_title'] = $this->theme_data['Name'];
			}
			
			if ( empty ( $this->args['page_title'] ) ) {
				$this->args['page_title'] = $this->theme_data['Name'];
			}
			
			if ( empty ( $this->args['class_prefix'] ) ) {
				$this->args['class_prefix'] = $this->theme_slug;
			}
			
			/**
			 * filter 'pgs-sections-sections'
			 *
			 * @deprecated
			 *
			 * @param  array $sections field option sections
			 */
			$this->sections = apply_filters( 'pgs-welcome-sections', $sections );
			
			// Return if sections is empty.
			if( empty($this->sections) ){
				return;
			}
			
			$this->current_tab = $this->get_current_tab();
			
			$this->system_status = new Pgs_Core_System_Status();
			
			add_action( 'admin_menu', array( $this, 'create_settings' ), 9 );
		}
		
		private function set_default_args() {
			$this->args = array(
				'slug'              => 'pgs-welcome',
				'menu_title'        => '',                                                                           // menu title
				'page_title'        => '',                                                                           // page title
				'screen_title'      => sprintf( esc_html__( 'Welcome to %s', 'pgs-core'), $this->theme_data['Name']),// page title
				'menu_icon'         => get_parent_theme_file_uri() . '/images/admin/admin-icon.png',                 // menu icon
				'class_prefix'      => '',                                                                           // class prefix
				'templates_path'    => get_parent_theme_file_path() . '/includes/welcome/templates',                 // Path to the templates file for sections
				'templates_uri'     => get_parent_theme_file_uri() . '/includes/welcome/templates',                  // URL to the templates file for sections
				'page_permissions'  => 'manage_options',
				'page_priority'     => 2,

				'admin_bar'         => true,
				'admin_bar_priority'=> 999,                                                                          // Show the panel pages on the admin bar
				'admin_bar_icon'    => '',                                                                           // admin bar icon
				'help_tabs'         => array(),
				'help_sidebar'      => '',
			);
		}
		
		public function create_settings() {
			add_menu_page(
				$this->args['page_title'],       // Page Title
				$this->args['menu_title'],       // Menu Title
				$this->args['page_permissions'], // Capability
				$this->args['slug'],             // Slug
				array($this, 'settings_content'),// Callback
				$this->args['menu_icon'],        // Icon
				$this->args['page_priority']     // Position
			);
			
			$tabs_sr = 0;
			$custom_links = array();
			global $submenu;
			
			foreach( $this->sections as $tab ){
				
				if( $tabs_sr == 0 ){
					$url = $this->args['slug'];
				}else{
					$url = $this->args['slug'].'__'.sanitize_text_field($tab['slug']);
				}
				
				add_submenu_page(
					$this->args['slug'],
					$tab['title'],
					$tab['title'],
					$this->args['page_permissions'],
					$url,
					array($this, 'settings_content')
				);
				
				if( isset($tab['link_type']) && $tab['link_type'] == 'custom' ){
					
					$custom_links[$tabs_sr] = array(
						'index' => $tabs_sr,
						'link'  => $tab['link'],
					);
				}
				$tabs_sr++;
			}
			
			foreach( $custom_links as $custom_link_k => $custom_link ){
				if( isset($submenu[$this->args['slug']]) ){
					$submenu[$this->args['slug']][$custom_link_k] = array(
						$submenu[$this->args['slug']][$custom_link_k][0],
						$submenu[$this->args['slug']][$custom_link_k][1],
						$custom_link['link'],
					);
				}
			}
		}
		
		public function settings_content() {
			
			$current_tab  = $this->current_tab;
			$class_prefix = $this->args['class_prefix'];
			
			$tab_content_classes = array(
				$class_prefix.'-admin-tab_content',
				$class_prefix.'-admin-tab_content_'.$current_tab,
			);
			?>
			<div class="wrap <?php echo esc_attr($class_prefix);?>-welcome">
				<div class="<?php echo esc_attr($class_prefix);?>-welcome-header">
					<h1 class="wp-heading-inline"><?php echo esc_html__( $this->args['screen_title'] );?></h1>
					<hr>
					<?php settings_errors(); ?>
					
					<div class="<?php echo esc_attr($class_prefix);?>-welcome-description">
						<?php $this->get_template( 'header.php');?>
					</div>
					
					<div class="<?php echo esc_attr($class_prefix);?>-welcome-badge <?php echo esc_attr( $this->welcome_logo() ? $class_prefix.'-welcome-badge-with-logo' : $class_prefix.'-welcome-badge-without-logo' );?>">
						<div class="wp-badge"><?php
							if( !$this->welcome_logo() ){
								echo esc_html($this->theme_data['Name']);
							}
						?></div>
						<div class="<?php echo esc_attr($class_prefix);?>-welcome-badge-version">
							<?php echo sprintf( esc_html__('Version %s', 'pgs-core'), $this->theme_data['Version'] );?>
						</div>
					</div>
				</div>
				<div class="<?php echo esc_attr($class_prefix);?>-welcome-content">
					<div class="<?php echo esc_attr($class_prefix);?>-admin-tabs">
						<?php $this->admin_tabs();?>
					</div>
				
					<?php $tab_content_classes = implode( ' ', array_filter( array_unique( $tab_content_classes ) ) );?>
				
					<div class="<?php echo esc_attr($tab_content_classes);?>">
						<?php
						settings_fields( $this->theme_id.'_welcome' );
						do_settings_sections( $this->theme_id.'_welcome' );
						?>
						<div class="<?php echo esc_attr($class_prefix);?>-admin-tab_content_inner">
							<div class="<?php echo esc_attr($this->current_tab.'-content');?>">
								<?php $this->get_template( "$current_tab.php");?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php
		}
		
		function welcome_logo(){
			$welcome_logo = get_parent_theme_file_uri() . '/images/admin/welcome-logo.png';
			$welcome_logo_path = get_parent_theme_file_path() . '/images/admin/welcome-logo.png';
			if( file_exists($welcome_logo_path) && getimagesize($welcome_logo_path) !== false ) {
				return $welcome_logo;
			}else{
				return false;
			}
		}
		
		function get_current_page(){
			
			$current_page = '';
			
			if( isset($_GET['page']) && $_GET['page'] != '' ){
				$current_page = $_GET['page'];
			}else{
				$current_page = $this->args['slug'];
			}
			
			return $current_page;
		}
		
		function get_current_tab(){
			
			$current_tab  = $this->args['slug'];
			$current_page = $this->get_current_page();
			$tabs = $this->sections;
			
			if( $current_tab == $current_page ){
				$current_tab = $tabs[0]['slug'];
			}else{
				$current_tab = str_replace( $current_tab.'__', '', $current_page );
			}
			
			return $current_tab;
		}
		
		function admin_tabs() {
			
			$tabs = $this->sections;
			
			$current_page = $this->get_current_page();
			
			?>
			<h2 class="nav-tab-wrapper">
				<?php
				$tabs_sr = 1;
				foreach( $tabs as $tab_k => $tab ){
					if( $tabs_sr == 1 ){
						$tab_slug = $this->args['slug'];
					}else{
						$tab_slug = $this->args['slug'].'__'.sanitize_text_field($tab['slug']);
					}
					
					$classes = array(
						'nav-tab',
					);
					$classes[] = 'nav-tab-'.$tab['slug'];
					
					$url = $this->tab_url( $tab_slug );
					
					if( isset($tab['link_type']) && $tab['link_type'] == 'custom' ){
						
						$url = $tab['link'];
						
					}
					
					if( $current_page == $tab_slug ) {
						$classes[] = 'nav-tab-active';
					}
					$classes = implode( ' ', array_filter( array_unique( $classes ) ) );
					?>
					<a class="<?php echo esc_attr($classes);?>" href="<?php echo esc_url($url);?>"><?php echo esc_html($tab['title']);?></a>
					<?php
					$tabs_sr++;
				}
				?>
			</h2>
			<?php
		}
		
		function tab_url( $tab ){
			return "?page={$tab}";
		}
		
		function get_template( $template_name, $args = array() ) {
			
			$templates_path = $this->args['templates_path'];
			
			if ( ! empty( $args ) && is_array( $args ) ) {
				extract( $args );
			}
			
			$located = $this->locate_template( $template_name, $templates_path );

			// Allow 3rd party plugin filter template file from their plugin.
			$located = apply_filters( 'cs_admin_get_template', $located, $template_name, $args, $templates_path );

			do_action( 'cs_admin_before_template_part', $template_name, $templates_path, $located, $args );

			if( file_exists($located) ){
				include $located;
			}

			do_action( 'cs_admin_after_template_part', $template_name, $templates_path, $located, $args );
		}
		
		function locate_template( $template_name, $templates_path = '' ) {
			
			// Look within passed path within the theme - this is priority.
			$template = locate_template(
				array(
					trailingslashit( $templates_path ) . $template_name
				)
			);
			
			$template = trailingslashit( $templates_path ) . $template_name;
			
			// Return what we found.
			return apply_filters( 'cs_admin_locate_template', $template, $template_name, $templates_path );
		}
		
	}
}