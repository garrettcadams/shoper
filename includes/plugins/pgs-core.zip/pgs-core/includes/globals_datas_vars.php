<?php
global $pgscore_globals, $pgscore_shortcodes, $PGSCore_ReduxFramework, $pgscore_current_theme_data;

// Set blank array
$pgscore_globals = array();

$pgscore_globals['pgscore_theme_support'] = false;

add_action( 'init', 'pgscore_theme_support_init', 0 );
function pgscore_theme_support_init(){
	global $pgscore_globals;
	
	if( current_theme_supports('pgs-core') ){
		$pgscore_globals['pgscore_theme_support'] = true;
	}
}

$pgscore_current_theme_data = pgscore_get_current_theme_data();

$pgscore_globals['option_title']      = $pgscore_current_theme_data->get('Name') . ' ' . esc_html__('Theme Options', 'pgs-core');
$pgscore_globals['option_slug']       = sanitize_title($pgscore_current_theme_data->get('Name')).'-options';
$pgscore_globals['option_opt_name']   = str_replace('-', '_', $pgscore_globals['option_slug']);
$pgscore_globals['current_theme_slug']= pgscore_get_current_theme_name();

function pgscore_get_current_theme_data(){
	return wp_get_theme( pgscore_get_current_theme_name() );
}
function pgscore_get_current_theme_name(){
	return get_template();
}

function pgscore_after_setup_theme() {
	add_image_size( 'pgscore-50x50', 50, 50, true );
	add_image_size( 'pgscore-thumbnail-80', 80, 80, true );
	
	add_image_size( 'pgscore-slider-thumbnail', 768, 501, true );
	add_image_size( 'pgscore-portfolio-thumbnail', 700, 500, true );
	add_image_size( 'pgscore-team-member-thumbnail', 220, 410, true );
	add_image_size( 'pgscore-recent-post-thumbnail', 600, 350, true );
	add_image_size( 'pgscore-recent-post-thumbnail-vertical', 500, 600, true );
}
add_action( 'after_setup_theme', 'pgscore_after_setup_theme' );