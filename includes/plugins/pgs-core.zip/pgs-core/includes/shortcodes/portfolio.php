<?php
/******************************************************************************
 * 
 * Shortcode : pgscore_portfolio
 * 
 ******************************************************************************/

// Return if custom post type is not supported
if( !current_theme_supports('pgs_portfolio') ) return;

function pgscore_shortcode_portfolio( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'style'                 => 'filterable',
		'count'                 => 10,
		'categories'            => '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	$args = array(
		'post_type'     => 'portfolio',
		'posts_per_page'=> $count,
	);
	
	if( !empty($categories) ){
		$categories_array = explode(',', $categories);
		if( is_array($categories_array) && !empty($categories_array) ){
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'portfolio-category',
					'field'    => 'term_id',
					'terms'    => $categories_array
				)
			);
		}
	}
	
	$the_query = new WP_Query( $args );
	if ( !$the_query->have_posts() ) {
		return;
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['the_query'] = $the_query;
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('portfolio/content' );?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 * 
 * Visual Composer Integration
 * 
 ******************************************************************************/
$portfolio_categories = pgscore_get_terms( array( // You can pass arguments from get_terms (except hide_empty)
	'taxonomy'  => 'portfolio-category',
	'pad_counts'  => true,
));

$shortcode_fields = array(
	array(
		'type'       => 'pgscore_number_min_max',
		'heading'    => esc_html__( "Count", 'pgs-core' ),
		'param_name' => 'count',
		'value'      => '10',
		'min'        => '1',
		'max'        => '100',
		'description'=> esc_html__('Enter number of portfolio items to display.','pgs-core'),
		'admin_label'=> true,
	),
	array(
		'type'       => 'checkbox',
		'heading'    => esc_html__('Categories', 'pgs-core'),
		'param_name' => 'categories',
		'description'=> esc_html__('Select categories to limit result from. To display result from all categories leave all categories unselected.', 'pgs-core'),
		'value'      => $portfolio_categories,
		'admin_label'=> true,
	),
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Portfolio", 'pgs-core' ),
	"description"            => esc_html__( "Display portfolio.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}