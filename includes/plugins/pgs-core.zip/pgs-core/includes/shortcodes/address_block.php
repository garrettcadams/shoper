<?php
/******************************************************************************
 * 
 * Shortcode : pgscore_address_block
 * 
 ******************************************************************************/
function pgscore_shortcode_address_block( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'shape'           => 'square',
		'style'           => 'border',
		'title'           => '',
		'sub_contents'    => '',
		'icon_type'       => 'fontawesome',
		'icon_fontawesome'=> 'fa fa-chevron-right',
		'icon_openiconic' => 'vc-oi vc-oi-right',
		'icon_typicons'   => 'typcn typcn-chevron-right',
		'icon_entypo'     => 'entypo-icon entypo-icon-right-open',
		'icon_linecons'   => 'vc_li vc_li-heart',
		'icon_monosocial' => 'vc-mono vc-mono-fivehundredpx',
		'icon_material'   => 'vc-material vc-material-cake',
		'icon_pixelicons' => 'vc_pixel_icon vc_pixel_icon-alert',
		'icon_flaticon'   => '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	$sub_contents = vc_param_group_parse_atts( $sub_contents );
	
	// Filter data without "subcontent_title"
	if( is_array($sub_contents) && !empty($sub_contents) ){
		foreach( $sub_contents as $sub_content_tk => $sub_content_td  ){
			if( empty($sub_content_td['subcontent_title']) ){
				unset($sub_contents[$sub_content_tk]);
			}
		}
	}else{
		$sub_contents = array();
	}
	
	/*********************************************
	 * 
	 * Return shortcode if no title or sub contents found.
	 * 
	 *********************************************/
	if( empty( $title ) && empty($sub_contents) ) {
		return;
	}
	
	/**********************************************************
	 * 
	 * Icons Settings
	 * 
	 **********************************************************/
	$icon_html = $icon_class = '';
	
	$add_icon = true;
	if( $add_icon ){
		$icon_wrapper = false;
		if ( isset( ${'icon_' . $icon_type} ) && !empty(${'icon_' . $icon_type}) ) {
			if ( 'pixelicons' === $icon_type ) {
				$icon_wrapper = true;
			}
			$icon_class = ${'icon_' . $icon_type};
		}
		
		if( $icon_class ){
			if ( $icon_wrapper ) {
				$icon_html = '<i class="icon_wrap"><span class="' . esc_attr( $icon_class ) . '"></span></i>';
			} else {
				$icon_html = '<i class="' . esc_attr( $icon_class ) . '"></i>';
			}
		
			// Enqueue icon CSS for icon type
			vc_icon_element_fonts_enqueue( $icon_type );
		}
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['sub_contents_data'] = $sub_contents;
	$pgscore_shortcodes[$shortcode_handle]['icon_html'] = $icon_html;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('address_block/content' );?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 * 
 * Visual Composer Integration
 * 
 ******************************************************************************/
$shortcode_fields = array(
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Style', 'pgs-core' ),
		'param_name' => 'style',
		'description'=> esc_html__( 'Select style.', 'pgs-core' ),
		'std'        => 'none',
		'value'      => array(
			esc_html__( 'Default', 'pgs-core' )=> 'default',
			esc_html__( 'Border', 'pgs-core' ) => 'border',
			esc_html__( 'Flat', 'pgs-core' )   => 'flat',
		),
		'admin_label' => true,
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Shape', 'pgs-core' ),
		'param_name' => 'shape',
		'description'=> esc_html__( 'Select icon shape.', 'pgs-core' ),
		'std'        => 'square',
		'value'      => array(
			esc_html__( 'Square', 'pgs-core' ) => 'square',
			esc_html__( 'Rounded', 'pgs-core' )=> 'rounded',
			esc_html__( 'Round', 'pgs-core' )  => 'round',
		),
		'admin_label' => true,
	),
	array(
		"type"        => "textfield",
		"heading"     => esc_html__( "Title", 'pgs-core' ),
		"param_name"  => "title",
		'admin_label' => true,
		'group'       => esc_html__( 'Content', 'pgs-core' ),
	),
	array(
		'type'            => 'param_group',
		"heading"         => esc_html__( "Sub Contents", 'pgs-core' ),
		'value'           => '',
		'param_name'      => 'sub_contents',
		'params'          => array(
			array(
				"type"        => "textfield",
				"heading"     => esc_html__( "Title", 'pgs-core' ),
				"param_name"  => "subcontent_title",
				'description' => esc_html__( 'Add content here.', 'pgs-core' ),
				'admin_label' => true,
			),
			array(
				'type'            => 'checkbox',
				'heading'         => esc_html__( 'Enable Link', 'pgs-core' ),
				'param_name'      => 'enable_link',
				'description'     => esc_html__( 'Enable link for the content.', 'pgs-core' ),
				'edit_field_class'=> 'vc_col-sm-4 vc_column',
			),
			array(
				'type'            => 'vc_link',
				'heading'         => esc_html__( 'Content Link', 'pgs-core' ),
				'param_name'      => 'custom_link',
				'description'     => esc_html__( 'Add link. For email use mailto:your.email@example.com.', 'pgs-core' ),
				'edit_field_class'=> 'vc_col-sm-4 vc_column',
				'dependency'      => array(
					'element' => 'enable_link',
					'value'   => 'true',
				)
			),
		),
		'group'    => esc_html__( 'Content', 'pgs-core' ),
	),
);

// Merge icon fields.
$shortcode_fields = array_merge(
	$shortcode_fields,
	pgscore_iconpicker()
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Address Block", 'pgs-core' ),
	"description"            => esc_html__( "Add address blocks.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}