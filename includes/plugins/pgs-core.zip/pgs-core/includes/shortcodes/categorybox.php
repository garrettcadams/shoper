<?php
/*
 * Shortcode : pgscore_categorybox
 */
function pgscore_shortcode_categorybox( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'title'              => '',
		'subtitle'           => '',
		'categories'         => '',
		'enable_archive_link'=> false,
		'archive_link'       => '',
		'category_box_bg'    => '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	
	extract($atts);
	
	if( empty($categories) ){
		return;
	}
	
	$categorybox_args = array(
		'taxonomy'     => 'product_cat',
		'orderby'      => 'name',
		'show_count'   => 0,
		'pad_counts'   => 0,
		'hierarchical' => 0,
		'title_li'     => '',
		'hide_empty'   => 0,
		'include'      => $categories,
    );
	
    $categorybox_categories = get_terms( $categorybox_args );
	
	if( empty($categorybox_categories) || is_wp_error($categorybox_categories) ){
		return;
	}
	
	/**********************************************************
	 *
	 * Element Classes
	 * For base wrapper
	 *
	**********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['categorybox_categories'] = $categorybox_categories;
	
    ob_start();
    ?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('categorybox/content' );?>
	</div><!-- shortcode-base-wrapper-end -->
    <?php
    return ob_get_clean();
}

if ( function_exists( 'vc_map' ) && is_admin() ) {
	/*
	 * Visual Composer Integration
	 */
	$shortcode_fields = array(
		array(
			"type"        => "textfield",
			"class"       => "",
			"heading"     => esc_html__( "Title", 'pgs-core' ),
			"param_name"  => "title",
			"admin_label"  => true,
		),
		array(
			"type"        => "textfield",
			"class"       => "",
			"heading"     => esc_html__( "Subtitle", 'pgs-core' ),
			"param_name"  => "subtitle",
			"admin_label"  => true,
		),
		array(
			'type'       => 'checkbox',
			'heading'    => esc_html__('Categories', 'pgs-core'),
			'param_name' => 'categories',
			'description'=> esc_html__('Select categories to display on front. If no categories selected, it will not display the complete box on front.', 'pgs-core'),
			'value'      => pgscore_get_terms( array( // You can pass arguments from get_terms (except hide_empty)
				'taxonomy'   => 'product_cat',
				'pad_counts' => true,
			)),
			'admin_label'=> true,
		),
		array(
			'type'      => 'checkbox',
			"heading"   => esc_html__("Display View All Link?", 'pgs-core'),
			'param_name'=> 'enable_archive_link',
		),
		array(
			"type"        => "vc_link",
			"class"       => "",
			"heading"     => esc_html__("Link", 'pgs-core'),
			"description" => esc_html__("Select/enter url.", 'pgs-core'),
			"param_name"  => "archive_link",
			'dependency' => array(
				'element'=> 'enable_archive_link',
				'value'  => 'true',
			),
		),
		array(
			'type'       => 'attach_image',
			'heading'    => __( 'Background Image', 'pgs-core' ),
			'param_name' => 'category_box_bg',
			'description'=> esc_html__( 'Select background image from media library.', 'pgs-core' ),
			'group'      => esc_html__( 'Background', 'pgs-core' ),
			"holder"    => "img",
		),
	);

	$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

	// Params
	$params = array(
		"name"                   => esc_html__( "Category Box", 'pgs-core' ),
		"description"            => esc_html__( "Display category box.", 'pgs-core'),
		"base"                   => $shortcode_tag,
		"class"                  => "pgscore_element_wrapper",
		"controls"               => "full",
		"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
		"category"               => esc_html__('Potenza Core', 'pgs-core'),
		"show_settings_on_create"=> true,
		"params"                 => $shortcode_fields,
	);

	vc_map( $params );
}