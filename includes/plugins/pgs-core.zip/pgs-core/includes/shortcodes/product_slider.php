<?php
if( ! (function_exists('is_plugin_active') && is_plugin_active('woocommerce/woocommerce.php') ) ) return;
/******************************************************************************
 *
 * Shortcode : pgscore_product_slider
 *
 ******************************************************************************/
function pgscore_shortcode_product_slider( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'add_icon'        => false,
		'icon_type'       => 'fontawesome',
		'icon_fontawesome'=> 'fa fa-info-circle',
		'icon_openiconic' => 'vc-oi vc-oi-dial',
		'icon_typicons'   => 'typcn typcn-adjust-brightness',
		'icon_entypo'     => 'entypo-icon entypo-icon-note',
		'icon_linecons'   => 'vc_li vc_li-heart',
		'icon_monosocial' => 'vc-mono vc-mono-fivehundredpx',
		'icon_material'   => 'vc-material vc-material-cake',
		'icon_pixelicons' => 'vc_pixel_icon vc_pixel_icon-alert',
		'icon_flaticon'   => '',
		'number_of_item'  => 5,
		"custom_title"    => '',
		"pro_cat_slug"    => '',
		'product_type'    => 'pgs_new_arrivals',
		'slider_items'    => 6,
		'slides_per_view_xx'=> '',
		'slides_per_view_xs'=> '',
		'slides_per_view_sm'=> '',
		'slides_per_view_md'=> '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	$args = array(
		'post_type'     => 'product',
		'posts_status'  => 'publish',
		'posts_per_page'=> ( isset($number_of_item) && !empty($number_of_item) ) ? $number_of_item : 5,
	);
	if( $pro_cat_slug != '' ){
		$args['tax_query'] = array(
			array(
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => explode( ',' , $pro_cat_slug),
			),
		);
	}
	
	/* Featured product */
	if( $product_type == 'pgs_featured' ){
		$args['meta_query']=array(
			array(
				'key'     => '_featured',
				'value'   => 'yes',
				'compare' => '='
			),
		);
		
	/* On Sale product */
	}elseif( $product_type == 'pgs_on_sale' ){
		$args['meta_query'] = array(
			array(
				'key'     => '_sale_price',
				'value'   => '',
				'compare' => '!='
			),
		);
		
	/* Best Sellers Product */
	}elseif( $product_type == 'pgs_best_sellers' ){
		unset( $args['meta_query'] );
		
		$args['meta_key']      = 'total_sales';
		$args['meta_value_num']= 'total_sales';
		$args['orderby']       = 'meta_value_num';
		$args['order']         = 'DESC';
		
	/* Cheapest Product */
	}elseif($product_type=='pgs_cheapest'){
		unset($args['meta_query']);
		
		$args['meta_key']      = '_price';
		$args['meta_value_num']= '_price';
		$args['orderby']       = 'meta_value_num';
		$args['order']         = 'ASC';
	}
	
	$loop = new WP_Query( $args );
	if ( !$loop->have_posts() ) {
		return;
	}
	
	// Set Icon
	$icon = '';
	if( !empty($add_icon) ){
		if ( isset( ${'icon_' . $icon_type} ) && !empty(${'icon_' . $icon_type}) ) {
			$icon = ${'icon_' . $icon_type};
			vc_icon_element_fonts_enqueue( $icon_type );
		}
	}
	
	$cust_titles = array(
		'pgs_new_arrivals'=> esc_html__('New Arrivals', 'pgs-core'),
		'pgs_featured'    => esc_html__('Featured', 'pgs-core'),
		'pgs_best_sellers'=> esc_html__('Best Sellers', 'pgs-core'),
		'pgs_on_sale'     => esc_html__('On Sale', 'pgs-core'),
	);
	
	if( empty($custom_title) ){
		$custom_title = $cust_titles[$product_type];
	}
	
	/**********************************************************
	 *
	 * Element Classes
	 * For base wrapper
	 *
	**********************************************************/
	$atts['element_classes'] = array();
	
	$atts['custom_title'] = $custom_title;
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['loop'] = $loop;
	if( isset($icon) ){
		$pgscore_shortcodes[$shortcode_handle]['icon'] = $icon;
	}
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('product_slider/content' );?>
	</div><!-- shortcode-base-wrapper-end -->
	<?php
	return ob_get_clean();
}

/******************************************************************************
 *
 * Visual Composer Integration
 *
 ******************************************************************************/
$pgscore_iconpicker_args = array(
	'dependency' => array(
		'element'=> 'add_icon',
		'value'  => 'true',
	),
);

$shortcode_fields = array_merge(
	array(
		array(
			"type"        => "textfield",
			"class"       => "",
			"heading"     => esc_html__("Title", 'pgs-core'),
			"param_name"  => "custom_title",
			'admin_label' => true,
		),
		array(
			'type'       => 'checkbox',
			'heading'    => esc_html__('Categories', 'pgs-core'),
			'param_name' => 'pro_cat_slug',
			'description'=> esc_html__('Select categories to limit result from. To display result from all categories leave all categories unselected.', 'pgs-core'),
			'value'      => pgscore_get_terms( array( // You can pass arguments from get_terms (except hide_empty)
				'taxonomy'   => 'product_cat',
				'pad_counts' => true,
			)),
			'admin_label'=> true,
		),
		array(
			'type'       => 'dropdown',
			'heading'    => esc_html__( 'Product Type', 'pgs-core' ),
			'param_name' => 'product_type',
			'description'=> esc_html__( 'Select product type. which type of product want to display on front page', 'pgs-core' ),
			'value'      => array(
				esc_html__('New Arrivals', 'pgs-core')=>'pgs_new_arrivals',
				esc_html__('Featured', 'pgs-core')    =>'pgs_featured',
				esc_html__('Best Sellers', 'pgs-core')=>'pgs_best_sellers',
				esc_html__('On Sale', 'pgs-core')     =>'pgs_on_sale',
				esc_html__('Cheapest', 'pgs-core')    =>'pgs_cheapest',
			),
			'save_always' => true,
			'admin_label'=> true,
		),
		array(
			"type"        => "textfield",
			"class"       => "",
			"heading"     => esc_html__("Number of item", 'pgs-core'),
			"param_name"  => "number_of_item",
			'admin_label' => true,
		),
		array(
			'type'      => 'checkbox',
			'heading'   => esc_html__( 'Add icon?', 'pgs-core' ),
			'param_name'=> 'add_icon',
		),
	),
	pgscore_iconpicker($pgscore_iconpicker_args),
	array(
		array(
			'type'            => 'pgscore_number_min_max',
			'heading'         => esc_html__( "Slides Per View", 'pgs-core' ),
			'param_name'      => 'slider_items',
			'min'             => 1,
			'max'             => 6,
			'value'           => 6,
			// 'suffix'          => 'px',
			'description'     => esc_html__('Enter number of slides to display per view.', 'pgs-core'),
			'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		),
		array(
			'type'            => 'pgscore_heading',
			'heading'         => '',
			'param_name'      => 'responsive_slide_counts_header',
			'title'           => esc_html__('Responsive slide counts','pgs-core'),
			'title_el'        => 'h5',
			'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		),
		array(
			'type'            => 'pgscore_number_min_max',
			'heading'         => esc_html__('Slides per view ( < 480px)','pgs-core'),
			'param_name'      => 'slides_per_view_xx',
			'min'             => '1',
			'max'             => '10',
			'description'     => esc_html__( 'Enter number of slides to display at the same time.', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-3 vc_column',
			'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		),
		array(
			'type'            => 'pgscore_number_min_max',
			'heading'         => esc_html__('Slides per view ( < 768px)','pgs-core'),
			'param_name'      => 'slides_per_view_xs',
			'min'             => '1',
			'max'             => '10',
			'description'     => esc_html__( 'Enter number of slides to display at the same time.', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-3 vc_column',
			'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		),
		array(
			'type'            => 'pgscore_number_min_max',
			'heading'         => esc_html__('Slides per view ( < 992px)','pgs-core'),
			'param_name'      => 'slides_per_view_sm',
			'min'             => '1',
			'max'             => '10',
			'description'     => esc_html__( 'Enter number of slides to display at the same time.', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-3 vc_column',
			'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		),
		array(
			'type'            => 'pgscore_number_min_max',
			'heading'         => esc_html__('Slides per view ( < 1200px)','pgs-core'),
			'param_name'      => 'slides_per_view_md',
			'min'             => '1',
			'max'             => '10',
			'description'     => esc_html__( 'Enter number of slides to display at the same time.', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-3 vc_column',
			'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		),
		array(
			'type'            => 'pgscore_html',
			'heading'         => esc_html__('Responsive slide counts','pgs-core'),
			'param_name'      => 'responsive_slide_counts_header',
			'html'            => '<h4>'.esc_html__( 'Note: Count entered in "Slides per view", will be used for device width above 1200px.', 'pgs-core' ).'</h4>',
			'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		),
	)
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Product Slider", 'pgs-core' ),
	"description"            => esc_html__( "Display product slider from selected category.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}