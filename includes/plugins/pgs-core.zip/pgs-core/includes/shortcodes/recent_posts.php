<?php
/******************************************************************************
 *
 * Shortcode : pgscore_recent_posts
 *
 ******************************************************************************/
function pgscore_shortcode_recent_posts( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'style'                  => 'style-1',
		'list_style'             => 'grid',
		'post_type'              => 'post',
		'posts_per_page'         => 10,
		'ignore_sticky_posts'    => true,
		'categories'             => '',
		'show_pagination_control'=> 'no',
		'show_prev_next_buttons' => 'no',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	$args = array(
		'post_type'          => $post_type,
		'post_status'        => array('publish'),
		'posts_per_page'     => $posts_per_page,
		'ignore_sticky_posts'=> $ignore_sticky_posts,
	);
	
	$categories = trim($categories);
	if( !empty($categories) ){
		$categories_array = explode(',', $categories);
		if( is_array($categories_array) && !empty($categories_array) ){
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'category',
					'field'    => 'term_id',
					'terms'    => $categories_array
				)
			);
		}
	}
	
	$the_query = new WP_Query( $args );
	if ( !$the_query->have_posts() ) {
		return;
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['the_query'] = $the_query;
	
	$list_classes = array();
	$list_classes[] = 'pgscore_recent_post_list';
	if( $list_style ){
		$list_classes[] = 'pgscore_recent_posts_list_style_'.esc_attr($list_style);
	}
	if( $style ){
		$list_classes[] = 'pgscore_recent_posts_style_'.esc_attr($style);
	}
	$list_classes = implode( ' ', array_filter( array_unique( $list_classes ) ) );
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<div class="<?php echo esc_attr($list_classes);?>">
			<?php pgscore_get_shortcode_templates('recent_posts/content', $list_style );?>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 *
 * Visual Composer Integration
 *
 ******************************************************************************/
$recent_post_categories = pgscore_get_terms( array( // You can pass arguments from get_terms (except hide_empty)
	'taxonomy'  => 'category',
	'pad_counts'  => true,
));

$categories_hierarchy = get_terms_hierarchy( 'category' );
$categories_flat = get_terms_hierarchical_list( $categories_hierarchy );
$categories_list = array();
foreach( $categories_flat as $term_id => $term ){
	// $categories_list[$term->name] = $term_id;
	// $categories_list[ str_repeat("- – —", $term->depth). $term->name ] = $term_id;
	$categories_list[ str_repeat("— ", $term->depth) . $term->name .' ('.$term->count.')' ] = $term_id;
}
$shortcode_fields = array(
	array(
		'type'            => 'pgscore_radio_image',
		"heading"         => esc_html__("Style", 'pgs-core'),
		'param_name'      => 'style',
		'options'         => pgscore_get_shortcode_param_data('recent_posts'),
		'show_label'      => true,
		'admin_label'     => true,
	),
	array(
		"type"        => "dropdown",
		"class"       => "",
		"heading"     => esc_html__("List Type", 'pgs-core'),
		"description" => esc_html__("Select list type.", 'pgs-core'),
		"param_name"  => "list_style",
		"value"       => array(
			esc_html__( "Grid", 'pgs-core' )      => 'grid',
			esc_html__( "Carousel", 'pgs-core' )  => 'carousel',
		),
		'admin_label'=> true,
	),
	array(
		'type'       => 'pgscore_number_min_max',
		'heading'    => esc_html__( "Count", 'pgs-core' ),
		'param_name' => 'posts_per_page',
		'value'      => '',
		'min'        => '2',
		'max'        => '10',
		'description'=> esc_html__('Enter number of posts to display.','pgs-core'),
		'admin_label'=> true,
	),
	array(
		'type'       => 'checkbox',
		'heading'    => esc_html__('Categories', 'pgs-core'),
		'param_name' => 'categories',
		'description'=> esc_html__('Select categories to limit result from. To display result from all categories leave all categories unselected.', 'pgs-core'),
		'value'      => $recent_post_categories,
		'admin_label'=> true,
	),
	array(
		'type'            => 'checkbox',
		'heading'         => esc_html__( 'Show Pagination Control', 'pgs-core' ),
		'param_name'      => 'show_pagination_control',
		'description'     => esc_html__( 'Check this to display pagination controls.', 'pgs-core' ),
		'value'           => array( esc_html__( 'Yes', 'pgs-core' )=> 'yes' ),
		'edit_field_class'=> 'vc_col-sm-6 vc_column',
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		'admin_label'     => true,
		'dependency'      => array(
			'element' => 'list_style',
			'value'   => 'carousel',
		)
	),
	array(
		'type'            => 'checkbox',
		'heading'         => esc_html__( 'Show Prev/Next Buttons', 'pgs-core' ),
		'param_name'      => 'show_prev_next_buttons',
		'description'     => esc_html__( 'Check this t display prev/next buttons.', 'pgs-core' ),
		'value'           => array( esc_html__( 'Yes', 'pgs-core' )=> 'yes' ),
		'edit_field_class'=> 'vc_col-sm-6 vc_column',
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		'admin_label'     => true,
		'dependency'      => array(
			'element' => 'list_style',
			'value'   => 'carousel',
		)
	),
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Recent Posts", 'pgs-core' ),
	"description"            => esc_html__( "Display recent posts.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}