<?php
/******************************************************************************
 *
 * Shortcode : pgscore_banner
 *
 ******************************************************************************/
function pgscore_shortcode_banner( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'style'                 => 'style-1',
		
		'font_size_responsive'  => '',
		'font_size'             => '70',
		'font_size_lg'          => '70',
		'font_size_md'          => '70',
		'font_size_sm'          => '50',
		'font_size_xs'          => '50',
		
		'vertical_align'        => 'vtop',
		'horizontal_align'      => 'hleft',
		'banner_effect'         => 'none',
		'bg_img'                => '',
		'banner_css'            => '',
		
		'list_items'            => '',
		
		'button_text'           => esc_html__('Click Here', 'pgs-core'),
		'button_style'          => 'link',
		'button_shape'          => 'square',
		'button_color'          => '#FF0000',
		'button_border_color'   => '#00FF00',
		'button_text_color'     => '#0000FF',
		// 'link_url'           => 'url:%23|||',
		'link_url'              => '|||',
		
		'add_badge'             => '',
		'badge_style'           => 'style-1',
		'badge_title'           => '',
		'badge_type'            => 'border',
		'badge_text_color'      => '#323232',
		'badge_background_color'=> '#ffffff',
		'badge_border_color'    => '#323232',
		'badge_width'           => '70',
		'badge_height'          => '70',
		'badge_vertical_align'  => 'vbottom',
		'badge_horizontal_align'=> 'hright',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	
	extract( $atts );
	
	/* banner image is empty then return  */
	$banner_image = wp_get_attachment_image_src($bg_img, "full");
	if( empty($banner_image[0]) ){
		return;
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	**********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['banner_image'] = $banner_image;
	$pgscore_shortcodes[$shortcode_handle]['show_hide_defaults'] = array( 'lg', 'md', 'sm', 'xs' );
	$pgscore_shortcodes[$shortcode_handle]['hide_classes'] = array( 'lg' => 'hidden-lg', 'md' => 'hidden-md', 'sm' => 'hidden-sm', 'xs' => 'hidden-xs' );
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('banner/content' );?>
	</div><!-- shortcode-base-wrapper-end -->
	<?php
	return ob_get_clean();
}

/******************************************************************************
 *
 * Visual Composer Integration
 *
 ******************************************************************************/
$shortcode_fields = array(
	/*
	array(
		'type'                    => 'pgscore_radio_image',
		"heading"                 => esc_html__("Style", 'pgs-core'),
		'param_name'              => 'style',
		'options'                 => pgscore_get_shortcode_param_data('banner'),
		'show_label'              => true,
		'admin_label'             => true,
	),
	*/
	array(
		"type"                    => "dropdown",
		"class"                   => "",
		"heading"                 => esc_html__("Vertical Align", 'pgs-core'),
		"description"             => esc_html__("Set banner text vertical position.", 'pgs-core'),
		"param_name"              => "vertical_align",
		'value'                   => array_flip( array(
			'vtop'   => esc_html__('Top', 'pgs-core'),
			'vmiddle'=> esc_html__('Middle', 'pgs-core'),
			'vbottom'=> esc_html__('Bottom', 'pgs-core'),
		) ),
		'std'                     => 'vtop',
		"edit_field_class"        => "vc_col-md-4",
		'admin_label'             => true,
	),
	array(
		"type"                    => "dropdown",
		"class"                   => "",
		"heading"                 => esc_html__("Horizontal Align", 'pgs-core'),
		"description"             => esc_html__("Set banner text horizontal position", 'pgs-core'),
		"param_name"              => "horizontal_align",
		'value'                   => array_flip( array(
			'hleft'  => esc_html__('Left', 'pgs-core'),
			'hcenter'=> esc_html__('Center', 'pgs-core'),
			'hright' => esc_html__('Right', 'pgs-core'),
		) ),
		'std'                     => 'hleft',
		"edit_field_class"        => "vc_col-md-4",
		'admin_label'             => true,
	),
	array(
		'type'                    => 'dropdown',
		'heading'                 => esc_html__( 'Effect', 'pgs-core' ),
		'param_name'              => 'banner_effect',
		'value'                   => array_flip( array(
			'none'  => esc_html__('None', 'pgs-core'),
			'border'=> esc_html__('Border', 'pgs-core'),
			'flash' => esc_html__('Flash', 'pgs-core'),
			'zoom'  => esc_html__('Zoom', 'pgs-core'),
		) ),
		'std'                     => 'none',
		'description'             => esc_html__( 'Select banner effect type.', 'pgs-core' ),
		"edit_field_class"        => "vc_col-md-4",
		'save_always'             => true,
		'admin_label'             => true,
	),
	array(
		'type'                    => 'css_editor',
		'heading'                 => esc_html__( 'Banner Padding', 'pgs-core' ),
		'param_name'              => 'banner_css',
		"edit_field_class"        => "vc_col-sm-12 vc_col-sm-6 vc_col-md-5 vc_col-lg-3 banner_css_wrap",
	),
	array(
		'type'                    => 'checkbox',
		"heading"                 => esc_html__("Font Size Responsive?", 'pgs-core'),
		'param_name'              => 'font_size_responsive',
		'description'             => esc_html__( 'Select this checkbox to enable responsive font size for different width.', 'pgs-core' ),
	),
	array(
		'type'                    => 'pgscore_range_slider',
		'heading'                 => esc_html__( "Font Size", 'pgs-core' ),
		'param_name'              => 'font_size',
		'tooltip'                 => __( 'Choose font size', 'pgs-core' ),
		'min'                     => 10,
		'max'                     => 100,
		'value'                   => 70,
		'unit'                    => 'px',
		'dependency'              => array(
			'element'           => 'font_size_responsive',
			'value_not_equal_to'=> 'true',
		),
	),
	/******************************************************/
	array(
		'type'                    => 'pgscore_range_slider',
		"heading"                 => esc_html__("Large Devices (≥1200px)", 'pgs-core'),
		'param_name'              => 'font_size_lg',
		'tooltip'                 => __( 'Choose font size', 'pgs-core' ),
		'min'                     => 10,
		'max'                     => 100,
		'value'                   => 70,
		'unit'                    => 'px',
		'dependency'              => array(
			'element'=> 'font_size_responsive',
			'value'  => 'true',
		),
	),
	array(
		'type'                    => 'pgscore_range_slider',
		"heading"                 => esc_html__("Medium Devices (≥992px)", 'pgs-core'),
		'param_name'              => 'font_size_md',
		'tooltip'                 => __( 'Choose font size', 'pgs-core' ),
		'min'                     => 10,
		'max'                     => 100,
		'value'                   => 60,
		'unit'                    => 'px',
		'dependency'              => array(
			'element'=> 'font_size_responsive',
			'value'  => 'true',
		),
	),
	array(
		'type'                    => 'pgscore_range_slider',
		"heading"                 => esc_html__("Small Devices (≥768px)", 'pgs-core'),
		'param_name'              => 'font_size_sm',
		'tooltip'                 => __( 'Choose font size', 'pgs-core' ),
		'min'                     => 10,
		'max'                     => 100,
		'value'                   => 50,
		'unit'                    => 'px',
		'dependency'              => array(
			'element'=> 'font_size_responsive',
			'value'  => 'true',
		),
	),
	array(
		'type'                    => 'pgscore_range_slider',
		"heading"                 => esc_html__("Extra Small Devices (<768px)", 'pgs-core'),
		'param_name'              => 'font_size_xs',
		'tooltip'                 => __( 'Choose font size', 'pgs-core' ),
		'min'                     => 10,
		'max'                     => 100,
		'value'                   => 40,
		'unit'                    => 'px',
		'dependency'              => array(
			'element'=> 'font_size_responsive',
			'value'  => 'true',
		),
	),
	/******************************************************/
	array(
		'type'                    => 'param_group',
		'param_name'              => 'list_items',
		'group'                   => esc_html__( 'List Items', 'pgs-core' ),
		'max_items'               => 5,
		'sortable'                => true,
		'deletable'               => true,
		'collapsible'             => true,
		'params'                  => array(
			array(
				"type"            => "textfield",
				"param_name"      => "title",
				"heading"         => esc_html__( "Title", 'pgs-core'),
				'description'     => esc_html__( "Add banner text.", 'pgs-core' ),
				'admin_label'     => true,
			),
			array(
				'type'            => 'pgscore_number_min_max',
				'heading'         => esc_html__( "Title Font Size", 'pgs-core' ),
				'param_name'      => 'font_size',
				'min'             => 10,
				'max'             => 100,
				'value'           => 70,
				'suffix'          => '%',
				'description'     => esc_html__('Enter/select font size. This font-size will be in ratio of main font-size.', 'pgs-core'),
				"edit_field_class"=> "vc_col-md-4",
				'admin_label'     => true,
			),
			array(
				'type'            => 'colorpicker',
				'heading'         => esc_html__( 'Color', 'pgs-core' ),
				'param_name'      => 'color',
				'description'     => esc_html__( 'Select text color.', 'pgs-core' ),
				'value'           => '#323232',
				"edit_field_class"=> "vc_col-md-4",
				'admin_label'     => true,
			),
			array(
				'type'            => 'colorpicker',
				'heading'         => esc_html__( 'Background Color', 'pgs-core' ),
				'param_name'      => 'bg_color',
				'description'     => esc_html__( 'Select text background color.', 'pgs-core' ),
				"edit_field_class"=> "vc_col-md-4",
				'admin_label'     => true,
			),
			array(
				'type'            => 'checkbox',
				"heading"         => esc_html__("Responsive", 'pgs-core'),
				'description'     => esc_html__( 'Select checkbox(es) to show/hide on text on specific device size.', 'pgs-core' ),
				'param_name'      => 'text_show_hide',
				'value'           => array_flip( array(
					'lg'          => esc_html__("Large Devices (≥1200px)", 'pgs-core'),
					'md'          => esc_html__("Medium Devices (≥992px)", 'pgs-core'),
					'sm'          => esc_html__("Small Devices (≥768px)", 'pgs-core'),
					'xs'          => esc_html__("Extra Small Devices (<768px)", 'pgs-core'),
				) ),
				'std'             => 'lg,md,sm,xs',
				"edit_field_class"=> "vc_col-md-12",
			),
		),
		'value'                   => urlencode( json_encode( array(
			array(
				'title'           => esc_html__( 'Lorem Ipsum', 'pgs-core'),
				'font_size'       => '70',
				'color'           => '#323232',
				'text_show_hide'  => 'lg,md,sm,xs',
			),
		) ) ),
		'callbacks'               => array(
			// 'after_add'           => 'vcChartParamAfterAddCallback',
		),
	),
	array(
		"type"                    => "attach_image",
		"class"                   => "",
		"heading"                 => esc_html__("Banner Image", 'pgs-core'),
		"description"             => esc_html__("Upload banner image", 'pgs-core'),
		"param_name"              => "bg_img",
		"holder"                  => "img",
	),
	
	// Button
	array(
		"type"                    => "textfield",
		"class"                   => "",
		"heading"                 => esc_html__( 'Button Title', 'pgs-core'),
		"param_name"              => "button_text",
		'group'                   => esc_html__( 'Button', 'pgs-core' ),
		'admin_label'             => true,
	),
	array(
		"type"                    => "dropdown",
		"param_name"              => "button_style",
		"heading"                 => esc_html__("Button Style", 'pgs-core'),
		"description"             => esc_html__("Select button style.", 'pgs-core'),
		'value'                   => array_flip( array(
			'link'  => esc_html__('Link', 'pgs-core'),
			'flat'  => esc_html__('Flat', 'pgs-core'),
			'border'=> esc_html__('Border', 'pgs-core'),
		) ),
		"std"                     => "link",
		'group'                   => esc_html__( 'Button', 'pgs-core' ),
	),
	array(
		"type"                    => "dropdown",
		"param_name"              => "button_shape",
		"heading"                 => esc_html__("Button Shape", 'pgs-core'),
		"description"             => esc_html__("Select button shape.", 'pgs-core'),
		'value'                   => array_flip( array(
			'square' => esc_html__('Square', 'pgs-core'),
			'rounded'=> esc_html__('Rounded', 'pgs-core'),
			'round'  => esc_html__('Round', 'pgs-core'),
		) ),
		"std"                     => "square",
		'dependency'              => array(
			'element'=> 'button_style',
			'value'  => array( 'flat', 'border' ),
		),
		'group'                   => esc_html__( 'Button', 'pgs-core' ),
	),
	array(
		'type'                    => 'colorpicker',
		'heading'                 => esc_html__( 'Button Color', 'pgs-core' ),
		'param_name'              => 'button_color',
		'description'             => esc_html__( 'Select button color.', 'pgs-core' ),
		'group'                   => esc_html__( 'Button', 'pgs-core' ),
		'dependency'              => array(
			'element'=> 'button_style',
			'value'  => array( 'flat' ),
		),
	),
	array(
		'type'                    => 'colorpicker',
		'heading'                 => esc_html__( 'Button Border Color', 'pgs-core' ),
		'param_name'              => 'button_border_color',
		'description'             => esc_html__( 'Select button border color.', 'pgs-core' ),
		'group'                   => esc_html__( 'Button', 'pgs-core' ),
		'dependency'              => array(
			'element'=> 'button_style',
			'value'  => array( 'border' ),
		),
	),
	array(
		'type'                    => 'colorpicker',
		'heading'                 => esc_html__( 'Button Text Color', 'pgs-core' ),
		'param_name'              => 'button_text_color',
		'description'             => esc_html__( 'Select button text color.', 'pgs-core' ),
		'group'                   => esc_html__( 'Button', 'pgs-core' ),
	),
	array(
		'type'                    => 'vc_link',
		'heading'                 => esc_html__( 'URL (Link)', 'pgs-core' ),
		'param_name'              => 'link_url',
		'description'             => esc_html__( 'Add custom link.', 'pgs-core' ),
		'group'                   => esc_html__( 'Button', 'pgs-core' ),
	),
	
	// Badge
	array(
		'type'                    => 'checkbox',
		"heading"                 => esc_html__("Add Badge", 'pgs-core'),
		'param_name'              => 'add_badge',
		'description'             => esc_html__( 'Select this checkbox to add badge.', 'pgs-core' ),
		'group'                   => esc_html__( 'Badge', 'pgs-core' ),
		'admin_label'             => true,
	),
	array(
		"type"                    => "textfield",
		"param_name"              => "badge_title",
		"heading"                 => esc_html__( "Title", 'pgs-core'),
		'description'             => esc_html__( "Add badge title.", 'pgs-core' ),
		'group'                   => esc_html__( 'Badge', 'pgs-core' ),
		'dependency'              => array(
			'element'=> 'add_badge',
			'value'  => 'true',
		),
		"edit_field_class"        => "vc_col-md-9",
	),
	array(
		"type"                    => "dropdown",
		"param_name"              => "badge_type",
		"heading"                 => esc_html__("Badge Type", 'pgs-core'),
		"description"             => esc_html__("Select badge style.", 'pgs-core'),
		'value'                   => array_flip( array(
			'border'=> esc_html__('Border', 'pgs-core'),
			'flat'  => esc_html__('Flat', 'pgs-core'),
		) ),
		"std"                     => "border",
		'group'                   => esc_html__( 'Badge', 'pgs-core' ),
		'dependency'              => array(
			'element'=> 'add_badge',
			'value'  => 'true',
		),
		"edit_field_class"        => "vc_col-md-3",
	),
	array(
		'type'                    => 'colorpicker',
		'heading'                 => esc_html__( 'Text Color', 'pgs-core' ),
		'param_name'              => 'badge_text_color',
		'description'             => esc_html__( 'Select badge text color.', 'pgs-core' ),
		'group'                   => esc_html__( 'Badge', 'pgs-core' ),
		'value'                   => '#323232',
		'dependency'              => array(
			'element'=> 'add_badge',
			'value'  => 'true',
		),
		"edit_field_class"        => "vc_col-md-6",
	),
	array(
		'type'                    => 'colorpicker',
		'heading'                 => esc_html__( 'Background Color', 'pgs-core' ),
		'param_name'              => 'badge_background_color',
		'description'             => esc_html__( 'Select badge background color.', 'pgs-core' ),
		'group'                   => esc_html__( 'Badge', 'pgs-core' ),
		'value'                   => '#ffffff',
		'dependency'              => array(
			'element'=> 'badge_type',
			'value'  => array( 'flat' ),
		),
		"edit_field_class"        => "vc_col-md-6",
	),
	array(
		'type'                    => 'colorpicker',
		'heading'                 => esc_html__( 'Border Color', 'pgs-core' ),
		'param_name'              => 'badge_border_color',
		'description'             => esc_html__( 'Select badge border color.', 'pgs-core' ),
		'group'                   => esc_html__( 'Badge', 'pgs-core' ),
		'value'                   => '#323232',
		'dependency'              => array(
			'element'=> 'badge_type',
			'value'  => array( 'border' ),
		),
		"edit_field_class"        => "vc_col-md-6",
	),
	array(
		'type'                    => 'pgscore_number_min_max',
		'heading'                 => esc_html__( "Width", 'pgs-core' ),
		'param_name'              => 'badge_width',
		'min'                     => 10,
		'max'                     => 200,
		'value'                   => 70,
		'suffix'                  => 'px',
		'description'             => esc_html__('Enter/select badge width.', 'pgs-core'),
		'group'                   => esc_html__( 'Badge', 'pgs-core' ),
		"edit_field_class"        => "vc_col-md-6",
		'dependency'              => array(
			'element'=> 'add_badge',
			'value'  => 'true',
		),
	),
	array(
		'type'                    => 'pgscore_number_min_max',
		'heading'                 => esc_html__( "Height", 'pgs-core' ),
		'param_name'              => 'badge_height',
		'min'                     => 10,
		'max'                     => 200,
		'value'                   => 70,
		'suffix'                  => 'px',
		'description'             => esc_html__('Enter/select badge height.', 'pgs-core'),
		'group'                   => esc_html__( 'Badge', 'pgs-core' ),
		'dependency'              => array(
			'element'=> 'add_badge',
			'value'  => 'true',
		),
		"edit_field_class"        => "vc_col-md-6",
	),
	array(
		"type"                    => "dropdown",
		"heading"                 => esc_html__("Vertical Align", 'pgs-core'),
		"description"             => esc_html__("Set badge vertical position.", 'pgs-core'),
		"param_name"              => "badge_vertical_align",
		'value'                   => array_flip( array(
			'vtop'   => esc_html__('Top', 'pgs-core'),
			'vmiddle'=> esc_html__('Middle', 'pgs-core'),
			'vbottom'=> esc_html__('Bottom', 'pgs-core'),
		) ),
		'std'                     => 'vbottom',
		'group'                   => esc_html__( 'Badge', 'pgs-core' ),
		'dependency'              => array(
			'element'=> 'add_badge',
			'value'  => 'true',
		),
		"edit_field_class"        => "vc_col-md-6",
	),
	array(
		"type"                    => "dropdown",
		"heading"                 => esc_html__("Horizontal Align", 'pgs-core'),
		"description"             => esc_html__("Set badge horizontal position.", 'pgs-core'),
		"param_name"              => "badge_horizontal_align",
		'value'                   => array_flip( array(
			'hleft'  => esc_html__('Left', 'pgs-core'),
			'hcenter'=> esc_html__('Center', 'pgs-core'),
			'hright' => esc_html__('Right', 'pgs-core'),
		) ),
		'std'                     => 'hright',
		'group'                   => esc_html__( 'Badge', 'pgs-core' ),
		'dependency'              => array(
			'element'=> 'add_badge',
			'value'  => 'true',
		),
		"edit_field_class"        => "vc_col-md-6",
	),
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params                      = array(
	"name"                   => esc_html__( "Banner", 'pgs-core' ),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}