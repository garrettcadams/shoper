<?php
/******************************************************************************
 *
 * Shortcode : pgscore_info_box
 *
 ******************************************************************************/
function pgscore_shortcode_info_box( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		// Box
		'layout'                  => 'style_1',
		'content_alignment'       => 'center',
		'icon_position'           => 'left',
		
		// Title
		'title'                   => '',
		'title_el'                => 'h3',
		'title_color'             => '#323232',
		
		// Description
		'description'             => '',
		
		// Icon
		'icon_disable'            => '',
		'icon_style'              => 'default', // default, border, flat
		'icon_size'               => 'md',
		'icon_shape'              => 'square', // square, rounded, round
		
		// Icon - Background
		'icon_background_color'   => '#878787',
		
		// Icon - Border
		'icon_border_color'       => '#878787',
		'icon_border_width'       => '5',
		'icon_border_style'       => '',
		
		// Icon (Outer Border)
		'icon_enable_outer_border'=> '',
		'icon_outer_border_color' => '#323232',
		'icon_outer_border_width' => '5',
		'icon_outer_border_style' => '',
		
		// Icon - Source
		'icon_source'             => 'font', // font, image
		
		// Icon - Type            = Image
		'icon_image'              => '',
		
		// Icon - Type            = Font
		'icon_color'              => '#323232',
		'icon_type'               => 'fontawesome',
		'icon_fontawesome'        => 'fa fa-chevron-right',
		'icon_openiconic'         => 'vc-oi vc-oi-right',
		'icon_typicons'           => 'typcn typcn-chevron-right',
		'icon_entypo'             => 'entypo-icon entypo-icon-right-open',
		'icon_linecons'           => 'vc_li vc_li-heart',
		'icon_monosocial'         => 'vc-mono vc-mono-fivehundredpx',
		'icon_material'           => 'vc-material vc-material-cake',
		'icon_pixelicons'         => 'vc_pixel_icon vc_pixel_icon-alert',
		'icon_flaticon'           => 'glyph-icon flaticon-right-arrow-1',
		
		// Link
		'link_enable'             => '',
		'link_url'                => '',
		'link_on'                 => 'title',
		'link_custom_onclick'     => '',
		'link_custom_onclick_code'=> '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	
	extract( $atts );
	
	// Return shortcode if no required content found to display the shortcode perfectly.
	if( empty( $title ) && empty( $description ) ) {
		return;
	}
	
	/**********************************************************
	 *
	 * Icons Settings
	 *
	 **********************************************************/
	$icon_html = $icon_class = '';
	$icon_wrapper = false;
	
	if( isset($icon_source) && $icon_source == 'font' ){
		if ( isset( ${'icon_' . $icon_type} ) && !empty(${'icon_' . $icon_type}) ) {
			if ( 'pixelicons' === $icon_type ) {
				$icon_wrapper = true;
			}
			$icon_class = ${'icon_' . $icon_type};
		}
	}
	
	if( isset($icon_class) && empty($icon_class) ){
		$icon_disable == 'true';
	}
	
	if( isset($icon_disable) && $icon_disable == '' ){
		if( isset($icon_source) && $icon_source == 'font' ){
			if ( $icon_wrapper ) {
				$icon_html = '<i class="icon_wrap"><span class="' . esc_attr( $icon_class ) . '"></span></i>';
			} else {
				$icon_style = '';
				if( isset($icon_color) && !empty($icon_color) ){
					$icon_style = ' style="color:'.esc_attr($icon_color).';"';
				}
				$icon_html = '<i class="'.esc_attr($icon_class).'"'.$icon_style.'></i>';
			}
			
			// Enqueue icon CSS for icon type
			vc_icon_element_fonts_enqueue( $icon_type );
		}elseif( isset($icon_source) && $icon_source == 'image' ){
			if( !empty($icon_image) ){
				$icon_image_size = array(
					'xs' => array(16,16),
					'sm' => array(20,20),
					'md' => array(24,24),
					'lg' => array(28,28),
				);
				
				// $banner_image = wp_get_attachment_image_src( $icon_image, $icon_image_size[$icon_size] );
				$banner_image = wp_get_attachment_image_src( $icon_image, "pgscore-thumbnail-80" );
				$icon_html = '<img src="'.esc_url($banner_image[0]).'">';
			}
		}
	}
	
	/**********************************************************
	 *
	 * Element Classes
	 * For base wrapper
	 *
	**********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['icon_html'] = $icon_html;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('info_box/content' );?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 *
 * Visual Composer Integration
 *
 ******************************************************************************/
$shortcode_fields = array_merge(
	array(
		array(
			'type'            => 'pgscore_radio_image',
			"heading"         => esc_html__("Layout", 'pgs-core'),
			'param_name'      => 'layout',
			'options'         => pgscore_get_shortcode_param_data('info_box'),
			'show_label'      => true,
			'admin_label'     => true,
		),
		/*
		array(
			"type"            => "dropdown",
			"heading"         => esc_html__("Box Style", 'pgs-core'),
			"param_name"      => "box_style",
			'value'           => array_flip(array(
				'default'=> esc_html__( 'Default', 'pgs-core' ),
				'flat'   => esc_html__( 'Flat', 'pgs-core' ),
				'border' => esc_html__( 'Border', 'pgs-core' ),
			)),
			"std"             => "default",
			'admin_label'     => true,
		),
		*/
		array(
			"type"            => "pgscore_radio",
			"heading"         => esc_html__("Content Alignment", 'pgs-core'),
			"param_name"      => "content_alignment",
			'value'           => array_flip(array(
				'left'  => '<i class="dashicons dashicons-editor-alignleft"></i>',
				'center'=> '<i class="dashicons dashicons-editor-aligncenter"></i>',
				'right' => '<i class="dashicons dashicons-editor-alignright"></i>',
			)),
			"std"             => "center",
			"class"           => "pgscore_radio_label_only",
			'edit_field_class'=> 'vc_col-sm-6 vc_column',
			'save_always'     => true,
		),
		array(
			"type"            => "pgscore_radio",
			"heading"         => esc_html__("Icon Position", 'pgs-core'),
			"param_name"      => "icon_position",
			'value'           => array_flip(array(
				'left'  => '<i class="dashicons dashicons-editor-outdent"></i>',
				'right' => '<i class="dashicons dashicons-editor-indent"></i>',
			)),
			"std"             => "left",
			"class"           => "pgscore_radio_label_only",
			'edit_field_class'=> 'vc_col-sm-6 vc_column',
			'save_always'     => true,
			'dependency' => array(
				'element'=> 'layout',
				'value'  => 'style_2',
			),
		),
		
		/*---------------------------- Title ----------------------------*/
		array(
			"type"            => "textfield",
			"heading"         => esc_html__("Title", 'pgs-core'),
			"description"     => esc_html__("Enter title.", 'pgs-core'),
			"param_name"      => "title",
			'admin_label'     => true,
			'edit_field_class'=> 'vc_col-sm-9 vc_column vc_column-with-padding',
			'group'           => esc_html__( 'Title', 'pgs-core' ),
		),
		array(
			"type"            => "dropdown",
			"heading"         => esc_html__("Title Element Tag", 'pgs-core'),
			"param_name"      => "title_el",
			"std"             => "h3",
			'value'           => array_flip( array(
				'h2'  => esc_html__( 'H2', 'pgs-core' ),
				'h3'  => esc_html__( 'H3', 'pgs-core' ),
				'h4'  => esc_html__( 'H4', 'pgs-core' ),
				'h5'  => esc_html__( 'H5', 'pgs-core' ),
				'h6'  => esc_html__( 'H6', 'pgs-core' ),
			)),
			'edit_field_class'=> 'vc_col-sm-3 vc_column',
			'group'           => esc_html__( 'Title', 'pgs-core' ),
		),
		array(
			'type'            => 'colorpicker',
			'heading'         => esc_html__( 'Color', 'pgs-core' ),
			'param_name'      => 'title_color',
			'description'     => esc_html__( 'Select title color.', 'pgs-core' ),
			'value'           => '#323232',
			'group'           => esc_html__( 'Title', 'pgs-core' ),
		),
		
		/*---------------------------- Description ----------------------------*/
		array(
			"type"        => "textfield",
			"heading"     => esc_html__("Description", 'pgs-core'),
			"param_name"  => "description",
			"description" => esc_html__("Enter description. Please ensure to add short content.", 'pgs-core'),
			'holder'      => 'div',
			'group'       => esc_html__( 'Content', 'pgs-core' ),
		),
		
		/*---------------------------- Icon ----------------------------*/
		array(
			'type'             => 'checkbox',
			'heading'          => __( 'Icon Disable', 'pgs-core' ),
			'param_name'       => 'icon_disable',
			'description'      => __( 'Check this checkbox to disable icon.', 'pgs-core' ),
			'value'            => array(
				__( 'Disable', 'pgs-core' ) => 'true'
			),
			'std'              => '',
			'group'            => __( 'Icon', 'pgs-core' ),
			'admin_label'     => true,
		),
		array(
			"type"            => "dropdown",
			"heading"         => esc_html__("Icon Style", 'pgs-core'),
			"param_name"      => "icon_style",
			'value'           => array_flip(array(
				'default'=> esc_html__( 'Default', 'pgs-core' ),
				'flat'   => esc_html__( 'Flat', 'pgs-core' ),
				'border' => esc_html__( 'Border', 'pgs-core' ),
			)),
			"std"             => "default",
			'group'            => __( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-4 vc_column',
			'dependency'      => array(
				'element'           => 'icon_disable',
				'value_not_equal_to'=> 'true',
			),
		),
		array(
			'type'            => 'dropdown',
			'heading'         => esc_html__( 'Icon Size', 'pgs-core' ),
			'param_name'      => 'icon_size',
			'description'     => esc_html__( 'Select icon size.', 'pgs-core' ),
			'value'           => array_flip( array(
				'xs'=> esc_html__( 'Extra Small', 'pgs-core' ),
				'sm'=> esc_html__( 'Small', 'pgs-core' ),
				'md'=> esc_html__( 'medium', 'pgs-core' ),
				'lg'=> esc_html__( 'Large', 'pgs-core' ),
			) ),
			'std'             => 'md',
			'admin_label'     => true,
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-4 vc_column',
			'dependency'      => array(
				'element'           => 'icon_disable',
				'value_not_equal_to'=> 'true',
			)
		),
		array(
			"type"            => "dropdown",
			"heading"         => esc_html__("Icon Shape", 'pgs-core'),
			"param_name"      => "icon_shape",
			"description"     => "Select icon shape.",
			'value'           => array_flip(array(
				'square' => esc_html__( 'Square', 'pgs-core' ),
				'rounded'=> esc_html__( 'Rounded', 'pgs-core' ),
				'round'  => esc_html__( 'Round', 'pgs-core' ),
			)),
			"std"             => "square",
			'group'           => __( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-4 vc_column',
			'dependency'      => array(
				'element' => 'icon_style',
				'value'   => array('flat', 'border'),
			)
		),
		array(
			'type'            => 'colorpicker',
			'heading'         => esc_html__( 'Background Color', 'pgs-core' ),
			'param_name'      => 'icon_background_color',
			'description'     => esc_html__( 'Select icon background color.', 'pgs-core' ),
			'value'           => '#ccc',
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-4 vc_column',
			'dependency'      => array(
				'element' => 'icon_style',
				'value'   => array('flat'),
			)
		),
		array(
			'type'            => 'colorpicker',
			'heading'         => esc_html__( 'Border Color', 'pgs-core' ),
			'param_name'      => 'icon_border_color',
			'description'     => esc_html__( 'Select border color.', 'pgs-core' ),
			'value'           => '#ccc',
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-4 vc_column',
			'dependency'      => array(
				'element' => 'icon_style',
				'value'   => array('border'),
			)
		),
		array(
			'type'            => 'pgscore_number_min_max',
			'heading'         => esc_html__( "Border Width", 'pgs-core' ),
			'description'     => esc_html__('Enter/select border width.', 'pgs-core'),
			'param_name'      => 'icon_border_width',
			'min'             => 1,
			'max'             => 10,
			'value'           => 5,
			'suffix'          => 'px',
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-4 vc_column',
			'dependency'      => array(
				'element' => 'icon_style',
				'value'   => array('border'),
			)
		),
		array(
			"type"            => "dropdown",
			"heading"         => esc_html__("Border Style", 'pgs-core'),
			"param_name"      => "icon_border_style",
			"description"     => "Select border style.",
			'value'           => array_flip( array(
				''       => esc_html__( 'Theme defaults', 'pgs-core' ),
				'solid'  => esc_html__( 'Solid', 'pgs-core' ),
				'dotted' => esc_html__( 'Dotted', 'pgs-core' ),
				'dashed' => esc_html__( 'Dashed', 'pgs-core' ),
				'double' => esc_html__( 'Double', 'pgs-core' ),
				'groove' => esc_html__( 'Groove', 'pgs-core' ),
				'ridge'  => esc_html__( 'Ridge', 'pgs-core' ),
			) ),
			"std"             => "",
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-4 vc_column',
			'dependency'      => array(
				'element' => 'icon_style',
				'value'   => array('border'),
			)
		),
		array(
			'type'             => 'checkbox',
			'heading'          => __( 'Enable Outer Border', 'pgs-core' ),
			'param_name'       => 'icon_enable_outer_border',
			'description'      => __( 'Check this checkbox to enable outer border.', 'pgs-core' ),
			'value'            => array(
				esc_html__( 'Enable', 'pgs-core' ) => 'true'
			),
			'std'              => '',
			'group'            => __( 'Icon', 'pgs-core' ),
			'dependency'      => array(
				'element' => 'icon_style',
				'value'   => array('flat', 'border'),
			)
		),
		array(
			'type'            => 'colorpicker',
			'heading'         => esc_html__( 'Outer Border Color', 'pgs-core' ),
			'param_name'      => 'icon_outer_border_color',
			'description'     => esc_html__( 'Select border color.', 'pgs-core' ),
			'value'           => '#ccc',
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-4 vc_column',
			'dependency'      => array(
				'element'  => 'icon_enable_outer_border',
				'not_empty'=> true,
			)
		),
		array(
			'type'            => 'pgscore_number_min_max',
			'heading'         => esc_html__( "Outer Border Width", 'pgs-core' ),
			'description'     => esc_html__('Enter/select border width.', 'pgs-core'),
			'param_name'      => 'icon_outer_border_width',
			'min'             => 1,
			'max'             => 10,
			'value'           => 5,
			'suffix'          => 'px',
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			"edit_field_class"=> "vc_col-md-4",
			'dependency'      => array(
				'element'  => 'icon_enable_outer_border',
				'not_empty'=> true,
			)
		),
		array(
			"type"            => "dropdown",
			"heading"         => esc_html__("Outer Border Style", 'pgs-core'),
			"param_name"      => "icon_outer_border_style",
			"description"     => "Select border style.",
			'value'           => array_flip( array(
				''       => esc_html__( 'Theme defaults', 'pgs-core' ),
				'solid'  => esc_html__( 'Solid', 'pgs-core' ),
				'dotted' => esc_html__( 'Dotted', 'pgs-core' ),
				'dashed' => esc_html__( 'Dashed', 'pgs-core' ),
				'double' => esc_html__( 'Double', 'pgs-core' ),
				'groove' => esc_html__( 'Groove', 'pgs-core' ),
				'ridge'  => esc_html__( 'Ridge', 'pgs-core' ),
			) ),
			"std"             => "",
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-4 vc_column',
			'dependency'      => array(
				'element'  => 'icon_enable_outer_border',
				'not_empty'=> true,
			)
		),
		array(
			"type"            => "dropdown",
			"heading"         => esc_html__("Icon Source", 'pgs-core'),
			"param_name"      => "icon_source",
			'value'           => array_flip(array(
				'font' => esc_html__( 'Font', 'pgs-core' ),
				'image'=> esc_html__( 'Image', 'pgs-core' ),
			)),
			"std"             => "font",
			'group'           => __( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-12 vc_column',
			'dependency'      => array(
				'element'           => 'icon_disable',
				'value_not_equal_to'=> 'true',
			),
			"class"           => "pgscore_radio_label_only",
			'save_always'     => true,
			'admin_label'     => true,
		),
		array(
			"type"            => "attach_image",
			"param_name"      => "icon_image",
			"heading"         => esc_html__("Icon Image", 'pgs-core'),
			"description"     => esc_html__("Upload/select icon image.", 'pgs-core'),
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			'edit_field_class'=> 'vc_col-sm-6 vc_column',
			'dependency'      => array(
				'element'     => 'icon_source',
				'value'       => 'image',
			),
		),
		/*
		array(
			'type'            => 'textfield',
			'param_name'      => 'icon_image_size',
			'heading'         => esc_html__( 'Image Size', 'pgs-core' ),
			'description'     => wp_kses( __( 'Enter image size. You can use default/custom WordPress sizes (<code>thumbnail</code>, <code>medium</code>, <code>large</code>, <code>full</code>) or exact size (by width and height) in this format: <code>100x200</code>.', 'pgs-core' ), array(
				'code' => array(),
			) ).'<br>'.esc_html__('Note: This image size will be used to generate output image, but image will be displayed in fixed size as per selected in Icon Size', 'pgs-core'),
			'value'           => 'thumbnail',
			'edit_field_class'=> 'vc_col-sm-6 vc_column',
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			'dependency'      => array(
				'element'     => 'icon_source',
				'value'       => 'image',
			),
		),
		*/
		array(
			'type'            => 'colorpicker',
			'heading'         => esc_html__( 'Icon Color', 'pgs-core' ),
			'param_name'      => 'icon_color',
			'description'     => esc_html__( 'Select icon color.', 'pgs-core' ),
			'value'           => '#323232',
			'group'           => esc_html__( 'Icon', 'pgs-core' ),
			'dependency'      => array(
				'element'     => 'icon_source',
				'value'       => 'font',
			),
		),
	),
	pgscore_iconpicker( array(
		'dependency' => array(
			'element' => 'icon_source',
			'value'   => 'font',
		),
		'group'      => esc_html__( 'Icon', 'pgs-core' ),
	) ),
	array(
		/*---------------------------- Link ----------------------------*/
		/*
		array(
			'type'             => 'checkbox',
			'heading'          => __( 'Icon', 'pgs-core' ),
			'param_name'       => 'link_enable',
			'description'      => __( 'Check this checkbox to add link.', 'pgs-core' ),
			'value'            => array(
				esc_html__( 'Enable', 'pgs-core' ) => 'true'
			),
			'std'              => '',
			'group'            => esc_html__( 'Link', 'pgs-core' ),
		),
		array(
			'type'            => 'vc_link',
			'heading'         => esc_html__( 'Link', 'pgs-core' ),
			'param_name'      => 'link_url',
			'description'     => esc_html__( 'Add link.', 'pgs-core' ),
			'group'           => esc_html__( 'Link', 'pgs-core' ),
			'dependency'      => array(
				'element'=> 'link_enable',
				'not_empty'=> true,
			),
		),
		array(
			'type'            => 'dropdown',
			'heading'         => esc_html__( 'Link On', 'pgs-core' ),
			'param_name'      => 'link_on',
			'description'     => esc_html__( 'Select where to set link.', 'pgs-core' ),
			'value'           => array_flip( array(
				'title' => esc_html__( 'Title', 'pgs-core' ),
				'icon'  => esc_html__( 'Icon', 'pgs-core' ),
				'box'   => esc_html__( 'Box', 'pgs-core' ),
			) ),
			'std'             => 'title',
			'group'            => esc_html__( 'Link', 'pgs-core' ),
			'dependency'      => array(
				'element'  => 'link_enable',
				'not_empty'=> true,
			),
		),
		array(
			'type'             => 'checkbox',
			'heading'          => __( 'Advanced on click action', 'pgs-core' ),
			'param_name'       => 'link_custom_onclick',
			'description'      => __( 'Check this checkbox to insert inline onclick javascript action.', 'pgs-core' ),
			'value'            => array(
				esc_html__( 'Enable', 'pgs-core' ) => 'true'
			),
			'std'              => '',
			'group'            => esc_html__( 'Link', 'pgs-core' ),
			'dependency'      => array(
				'element'  => 'link_enable',
				'not_empty'=> true,
			),
		),
		array(
			'type'       => 'textfield',
			'heading'    => esc_html__( 'On click code', 'pgs-core' ),
			'param_name' => 'link_custom_onclick_code',
			'description'=> esc_html__( 'Enter onclick action code.', 'pgs-core' ),
			'group'      => esc_html__( 'Link', 'pgs-core' ),
			'dependency' => array(
				'element'  => 'link_custom_onclick',
				'not_empty'=> true,
			),
		),
		*/
	)
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                    => esc_html__( "Info Box", 'pgs-core' ),
	"description"             => esc_html__( "Information box with icon and link.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}