<?php
/******************************************************************************
 *
 * Shortcode : pgscore_logo_carousel
 *
 ******************************************************************************/
function pgscore_shortcode_logo_carousel( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		// 'style'   => 'slider',
		'images'     => '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	// Return if no images found
	if ( empty($images) ) {
		return null;
	}
	
	$images_list = explode(',', $images);
	
	$element_class = vc_shortcode_custom_css_class( $element_css, ' ' );
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	**********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['images_list'] = $images_list;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('logo_carousel/content');?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 *
 * Visual Composer Integration
 *
 ******************************************************************************/
$shortcode_fields = array(
	array(
		'type'       => 'attach_images',
		'heading'    => __( 'Images', 'pgs-core' ),
		'param_name' => 'images',
		'holder'     => 'ul',
		'value'      => '',
		'description'=> __( 'Select images from media library.', 'pgs-core' ),
	),
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Logo Carousel", 'pgs-core' ),
	"description"            => esc_html__( "Display carousel of clients logos.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}