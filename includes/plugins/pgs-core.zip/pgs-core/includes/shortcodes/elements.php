<?php
/******************************************************************************
 *
 * Shortcode : pgscore_elements
 *
 ******************************************************************************/
function pgscore_shortcode_elements( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'type'         => '',
		'element_css'  => '',
		'element_class'=> '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	if( empty($type) ){
		return;
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array(
		'pgscore_elements_wrapper',
		'pgscore_elements_type-'.$type,
	);
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	
	ob_start();
	pgscore_get_shortcode_templates('elements/'.$type);
	$shortcode_content = ob_get_clean();
	$shortcode_content = trim($shortcode_content);
	if( empty( $shortcode_content ) ){
		return;
	}
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php echo $shortcode_content;?>
	</div>
	<?php
	return ob_get_clean();
}