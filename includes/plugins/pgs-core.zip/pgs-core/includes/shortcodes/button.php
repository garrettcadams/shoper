<?php
/******************************************************************************
 * 
 * Shortcode : pgscore_button
 * 
 ******************************************************************************/
function pgscore_shortcode_button( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'title'         => 'Click Here',
		'button_link'   => '|||',
		'style'         => 'default',
		'button_3d'     => '',
		'size'          => 'medium',
		'shape'         => 'square',
		'align'         => 'inline',
		'button_block'  => '',
		'animation'     => '',
		'color'         => 'default',
		'add_icon'      => '',
		'alignment'     => 'left',
		'icon_animation'=> '',
		'icon_type'       => 'fontawesome',
		'icon_fontawesome'=> 'fa fa-chevron-right',
		'icon_openiconic' => 'vc-oi vc-oi-right',
		'icon_typicons'   => 'typcn typcn-chevron-right',
		'icon_entypo'     => 'entypo-icon entypo-icon-right-open',
		'icon_linecons'   => 'vc_li vc_li-heart',
		'icon_monosocial' => 'vc-mono vc-mono-fivehundredpx',
		'icon_material'   => 'vc-material vc-material-cake',
		'icon_pixelicons' => 'vc_pixel_icon vc_pixel_icon-alert',
		'icon_flaticon'   => 'glyph-icon flaticon-right-arrow-1',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	// Return shortcode if no required content found to display the shortcode perfectly.
	if( empty( $title ) ) {
		return;
	}
	
	/**********************************************************
	 * 
	 * Icons Settings
	 * 
	 **********************************************************/
	$icon_html  = '';
	
	if( $add_icon ){
		$icon_wrapper = false;
		if ( isset( ${'icon_' . $icon_type} ) && !empty(${'icon_' . $icon_type}) ) {
			if ( 'pixelicons' === $icon_type ) {
				$icon_wrapper = true;
			}
			$icon_class = ${'icon_' . $icon_type};
		} else {
			$icon_class = 'fa fa-adjust';
		}
		
		if ( $icon_wrapper ) {
			$icon_html = '<i class="icon_wrap"><span class="' . esc_attr( $icon_class ) . '"></span></i>';
		} else {
			$icon_html = '<i class="' . esc_attr( $icon_class ) . '"></i>';
		}
		
		// Enqueue icon CSS for icon type
		vc_icon_element_fonts_enqueue( $icon_type );
	}
	
	$icon_html_left = $icon_html_right = '';
	
	if( $add_icon && !empty($icon_html) ){
		if( $alignment == 'left' ){
			$icon_html_left = $icon_html;
		}elseif( $alignment == 'right' ){
			$icon_html_right = $icon_html;
		}
	}
	
	
	/**********************************************************
	 * 
	 * Shortcode Link
	 * 
	 **********************************************************/
	$link_class = array();
	$link_class[] = 'button';
	if( $style && $style != 'default' ){
		$link_class[] = $style;
	}
	if( $button_3d && ( $style == 'default' || $style == 'flat-color' ) ){
		$link_class[] = 'button-3d';
	}
	if( $size && $size != 'medium' ){
		$link_class[] = $size;
	}
	if( $shape && $shape != 'square' ){
		$link_class[] = $shape;
	}
	if( $add_icon && !empty($icon_html) ){
		if( $alignment == 'left' ){
			$link_class[] = 'left-icn';
		}elseif( $alignment == 'right' ){
			$link_class[] = 'right-icn';
		}
	}
	if( $icon_animation ){
		$link_class[] = 'animated';
	}
	if( $animation ){
		$link_class[] = 'animated';
		if( $animation == 'button-fill' ){
			$link_class[] = 'fill';
		}else{
			$link_class[] = $animation;
		}
	}
	if( $color && $style == 'flat-color' ){
		$link_class[] = $color;
	}
	
	$link_attr = '';
	if( !empty($button_link) ){
		$link_attr = pgscore_vc_link_attr( $button_link, $link_class );
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	$atts['element_classes'][] = "pgscore_button_align-$align";
	if( $align != 'inline' && isset($button_block) && $button_block == 'true' ){
		$atts['element_classes'][] = "pgscore_button_block";
	}
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts']           = $atts;
	$pgscore_shortcodes[$shortcode_handle]['link_attr']      = $link_attr;
	$pgscore_shortcodes[$shortcode_handle]['icon_html_left'] = $icon_html_left;
	$pgscore_shortcodes[$shortcode_handle]['icon_html_right']= $icon_html_right;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('button/content' );?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 * 
 * Visual Composer Integration
 * 
 ******************************************************************************/
$shortcode_fields = array(
	array(
		"type"        => "textfield",
		"heading"     => esc_html__( "Title", 'pgs-core' ),
		"param_name"  => "title",
		'admin_label' => true,
	),
	array(
		'type'       => 'vc_link',
		'heading'    => esc_html__( 'URL (Link)', 'pgs-core' ),
		'param_name' => 'button_link',
		'description'=> esc_html__( 'Add link to button.', 'pgs-core' ),
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Style', 'pgs-core' ),
		'description'=> esc_html__( 'Select button display style.', 'pgs-core' ),
		'param_name' => 'style',
		'std'        => 'default',
		'value'      => array(
			esc_html__( 'Default', 'pgs-core' )    => 'default',
			esc_html__( 'Flat Color', 'pgs-core' ) => 'flat-color',
			esc_html__( 'Border', 'pgs-core' )     => 'border',
			esc_html__( 'Transparent', 'pgs-core' )=> 'transparent',
		),
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Color', 'pgs-core' ),
		'description'=> esc_html__( 'Select button color.', 'pgs-core' ),
		'param_name' => 'color',
		'std'        => 'default',
		'value'      => array(
			esc_html__( 'Blue Default'  , 'pgs-core' ) => 'blue'        ,
			esc_html__( 'Blue Dark'     , 'pgs-core' ) => 'blue-dark'   ,
			esc_html__( 'Purple Default', 'pgs-core' ) => 'purple'      ,
			esc_html__( 'Purple Dark'   , 'pgs-core' ) => 'purple-dark' ,
			esc_html__( 'Red Default'   , 'pgs-core' ) => 'red'         ,
			esc_html__( 'Red Dark'      , 'pgs-core' ) => 'red-dark'    ,
			esc_html__( 'Pink Default'  , 'pgs-core' ) => 'pink'        ,
			esc_html__( 'Pink Dark'     , 'pgs-core' ) => 'pink-dark'   ,
			esc_html__( 'Green Default' , 'pgs-core' ) => 'green'       ,
			esc_html__( 'Default'       , 'pgs-core' ) => 'default'     ,
			esc_html__( 'Default Dark'  , 'pgs-core' ) => 'default-dark',
			esc_html__( 'Brown Default' , 'pgs-core' ) => 'brown'       ,
			esc_html__( 'Brown Dark'    , 'pgs-core' ) => 'brown-dark'  ,
			esc_html__( 'Yellow Default', 'pgs-core' ) => 'yellow'      ,
			esc_html__( 'Yellow Dark'   , 'pgs-core' ) => 'yellow-dark' ,
			esc_html__( 'Black Default' , 'pgs-core' ) => 'black'       ,
			esc_html__( 'Black Light'   , 'pgs-core' ) => 'black-light' ,
			esc_html__( 'White Default' , 'pgs-core' ) => 'white'       ,
		),
		'dependency'=> array(
			'element'=> 'style',
			'value'  => array( 'flat-color' ),
		),
	),
	array(
		'type'      => 'checkbox',
		'heading'   => esc_html__( '3d?', 'pgs-core' ),
		'param_name'=> 'button_3d',
		'dependency'=> array(
			'element'=> 'style',
			'value'  => array( 'default', 'flat-color' ),
		),
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Size', 'pgs-core' ),
		'param_name' => 'size',
		'description'=> esc_html__( 'Select button display size.', 'pgs-core' ),
		'std'        => 'medium',
		'value'      => array(
			esc_html__( 'Small', 'pgs-core' ) => 'small',
			esc_html__( 'Medium', 'pgs-core' )=> 'medium',
			esc_html__( 'Big', 'pgs-core' )   => 'big',
		)
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Shape', 'pgs-core' ),
		'param_name' => 'shape',
		'description'=> esc_html__( 'Select button shape.', 'pgs-core' ),
		'std'        => 'square',
		'value'      => array(
			esc_html__( 'Square', 'pgs-core' ) => 'square',
			esc_html__( 'Rounded', 'pgs-core' )=> 'rounded',
			esc_html__( 'Round', 'pgs-core' )  => 'full-rounded',
		)
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Alignment', 'pgs-core' ),
		'param_name' => 'align',
		'description'=> esc_html__( 'Select button alignment.', 'pgs-core' ),
		'value'      => array(
			esc_html__( 'Inline', 'pgs-core' )=> 'inline',
			esc_html__( 'Left', 'pgs-core' )  => 'left',
			esc_html__( 'Right', 'pgs-core' ) => 'right',
			esc_html__( 'Center', 'pgs-core' )=> 'center',
		),
	),
	array(
		'type'      => 'checkbox',
		'heading'   => esc_html__( 'Set full width button?', 'pgs-core' ),
		'param_name'=> 'button_block',
		'dependency'=> array(
			'element'           => 'align',
			'value_not_equal_to'=> 'inline',
		),
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Animation', 'pgs-core' ),
		'param_name' => 'animation',
		'description'=> esc_html__( 'Select button animation.', 'pgs-core' ),
		'std'        => 'none',
		'value'      => array(
			esc_html__( 'None', 'pgs-core' )       => 'none',
			esc_html__( 'Left Fill', 'pgs-core' )  => 'left-fill',
			esc_html__( 'Middle Fill', 'pgs-core' )=> 'middle-fill',
			esc_html__( 'Button Fill', 'pgs-core' )=> 'button-fill',
		)
	),
	array(
		'type'      => 'checkbox',
		'heading'   => esc_html__( 'Add icon?', 'pgs-core' ),
		'param_name'=> 'add_icon',
	),
	array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Icon Alignment', 'pgs-core' ),
		'description'=> esc_html__( 'Select icon alignment.', 'pgs-core' ),
		'param_name' => 'alignment',
		'value'      => array(
			esc_html__( 'Left', 'pgs-core' ) => 'left',
			esc_html__( 'Right', 'pgs-core' ) => 'right',
		),
		'dependency' => array(
			'element' => 'add_icon',
			'value' => 'true',
		),
	),
	array(
		'type'      => 'checkbox',
		'heading'   => esc_html__( 'Icon Revealing Effect?', 'pgs-core' ),
		'param_name'=> 'icon_animation',
		'dependency'=> array(
			'element'=> 'add_icon',
			'value'  => 'true',
		),
	),
);

$shortcode_fields = array_merge(
	$shortcode_fields,
	pgscore_iconpicker( array(
		'dependency' => array(
			'element'=> 'add_icon',
			'value'  => 'true',
		),
	) )
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Button", 'pgs-core' ),
	"description"            => esc_html__( "Add styled buttons.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}