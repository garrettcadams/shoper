<?php
/******************************************************************************
 * 
 * Shortcode : pgscore_stepfeaturetext
 * 
 ******************************************************************************/
function pgscore_shortcode_stepfeaturetext( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(		
		'step_feature_text_alignment'	=> 'step_feature-text-left',
		'title'           				=> '',
		'title_type'      => 'h4',
		'description'     				=> '',
		'step_counter'    				=> '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	// Return shortcode if no required content found to display the shortcode perfectly.
	if( empty( $title ) || empty( $step_counter ) || empty( $description ) ) {
		return;
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('stepfeaturetext/content');?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 * 
 * Visual Composer Integration
 * 
 ******************************************************************************/
$shortcode_fields = array(
	array(
		'type'            => 'pgscore_radio_image2',
		"heading"         => esc_html__("Style", 'pgs-core'),
		'param_name'      => 'step_feature_text_alignment',
		'options'         => array(
			array(
				'value' => 'step_feature-text-left',
				'title' => 'Left',
				'image' => PGSCORE_URL . '/images/vc_options/step-feature-text/step_feature-text-left.png',
			),
			array(
				'value' => 'step_feature-text-center',
				'title' => 'Center',
				'image' => PGSCORE_URL . '/images/vc_options/step-feature-text/step_feature-text-center.png',
			),
			array(
				'value' => 'step_feature-text-right',
				'title' => 'Right',
				'image' => PGSCORE_URL . '/images/vc_options/step-feature-text/step_feature-text-right.png',
			),
		),
		'show_label'      => true,
		'admin_label'     => true,
	),
	array(
		"type"        => "textfield",
		"heading"     => esc_html__("Title", 'pgs-core'),
		"description" => esc_html__("Enter title.", 'pgs-core'),
		"param_name"  => "title",
		'admin_label' => true,
	),
	array(
		"type"        => "dropdown",
		"class"       => "",
		"heading"     => esc_html__("Title Type", 'pgs-core'),				
		"param_name"  => "title_type",
		"std"         => "h4",
		'value'     => array_flip(array(
			'h2'  => esc_html__( 'H2', 'pgs-core' ),
			'h3'  => esc_html__( 'H3', 'pgs-core' ),
			'h4'  => esc_html__( 'H4', 'pgs-core' ),
			'h5'  => esc_html__( 'H5', 'pgs-core' ),
			'h6'  => esc_html__( 'H6', 'pgs-core' ),
		)),
		'admin_label'     => true,
	),
	array(
		"type"        => "textarea",
		"heading"     => esc_html__("Description", 'pgs-core'),
		"description" => esc_html__("Enter description. Please ensure to add short content.", 'pgs-core'),
		"param_name"  => "description",
		'admin_label' => true,
	),
	array(
		'type'            => 'pgscore_number_min_max',
		'heading'         => esc_html__( "Step Counter", 'pgs-core' ),
		'param_name'      => 'step_counter',
		'value'           => '',
		'min'             => '1',
		'max'             => '99',
		'description'     => esc_html__('Enter step counter number.','pgs-core'),
		'admin_label'     => true,
	),
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Step Feature Text", 'pgs-core' ),
	"description"            => esc_html__( "Display feature texts with step number.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}