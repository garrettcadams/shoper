<?php
/******************************************************************************
 *
 * Shortcode : pgscore_clients
 *
 ******************************************************************************/
function pgscore_shortcode_clients( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'style'        	  => 'slider',
		'slider_elements' => 'pagination',
		'grid_elements'   => '2',
		'slides'          => '',
			// 'title'           => '',
			// 'image_link'  	 => '|||',
			// 'slide_image'     => '',
		'img_size'        => 'full',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	$slides = vc_param_group_parse_atts( $atts[ 'slides' ] );
	
	// Return shortcode if no required content found to display the shortcode perfectly.
	if( !is_array( $slides ) || empty( $slides ) ) {
		return;
	}
	
	/*********************************************
	 * 
	 * Check for thumbnail size
	 * 
	 *********************************************/
	if( empty($img_size) ){
		$img_size = 'full';
	}
	global $_wp_additional_image_sizes;
	
	$thumb_size = '';
	if ( is_string( $img_size ) && ( ( !empty( $_wp_additional_image_sizes[ $img_size ] ) && is_array( $_wp_additional_image_sizes[ $img_size ] ) ) || in_array( $img_size, array('thumbnail', 'thumb', 'medium', 'large', 'full') ) ) ) {
		$thumb_size = $img_size;
	}elseif( strpos($img_size, 'x') !== false) {
		$img_size = explode('x', $img_size);
		
		// Check for PHP version
		if (version_compare(PHP_VERSION, '5.3.0', '<')) { // PHP < 5.3
			$img_size = array_filter($img_size, create_function('$value', 'return $value !== "";'));
		}else{ // PHP 5.3 and later
			$img_size = array_filter($img_size, function($value) { return $value !== ''; });
		}
		
		if( count($img_size) == 2 && is_numeric($img_size[0]) && is_numeric($img_size[1]) ){
			$thumb_size = $img_size;
		}
	}
	if( empty($thumb_size) ){
		return;
	}
	
	/**********************************************************
	 *
	 * Element Classes
	 * For base wrapper
	 *
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['slides_data'] = $slides;
	$pgscore_shortcodes[$shortcode_handle]['thumb_size'] = $thumb_size;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('clients/content' );?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 *
 * Visual Composer Integration
 *
 ******************************************************************************/
$shortcode_fields = array(
	array(
		'type'      => 'dropdown',
		'heading'   => esc_html__( 'Style', 'pgs-core' ),
		'param_name'=> 'style',
		'value'     => array(
			esc_html__( 'Slider', 'pgs-core' ) => 'slider',
			esc_html__( 'Grid', 'pgs-core' )   => 'grid',
		),
		'description' => esc_html__( 'Select style. ', 'pgs-core' ),
		'admin_label'=> true,
	),
	array(
		'type'      => 'dropdown',
		'heading'   => esc_html__( 'Slider Navigations', 'pgs-core' ),
		'param_name'=> 'slider_elements',
		'value'     => array_flip( array(
			'pagination'=> esc_html__( 'Pagination Control', 'pgs-core' ),
			'prevnext'  => esc_html__( 'Prev/Next Buttons', 'pgs-core' ),
			'both'      => esc_html__( 'Both', 'pgs-core' ),
		) ),
		'description' => esc_html__( 'Select slider navigations controls type.', 'pgs-core' ),
		'admin_label'=> true,
		'dependency'=> array(
			'element'=> 'style',
			'value'  => array(
				'slider',
			)
		),
	),
	array(
		'type'      => 'dropdown',
		'heading'   => esc_html__( 'Grid Columns', 'pgs-core' ),
		'param_name'=> 'grid_elements',
		'value'     => array(
			esc_html__( '2', 'pgs-core' ) => '2',
			esc_html__( '3', 'pgs-core' ) => '3',
			esc_html__( '4', 'pgs-core' ) => '4',
			esc_html__( '5', 'pgs-core' ) => '5',
		),
		'description'=> esc_html__( 'Select number of columns in Grid view.', 'pgs-core' ),
		'admin_label'=> true,
		'dependency' => array(
			'element'=> 'style',
			'value'  => array(
				'grid',
			)
		),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Image Size', 'pgs-core' ),
		'param_name'      => 'img_size',
		'value'           => 'full',
		'description'     => esc_html__( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "full" size.', 'pgs-core' ),
		'admin_label'     => true,
	),
	array(
		'type'       => 'param_group',
		"heading"     => esc_html__("Slides", 'pgs-core'),
		'value'      => '',
		'param_name' => 'slides',
		'params'     => array(
			array(
				"type"        => "textfield",
				"heading"     => esc_html__("Title", 'pgs-core'),
				"description" => esc_html__("Enter title.", 'pgs-core'),
				"param_name"  => "title",
				'admin_label' => true,
			),
			array(
				"type"        => "attach_image",
				"heading"     => esc_html__("Slide Image", 'pgs-core'),
				"param_name"  => "slide_image",
			),
			array(
				"type"        => "vc_link",
				"heading"     => esc_html__("Image Link", 'pgs-core'),
				"param_name"  => "image_link",
			),
		),
	),
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Clients Logo", 'pgs-core' ),
	"description"            => esc_html__( "Display clients logo as grid and carousel.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}