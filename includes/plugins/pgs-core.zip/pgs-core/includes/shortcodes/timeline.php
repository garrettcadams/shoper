<?php
/******************************************************************************
 * 
 * Shortcode : pgscore_timeline
 * 
 ******************************************************************************/
function pgscore_shortcode_timeline( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'style'                 => 'style-1',
		'shape'                 => 'square',
		'title_element'         => 'h4',
		// 'timeline_dateformat'=> 'j F Y',
		'list'                  => '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	$list_items = vc_param_group_parse_atts( $list );
	
	pgscore_array_sort_by_column($list_items, 'timeline_date');
	
	// Return shortcode if no required content found to display the shortcode perfectly.
	if( empty( $list_items ) ) {
		return;
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['list_items'] = $list_items;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('timeline/content' );?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 * 
 * Visual Composer Integration
 * 
 ******************************************************************************/
$shortcode_fields = array(
	array(
		'type'            => 'pgscore_radio_image',
		"heading"         => esc_html__("Style", 'pgs-core'),
		'param_name'      => 'style',
		'options'         => pgscore_get_shortcode_param_data('timeline'),
		'show_label'      => true,
		'admin_label'     => true,
	),
	array(
		'type'      => 'dropdown',
		'heading'   => esc_html__( 'Shape', 'pgs-core' ),
		'param_name'=> 'shape',
		'value'     => array(
			esc_html__( 'Square', 'pgs-core' ) 	=> 'square',
			esc_html__( 'Rounded', 'pgs-core' ) => 'rounded',
			esc_html__( 'Round', 'pgs-core' )   => 'round',
		),
		'description' => esc_html__( 'Select shape.', 'pgs-core' ),
		'admin_label'=> true,
	),
	/*
	array(
		"type"        => "textfield",
		"class"       => "",
		"heading"     => esc_html__("Date Format", 'pgs-core'),
		"param_name"  => "timeline_dateformat",
		"std"         => "j F Y",
		"description"=> '<a href="https://codex.wordpress.org/Formatting_Date_and_Time">' . esc_html__( "Check this for more information on date formatting.", "pgs-core" ).'</a>',
	),
	*/
	array(
		"type"        => "dropdown",
		"class"       => "",
		"heading"     => esc_html__("Title Element", 'pgs-core'),				
		"param_name"  => "title_element",
		"std"         => "h4",
		'value'     => array_flip(array(
			'h2'  => esc_html__( 'H2', 'pgs-core' ),
			'h3'  => esc_html__( 'H3', 'pgs-core' ),
			'h4'  => esc_html__( 'H4', 'pgs-core' ),
			'h5'  => esc_html__( 'H5', 'pgs-core' ),
			'h6'  => esc_html__( 'H6', 'pgs-core' ),
		)),
		'admin_label'=> true,
	),
	array(
		'type'       => 'param_group',
		'value'      => '',
		'param_name' => 'list',
		"heading"     => esc_html__("Timeline Data", 'pgs-core'),
		'params'     => array(
			array(
				"type"        => "textfield",
				"class"       => "",
				"heading"     => esc_html__("Title", 'pgs-core'),
				"param_name"  => "timeline_title",
				'admin_label' => true,
			),
			array(
				"type"        => "textarea",
				"class"       => "",
				"heading"     => esc_html__("Description", 'pgs-core'),
				"param_name"  => "timeline_description",
			),
			array(
				"type"       => "pgscore_datepicker",
				"class"      => "timeline_date",
				"heading"    => esc_html__( "Date", "pgs-core" ),
				"param_name" => "timeline_date",
				"value"      => '',
				"description"=> esc_html__( "Enter date. [YYYY-MM-DD]", "pgs-core" ),
				'admin_label' => true,
			),
		),
		'group'     => esc_html__( 'Timeline Data', 'pgs-core' ),
	),
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Timeline", 'pgs-core' ),
	"description"            => esc_html__( "Display timeline with date and content.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}