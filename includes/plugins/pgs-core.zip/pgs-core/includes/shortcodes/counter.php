<?php
/******************************************************************************
 * 
 * Shortcode : pgscore_counter
 * 
 ******************************************************************************/
function pgscore_shortcode_counter( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'style'           => 'style_1',
		'title'           => '',
		'counter'         => '',
		'icon_style'      => 'default',
		'icon_shape'      => 'square',
		'icon_type'       => 'fontawesome',
		'icon_fontawesome'=> 'fa fa-chevron-right',
		'icon_openiconic' => 'vc-oi vc-oi-right',
		'icon_typicons'   => 'typcn typcn-chevron-right',
		'icon_entypo'     => 'entypo-icon entypo-icon-right-open',
		'icon_linecons'   => 'vc_li vc_li-heart',
		'icon_monosocial' => 'vc-mono vc-mono-fivehundredpx',
		'icon_material'   => 'vc-material vc-material-cake',
		'icon_pixelicons' => 'vc_pixel_icon vc_pixel_icon-alert',
		'icon_flaticon'   => 'glyph-icon flaticon-right-arrow-1',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	// Return shortcode if no required content found to display the shortcode perfectly.
	if( empty( $title ) || empty($counter) ) {
		return;
	}
	
	/**********************************************************
	 * 
	 * Icons Settings
	 * 
	 **********************************************************/
	$icon_html  = '';
	$enable_icon= true;
	
	if( $enable_icon ){
		$icon_wrapper = false;
		if ( isset( ${'icon_' . $icon_type} ) && !empty(${'icon_' . $icon_type}) ) {
			if ( 'pixelicons' === $icon_type ) {
				$icon_wrapper = true;
			}
			$icon_class = ${'icon_' . $icon_type};
		} else {
			$icon_class = 'fa fa-adjust';
		}
		
		if ( $icon_wrapper ) {
			$icon_html = '<i class="icon_wrap"><span class="' . esc_attr( $icon_class ) . '"></span></i>';
		} else {
			$icon_html = '<i class="' . esc_attr( $icon_class ) . '"></i>';
		}
		
		// Enqueue icon CSS for icon type
		vc_icon_element_fonts_enqueue( $icon_type );
	}
	
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts']       = $atts;
	$pgscore_shortcodes[$shortcode_handle]['icon_html']  = $icon_html;
	$pgscore_shortcodes[$shortcode_handle]['enable_icon']= $enable_icon;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('counter/content' );?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 * 
 * Visual Composer Integration
 * 
 ******************************************************************************/
$shortcode_fields = array(
	array(
		'type'            => 'pgscore_radio_image',
		"heading"         => esc_html__("Style", 'pgs-core'),
		'param_name'      => 'style',
		'options'         => pgscore_get_shortcode_param_data('counter'),
		'show_label'      => true,
		'admin_label'     => true,
	),
	array(
		"type"            => "textfield",
		"heading"         => esc_html__("Title", 'pgs-core'),
		"description"     => esc_html__("Enter title.", 'pgs-core'),
		"param_name"      => "title",
		'admin_label'     => true,
		'edit_field_class'=> 'vc_col-sm-9 vc_column',
	),
	array(
		'type'            => 'pgscore_number_min_max',
		'heading'         => esc_html__( "Counter", 'pgs-core' ),
		'param_name'      => 'counter',
		'min'             => '1',
		'max'             => '9999999',
		'description'     => esc_html__('Enter counter count.','pgs-core'),
		'admin_label'     => true,
		'edit_field_class'=> 'vc_col-sm-3 vc_column',
	),
	array(
		'type'      => 'dropdown',
		'heading'   => esc_html__( 'Icon Style', 'pgs-core' ),
		'param_name'=> 'icon_style',
		'value'     => array(
			esc_html__( 'Default', 'pgs-core' )=> 'default',
			esc_html__( 'Border', 'pgs-core' ) => 'border',
			esc_html__( 'Flat', 'pgs-core' )   => 'flat',
		),
		'description' => esc_html__( 'Select icon style.', 'pgs-core' ),
		'dependency'      => array(
			'element' => 'style',
			'value'   => array('style_1','style_2','style_3','style_7','style_8'),
		),
		'admin_label'=> true,
		'edit_field_class'=> 'vc_col-sm-6 vc_column',
	),
	array(
		'type'      => 'dropdown',
		'heading'   => esc_html__( 'Icon Shape', 'pgs-core' ),
		'param_name'=> 'icon_shape',
		'value'     => array(
			esc_html__( 'Square', 'pgs-core' ) 	=> 'square',
			esc_html__( 'Rounded', 'pgs-core' ) => 'rounded',
			esc_html__( 'Round', 'pgs-core' )   => 'round',
		),
		'description' => esc_html__( 'Select icon shape.', 'pgs-core' ),
		'dependency'      => array(
			'element' => 'icon_style',
			'value'   => array('border','flat'),
		),
		'admin_label'=> true,
		'edit_field_class'=> 'vc_col-sm-6 vc_column',
	),

);

$shortcode_fields = array_merge(
	$shortcode_fields,
	pgscore_iconpicker()
);
	
$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                    => esc_html__( "Counter", 'pgs-core' ),
	"description"             => esc_html__( "Display counter.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}