<?php
/******************************************************************************
 * 
 * Shortcode : pgscore_skillsbar
 * 
 ******************************************************************************/
function pgscore_shortcode_skillsbar( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'style'           => 'horizontal',
		'skill_bar_style' => 'skill-large',
		'text_position'   => 'position-top',
		'list'           => '',
		'skillbar_style' => '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	$list_items = vc_param_group_parse_atts( $atts[ 'list' ] );
	
	// Return shortcode if no required content found to display the shortcode perfectly.
	if( !is_array( $list_items ) || empty( $list_items ) ) {
		return;
	}
		
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['list_items'] = $list_items;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('skillsbar/content');?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 * 
 * Visual Composer Integration
 * 
 ******************************************************************************/
$shortcode_fields = array(
	array(
		'type'            => 'pgscore_radio_image',
		"heading"         => esc_html__("Style", 'pgs-core'),
		'param_name'      => 'style',
		'options'         => pgscore_get_shortcode_param_data('skills-bar'),
		'show_label'      => true,
		'admin_label'     => true,
	),
	array(
		'type'      => 'dropdown',
		'heading'   => esc_html__( 'Skill Bar Size', 'pgs-core' ),
		'param_name'=> 'skill_bar_style',
		'value'     => array(
			esc_html__( 'Large', 'pgs-core' ) => 'skill-large',
			esc_html__( 'Medium', 'pgs-core' ) => 'skill-medium',
			esc_html__( 'Small', 'pgs-core' ) => 'skill-small',
		),
		'description' => esc_html__( 'Select skill bar size.', 'pgs-core' ),
		'admin_label' => true,
		'dependency'=> array(
			'element'=> 'style',
			'value'  => array( 'horizontal' ),
		),
	),
	array(
		'type'      => 'dropdown',
		'heading'   => esc_html__( 'Text Position', 'pgs-core' ),
		'param_name'=> 'text_position',
		'value'     => array(
			esc_html__( 'Top', 'pgs-core' ) => 'position-top',
			esc_html__( 'Bottom', 'pgs-core' ) => 'position-bottom',
		),
		'description' => esc_html__( 'Select Text Postion.', 'pgs-core' ),
		'admin_label' => true,
		'dependency'=> array(
			'element'=> 'style',
			'value'  => array( 'horizontal' ),
		),
	),
	array(
		'type'      => 'dropdown',
		'heading'   => esc_html__( 'Skill Bar Style', 'pgs-core' ),
		'param_name'=> 'skillbar_style',
		'value'     => array(
			esc_html__( 'Default', 'pgs-core' ) => '',
			esc_html__( 'Rounded', 'pgs-core' ) => 'skill-style-rounded',
			esc_html__( 'Border', 'pgs-core' ) => 'skill-style-border',
		),
		'description' => esc_html__( 'Select skill bar style.', 'pgs-core' ),
		'admin_label' => true,
		'dependency'=> array(
			'element'=> 'style',
			'value'  => array( 'horizontal' ),
		),
	),
	array(
		'type'       => 'param_group',
		'value'      => '',
		'param_name' => 'list',
		'params'     => array(
			array(
				"type"        => "textfield",
				"class"       => "",
				"heading"     => esc_html__( "Bar Label", 'pgs-core' ),
				"description" => esc_html__( "Enter bar label.", 'pgs-core' ),
				"param_name"  => "bar_label",
				'holder'      => 'h1',
				'admin_label' => true,
			),
			array(
				'type'            => 'pgscore_number_min_max',
				'heading'         => esc_html__( "Bar Percent", 'pgs-core' ),
				'param_name'      => 'bar_percent',
				'value'           => '',
				'min'             => '1',
				'max'             => '100',
				'suffix'          => '%',
				'description'     => esc_html__( 'Enter bar percent.','pgs-core' ),
				'holder'          => 'span',
				'admin_label'     => true,
			),
		),
	),
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Skill Bar", 'pgs-core' ),
	"description"            => esc_html__( "Displays skill bar.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}