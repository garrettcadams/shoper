<?php
/******************************************************************************
 *
 * Shortcode : pgscore_testimonials
 *
 ******************************************************************************/

if( !current_theme_supports('pgs_testimonials') ) return; // Return if custom post type is not supported

function pgscore_shortcode_testimonials( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'style'         => 'style-1',
		'color'         => 'color-scheme',
		'columns'       => 1,
		'posts_per_page'=> 3,
		'categories'    => '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract($atts);
	
	$args = array(
		'post_type'          => 'testimonials',
		'posts_per_page'     => ( !empty( $posts_per_page ) && is_numeric($posts_per_page) ) ? $posts_per_page : 3,
		'post_status'        => array('publish'),
		'ignore_sticky_posts'=> true,
	);
	
	if( !empty($categories) ){
		$categories_array = explode(',', $categories);
		if( is_array($categories_array) && !empty($categories_array) ){
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'testimonial-category',
					'field'    => 'term_id',
					'terms'    => $categories_array
				)
			);
		}
	}
	
	$the_query = new WP_Query( $args );
	if ( !$the_query->have_posts() ) {
		return;
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['the_query'] = $the_query;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('testimonials/content' );?>
	</div><!-- shortcode-base-wrapper-end -->
	<?php
	return ob_get_clean();
}

/******************************************************************************
 *
 * Visual Composer Integration
 *
 ******************************************************************************/
$testimonial_categories = pgscore_get_terms( array( // You can pass arguments from get_terms (except hide_empty)
	'taxonomy'  => 'testimonial-category',
	'pad_counts'  => true,
));

$shortcode_fields = array(
	array(
		'type'            => 'pgscore_radio_image',
		"heading"         => esc_html__("Style", 'pgs-core'),
		'param_name'      => 'style',
		'options'         => pgscore_get_shortcode_param_data('testimonials'),
		'show_label'      => true,
		'admin_label'     => true,
	),
	array(
		"type"        => "dropdown",
		"class"       => "",
		"heading"     => esc_html__("Color", 'pgs-core'),
		"description" => esc_html__("Select testimonials color.", 'pgs-core'),
		"param_name"  => "color",
		"value"       => array(
			esc_html__( "Color Scheme", 'pgs-core' )=> 'color-scheme',
			esc_html__( "White", 'pgs-core' )       => 'white',
			esc_html__( "Transparent", 'pgs-core' ) => 'transparent',
		),
		'admin_label'=> true,
	),
	array(
		'type'       => 'pgscore_number_min_max',
		'heading'    => esc_html__( "Count", 'pgs-core' ),
		'param_name' => 'posts_per_page',
		'value'      => '3',
		'min'        => '1',
		'max'        => '10',
		'description'=> esc_html__('Enter number of testimonial items to display.','pgs-core'),
		'admin_label'=> true,
	),
	array(
		"type"        => "dropdown",
		"class"       => "",
		"heading"     => esc_html__("Columns", 'pgs-core'),
		'description'=> esc_html__('Enter number of testimonial columns to display.','pgs-core'),
		"param_name"  => "columns",
		"value"       => array(
			esc_html__( "1", 'pgs-core' )=> 1,
			esc_html__( "2", 'pgs-core' )=> 2,
		),
		'admin_label'=> true,
	),
	array(
		'type'       => 'checkbox',
		'heading'    => esc_html__('Categories', 'pgs-core'),
		'param_name' => 'categories',
		'description'=> esc_html__('Select categories to limit result from. To display result from all categories leave all categories unselected.', 'pgs-core'),
		'value'      => $testimonial_categories,
		'admin_label'=> true,
	),
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Testimonials", 'pgs-core' ),
	"description"            => esc_html__( "Display testimonials.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}