<?php
if( ! (function_exists('is_plugin_active') && is_plugin_active('woocommerce/woocommerce.php') ) ) return;
/******************************************************************************
 * 
 * Shortcode : pgscore_multi_tab_slider
 * 
 ******************************************************************************/
function pgscore_shortcode_multi_tab_slider( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'number_of_item'  => 5,
		"categories"      => "",
		'selected_tabs'   => 'pgs_new_arrivals',
		'add_title'       => false,
		"title"           => "",
		'add_icon'        => false,
		'icon_type'       => 'fontawesome',
		'icon_fontawesome'=> 'fa fa-info-circle',
		'icon_openiconic' => 'vc-oi vc-oi-dial',
		'icon_typicons'   => 'typcn typcn-adjust-brightness',
		'icon_entypo'     => 'entypo-icon entypo-icon-note',
		'icon_linecons'   => 'vc_li vc_li-heart',
		'icon_monosocial' => 'vc-mono vc-mono-fivehundredpx',
		'icon_material'   => 'vc-material vc-material-cake',
		'icon_pixelicons' => 'vc_pixel_icon vc_pixel_icon-alert',
		'icon_flaticon'   => '',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	
	extract($atts);
	
	// Tabs
	$mts_default_tabs = array(
		'pgs_new_arrivals' => esc_html__('Newest', 'pgs-core'),
		'pgs_featured'     => esc_html__('Featured', 'pgs-core'),
		'pgs_best_sellers' => esc_html__('Best Sellers', 'pgs-core'),
		'pgs_on_sale'      => esc_html__('On sale', 'pgs-core'),
		'pgs_cheapest'     => esc_html__('Cheapest', 'pgs-core'),
	);
	
	$mts_default_tabs_keys = array_keys($mts_default_tabs);
	
	// Set Icon
	$icon = '';
	if( !empty($add_icon) ){
		if ( isset( ${'icon_' . $icon_type} ) && !empty(${'icon_' . $icon_type}) ) {
			$icon = ${'icon_' . $icon_type};
			vc_icon_element_fonts_enqueue( $icon_type );
		}
	}
	
	// Prepare selected categories
	$categories = (!empty($categories))? explode(',',$categories):array();
	
	$mts_tabs = array_keys($mts_default_tabs);
	
	$selected_tabs = trim($selected_tabs);
	if( !empty($selected_tabs) ){
		
		// Prepare array from comma separated tabs
		$selected_tabs_array = explode( ',', $selected_tabs );
		
		// Verify provided tabs with default tabs. If no valdid tabs found, use all tabs instead.
		$product_type_tabs_result = array_intersect($mts_default_tabs_keys, $selected_tabs_array);
		if( !empty($product_type_tabs_result) ){
			$mts_tabs = $product_type_tabs_result;
		}
	}
	
	// Return if no tabs.
	if( empty($mts_tabs) ){
		return;
	}
	
	$tabs_data = array();
	$tabs_data_count = 0;
	foreach( $mts_tabs as $mts_tabs_k ){
		$tabs_data[$mts_tabs_k]['tab_slug'] = $mts_tabs_k;
		
		$args = array(
			'post_type'     => 'product',
			'posts_status'  => 'publish',
			'posts_per_page'=> $number_of_item,
		);

		if(!empty($categories)){
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $categories,
				),
			);
		}
		
		/* Featured product */
		if( $mts_tabs_k == 'pgs_featured' ){
			$args['meta_query'] = array(
				array(
					'key'     => '_featured',
					'value'   => 'yes',
					'compare' => '='
				),
			);
			
		/* On Sale product */
		}elseif( $mts_tabs_k == 'pgs_on_sale' ){
			$args['meta_query'] = array(
				array(
					'key'     => '_sale_price',
					'value'   => '',
					'compare' => '!='
				),
			);
		
		/* Best Sellers Product */
		}elseif( $mts_tabs_k == 'pgs_best_sellers' ){
			
			unset($args['meta_query']);
			$args['meta_key']      = 'total_sales';
			$args['meta_value_num']= 'total_sales';
			$args['orderby']       = 'meta_value_num';
			$args['order']         = 'DESC';
		
		/* Cheapest Product */
		}elseif( $mts_tabs_k == 'pgs_cheapest'){
			
			unset($args['meta_query']);
			$args['meta_key']      = '_price';
			$args['meta_value_num']= '_price';
			$args['orderby']       = 'meta_value_num';
			$args['order']         = 'ASC';
		}
		
		$loop = new WP_Query( $args );
		if ( $loop->have_posts() ) {
			$tabs_data_count++;
			$tabs_data[$mts_tabs_k]['tab_query'] = $loop;
			$tabs_data[$mts_tabs_k]['tab_status'] = true;
		}else{
			$tabs_data[$mts_tabs_k]['tab_status'] = false;
		}
	}
	
	if( $tabs_data_count == 0 ){
		return;
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	**********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['icon'] = $icon;
	$pgscore_shortcodes[$shortcode_handle]['mts_default_tabs'] = $mts_default_tabs;
	$pgscore_shortcodes[$shortcode_handle]['tabs_data'] = $tabs_data;
	
	/* Featured-product */	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('multi_tab_slider/content' );?>
	</div><!-- shortcode-base-wrapper-end -->
	<?php	
	return ob_get_clean();
}

/******************************************************************************
 * 
 * Visual Composer Integration
 * 
 ******************************************************************************/
// Tabs
$mts_default_tabs = array(
	'pgs_new_arrivals' => esc_html__('Newest', 'pgs-core'),
	'pgs_featured'     => esc_html__('Featured', 'pgs-core'),
	'pgs_best_sellers' => esc_html__('Best Sellers', 'pgs-core'),
	'pgs_on_sale'      => esc_html__('On sale', 'pgs-core'),
	'pgs_cheapest'     => esc_html__('Cheapest', 'pgs-core'),
);

$categories_hierarchy = get_terms_hierarchy( 'product_cat' );
$categories_flat = get_terms_hierarchical_list( $categories_hierarchy );
$categories_list = array();
foreach( $categories_flat as $term_id => $term ){
	$categories_list[ $term->name .' ('.$term->count.')' ] = $term_id;
}

$shortcode_fields = array(
	array(
		'type'       => 'checkbox',
		'heading'    => esc_html__( 'Categories', 'pgs-core' ),
		'param_name' => 'categories',
		'value'      => $categories_list,
		'save_always'=> true,
		'admin_label'=> true,
	),
	array(
		'type'       => 'checkbox',
		'heading'    => esc_html__( 'Tabs', 'pgs-core' ),
		'param_name' => 'selected_tabs',
		'value'      => array_flip($mts_default_tabs),
		'save_always' => true,                
		'description' => esc_html__( 'Select tab(s) to display on front page. If no tab type is selected, all tabs will be displayed.', 'pgs-core' ),
		'admin_label'=> true,
	),
	array(
		"type"       => "textfield",
		"class"      => "",
		"heading"    => esc_html__("Number of item", 'pgs-core'),
		"param_name" => "number_of_item",
		'admin_label'=> true,
	),
	array(
		'type'      => 'checkbox',
		'heading'   => esc_html__( 'Add title?', 'pgs-core' ),
		'param_name'=> 'add_title',
	),
	array(
		"type"       => "textfield",
		"class"      => "",
		"heading"    => esc_html__("Title", 'pgs-core'),
		"description"=> esc_html__("Leave blank if don't want to show", 'pgs-core'),
		"param_name" => "title",
		'admin_label'=> true,
		'dependency' => array(
			'element' => 'add_title',
			'value'   => 'true',
		),
	),
	array(
		'type'      => 'checkbox',
		'heading'   => esc_html__( 'Add icon?', 'pgs-core' ),
		'param_name'=> 'add_icon',
		'dependency' => array(
			'element' => 'add_title',
			'value'   => 'true',
		),
	),
);

$pgscore_iconpicker_args = array(
	'dependency' => array(
		'element'=> 'add_icon',
		'value'  => 'true',
	),
);

$shortcode_fields = array_merge(
	$shortcode_fields,
	pgscore_iconpicker($pgscore_iconpicker_args)
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Multi Tab Slider", 'pgs-core' ),
	"description"            => esc_html__( "Display products in multi tab slider.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}