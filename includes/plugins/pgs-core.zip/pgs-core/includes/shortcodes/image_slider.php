<?php
/******************************************************************************
 * 
 * Shortcode : pgscore_image_slider
 * 
 ******************************************************************************/
function pgscore_shortcode_image_slider( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'img_size'               => 'pgscore-slider-thumbnail',
		'slides_per_view'        => 3,
		'slides_per_view_xx'     => '',
		'slides_per_view_xs'     => '',
		'slides_per_view_sm'     => '',
		'slides_per_view_md'     => '',
		'slide_margin'           => '',
		'show_pagination_control'=> '',
		'show_prev_next_buttons' => '',
		'enable_infinity_loop'   => '',
		'enable_caption'         => false,
		'slides'                 => '',
			// 'image'             => '',
			// 'title'             => '',
			// 'subtitle'          => '',
			// 'onclick'           => 'link_no',
			// 'custom_link'       => '|||',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract( $atts );
	
	/*********************************************
	 * 
	 * Check for slides
	 * 
	 *********************************************/
	$slides_data = vc_param_group_parse_atts( $slides );
	
	if( !is_array( $slides_data ) || empty( $slides_data ) || ( (count($slides_data) == 1) && empty( $slides_data[0] ) ) ) {
		return;
	}
	
	/*********************************************
	 * 
	 * Check for thumbnail size
	 * 
	 *********************************************/
	if( empty($img_size) ){
		$img_size = 'pgscore-slider-thumbnail';
	}
	global $_wp_additional_image_sizes;
	
	$thumb_size = '';
	if ( is_string( $img_size ) && ( ( !empty( $_wp_additional_image_sizes[ $img_size ] ) && is_array( $_wp_additional_image_sizes[ $img_size ] ) ) || in_array( $img_size, array('thumbnail', 'thumb', 'medium', 'large', 'full') ) ) ) {
		$thumb_size = $img_size;
	}elseif( strpos($img_size, 'x') !== false) {
		$img_size = explode('x', $img_size);
		
		// Check for PHP version
		if (version_compare(PHP_VERSION, '5.3.0', '<')) { // PHP < 5.3
			$img_size = array_filter($img_size, create_function('$value', 'return $value !== "";'));
		}else{ // PHP 5.3 and later
			$img_size = array_filter($img_size, function($value) { return $value !== ''; });
		}
		
		if( count($img_size) == 2 && is_numeric($img_size[0]) && is_numeric($img_size[1]) ){
			$thumb_size = $img_size;
		}
	}
	if( empty($thumb_size) ){
		return;
	}
	
	foreach( $slides_data as $slide_tk => $slide_td  ){
		if( empty($slide_td['image']) ){
			unset($slides_data[$slide_tk]);
		}else{
			$image_thumb = wp_get_attachment_image_src($slide_td['image'], $thumb_size, false);
			$image_full  = wp_get_attachment_image_src($slide_td['image'], 'full', false);
			
			if( empty($image_thumb[0]) ){
				unset($slides_data[$slide_tk]);
			}else{
				$slides_data[$slide_tk]['image_thumbnail'] = $image_thumb[0];
				$slides_data[$slide_tk]['image_url'] = $image_full[0];
			}
		}
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['slides_data'] = $slides_data;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('image_slider/content' );?>
	</div>
	<!-- Shortcode Base Wrapper -->
	<?php
	return ob_get_clean();
}

/******************************************************************************
 * 
 * Visual Composer Integration
 * 
 ******************************************************************************/
$shortcode_fields = array(
	array(
		'type'            => 'checkbox',
		'heading'         => esc_html__( 'Enable Caption', 'pgs-core' ),
		'param_name'      => 'enable_caption',
		'admin_label'     => true,
		'description'     => esc_html__( 'Select this to enable caption on slides.', 'pgs-core' ),
		'group'           => esc_html__( 'Slides', 'pgs-core' ),
	),
	array(
		'type'            => 'param_group',
		'value'           => '',
		'param_name'      => 'slides',
		'params'          => array(
			array(
				"type"            => "attach_image",
				"heading"         => esc_html__("Slide Image", 'pgs-core'),
				"param_name"      => "image",
			),
			array(
				"type"            => "textfield",
				"heading"         => esc_html__("Title", 'pgs-core'),
				"param_name"      => "title",
				'description'     => esc_html__( 'This will be displayed only if Enable Caption is selected.', 'pgs-core' ),
				'edit_field_class'=> 'vc_col-sm-6 vc_column',
				'admin_label'     => true,
			),
			array(
				"type"            => "textfield",
				"heading"         => esc_html__("Subtitle", 'pgs-core'),
				"param_name"      => "subtitle",
				'description'     => esc_html__( 'This will be displayed only if Enable Caption is selected.', 'pgs-core' ),
				'edit_field_class'=> 'vc_col-sm-6 vc_column',
				'admin_label'     => true,
			),
			array(
				'type'            => 'dropdown',
				'heading'         => esc_html__( 'On Click Action', 'pgs-core' ),
				'param_name'      => 'onclick',
				'value'           => array(
					esc_html__( 'None', 'pgs-core' )            => 'link_no',
					esc_html__( 'Open prettyPhoto', 'pgs-core' )=> 'link_image',
					esc_html__( 'Open Custom Link', 'pgs-core' )=> 'custom_link',
				),
				'description'     => esc_html__( 'Select action for click event.', 'pgs-core' ),
				'edit_field_class'=> 'vc_col-sm-4 vc_column',
			),
			array(
				'type'            => 'vc_link',
				'heading'         => esc_html__( 'Custom Link', 'pgs-core' ),
				'param_name'      => 'custom_link',
				'description'     => esc_html__( 'Add custom link.', 'pgs-core' ),
				'edit_field_class'=> 'vc_col-sm-4 vc_column',
			),
		),
		'group'    => esc_html__( 'Slides', 'pgs-core' ),
	),
	array(
		'type'            => 'textfield',
		'heading'         => esc_html__( 'Carousel size', 'pgs-core' ),
		'param_name'      => 'img_size',
		'value'           => 'pgscore-slider-thumbnail',
		'description'     => esc_html__( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "pgscore-slider-thumbnail" size.', 'pgs-core' ),
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		'admin_label'     => true,
	),
	array(
		'type'            => 'checkbox',
		'heading'         => esc_html__( 'Show Pagination Control', 'pgs-core' ),
		'param_name'      => 'show_pagination_control',
		'description'     => esc_html__( 'Check this checkbox to display pagination controls.', 'pgs-core' ),
		'value'           => array( esc_html__( 'Yes', 'pgs-core' )=> 'yes' ),
		'edit_field_class'=> 'vc_col-sm-6 vc_column',
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		'admin_label'     => true,
	),
	array(
		'type'            => 'checkbox',
		'heading'         => esc_html__( 'Show Prev/Next Buttons', 'pgs-core' ),
		'param_name'      => 'show_prev_next_buttons',
		'description'     => esc_html__( 'Check this checkbox to display prev/next buttons.', 'pgs-core' ),
		'value'           => array( esc_html__( 'Yes', 'pgs-core' )=> 'yes' ),
		'edit_field_class'=> 'vc_col-sm-6 vc_column',
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		'admin_label'     => true,
	),
	array(
		'type'            => 'checkbox',
		'heading'         => esc_html__( 'Infinity Loop', 'pgs-core' ),
		'param_name'      => 'enable_infinity_loop',
		'description'     => esc_html__( 'Check this checkbox to enable infinity loop and display carousel in circular loop.', 'pgs-core' ),
		'value'           => array( esc_html__( 'Yes', 'pgs-core' )=> 'yes' ),
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
		'admin_label'     => true,
	),
	array(
		'type'            => 'pgscore_number_min_max',
		'heading'         => esc_html__('Slides per view','pgs-core'),
		'param_name'      => 'slides_per_view',
		'min'             => '1',
		'max'             => '10',
		'value'           => '3',
		'description'     => esc_html__( 'Enter number of slides to display at the same time.', 'pgs-core' ),
		'admin_label'     => true,
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
	),
	array(
		'type'            => 'pgscore_heading',
		'heading'         => esc_html__('Slides Counts in Responsive View','pgs-core'),
		'param_name'      => 'responsive_slide_counts_header',
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
	),
	array(
		'type'            => 'pgscore_number_min_max',
		'heading'         => esc_html__('Slides per view ( < 480px)','pgs-core'),
		'param_name'      => 'slides_per_view_xx',
		'min'             => '1',
		'max'             => '10',
		'description'     => esc_html__( 'Enter number of slides to display at the same time.', 'pgs-core' ),
		'edit_field_class'=> 'vc_col-sm-3 vc_column',
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
	),
	array(
		'type'            => 'pgscore_number_min_max',
		'heading'         => esc_html__('Slides per view ( < 768px)','pgs-core'),
		'param_name'      => 'slides_per_view_xs',
		'min'             => '1',
		'max'             => '10',
		'description'     => esc_html__( 'Enter number of slides to display at the same time.', 'pgs-core' ),
		'edit_field_class'=> 'vc_col-sm-3 vc_column',
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
	),
	array(
		'type'            => 'pgscore_number_min_max',
		'heading'         => esc_html__('Slides per view ( < 992px)','pgs-core'),
		'param_name'      => 'slides_per_view_sm',
		'min'             => '1',
		'max'             => '10',
		'description'     => esc_html__( 'Enter number of slides to display at the same time.', 'pgs-core' ),
		'edit_field_class'=> 'vc_col-sm-3 vc_column',
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
	),
	array(
		'type'            => 'pgscore_number_min_max',
		'heading'         => esc_html__('Slides per view ( < 1200px)','pgs-core'),
		'param_name'      => 'slides_per_view_md',
		'min'             => '1',
		'max'             => '10',
		'description'     => esc_html__( 'Enter number of slides to display at the same time.', 'pgs-core' ),
		'edit_field_class'=> 'vc_col-sm-3 vc_column',
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
	),
	array(
		'type'            => 'pgscore_html',
		'heading'         => esc_html__('Responsive slide counts','pgs-core'),
		'param_name'      => 'responsive_slide_counts_header',
		'html'            => '<h4>'.esc_html__( 'Note: Count entered in "Slides per view" will be used for device width above 1200px.', 'pgs-core' ).'</h4>',
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
	),
	array(
		'type'            => 'pgscore_number_min_max',
		'heading'         => esc_html__('Margin','pgs-core'),
		'param_name'      => 'slide_margin',
		'min'             => '0',
		'max'             => '100',
		'value'           => '0',
		'description'     => esc_html__( 'Enter margin-right(px) on item.', 'pgs-core' ),
		'admin_label'     => true,
		'group'           => esc_html__( 'Slider Settings', 'pgs-core' ),
	),
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                   => esc_html__( "Image Slider", 'pgs-core' ),
	"description"            => esc_html__( "Display image slider/carousel.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);

if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}