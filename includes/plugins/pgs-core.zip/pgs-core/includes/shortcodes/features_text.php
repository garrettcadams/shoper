<?php
/******************************************************************************
 * 
 * Shortcode : pgscore_features_text
 * 
 ******************************************************************************/
function pgscore_shortcode_features_text( $atts, $content = null, $shortcode_handle = '' ) {
	$default_custom = array(
		'style'           => 'style_1',
		'title'           => '',
		'title_type'      => 'h3',
		'description'     => '',
		'enable_icon'     => true,
		'icon_source'     => 'icon', // icon, image
		'icon_style'      => 'default', // default, border, flat
		'icon_shape'      => 'square', // square, rounded, round (when icon type is image OR icon with icon-style border/flat)
		'icon_alignment'  => 'icon-top',
		'size'            => 'large',
		'icon_type'       => 'fontawesome',
		'icon_fontawesome'=> 'fa fa-chevron-right',
		'icon_openiconic' => 'vc-oi vc-oi-right',
		'icon_typicons'   => 'typcn typcn-chevron-right',
		'icon_entypo'     => 'entypo-icon entypo-icon-right-open',
		'icon_linecons'   => 'vc_li vc_li-heart',
		'icon_monosocial' => 'vc-mono vc-mono-fivehundredpx',
		'icon_material'   => 'vc-material vc-material-cake',
		'icon_pixelicons' => 'vc_pixel_icon vc_pixel_icon-alert',
		'icon_flaticon'   => 'glyph-icon flaticon-right-arrow-1',
	);
	
	$default_atts = apply_filters( 'pgscore_shortcode_atts-'.$shortcode_handle, $default_custom, $shortcode_handle );
	$atts = shortcode_atts( $default_atts, $atts, $shortcode_handle );
	extract( $atts );
	
	// Return shortcode if no required content found to display the shortcode perfectly.
	if( empty( $title ) || empty( $description ) ) {
		return null;
	}
	
	/**********************************************************
	 * 
	 * Icons Settings
	 * 
	 **********************************************************/
	$icon_html  = '';
	
	if( $enable_icon ){
		$icon_wrapper = false;
		if ( isset( ${'icon_' . $icon_type} ) && !empty(${'icon_' . $icon_type}) ) {
			if ( 'pixelicons' === $icon_type ) {
				$icon_wrapper = true;
			}
			$icon_class = ${'icon_' . $icon_type};
		} else {
			$icon_class = 'fa fa-adjust';
		}
		
		if ( $icon_wrapper ) {
			$icon_html = '<i class="icon_wrap"><span class="' . esc_attr( $icon_class ) . '"></span></i>';
		} else {
			$icon_html = '<i class="' . esc_attr( $icon_class ) . '"></i>';
		}
		
		// Enqueue icon CSS for icon type
		vc_icon_element_fonts_enqueue( $icon_type );
	}
	
	/**********************************************************
	 * 
	 * Element Classes
	 * For base wrapper
	 * 
	 **********************************************************/
	$atts['element_classes'] = array();
	
	global $pgscore_shortcodes;
	$pgscore_shortcodes[$shortcode_handle]['atts'] = $atts;
	$pgscore_shortcodes[$shortcode_handle]['icon_html'] = $icon_html;
	
	ob_start();
	?>
	<div <?php pgscore_shortcode_id( $atts );?> class="<?php pgscore_element_classes( $atts );?>"><!-- shortcode-base-wrapper -->
		<?php pgscore_get_shortcode_templates('features_text/content' );?>
	</div>
	<?php
	return ob_get_clean();
}

/******************************************************************************
 * 
 * Visual Composer Integration
 * 
 ******************************************************************************/
$shortcode_fields = array(
	array(
		'type'            => 'pgscore_radio_image',
		"heading"         => esc_html__("Style", 'pgs-core'),
		'param_name'      => 'style',
		'options'         => pgscore_get_shortcode_param_data('features_text'),
		'show_label'      => true,
		'admin_label'     => true,
	),
	array(
		"type"            => "textfield",
		"heading"         => esc_html__("Title", 'pgs-core'),
		"description"     => esc_html__("Enter title.", 'pgs-core'),
		"param_name"      => "title",
		'admin_label'     => true,
		'edit_field_class'=> 'vc_col-sm-9 vc_column',
	),
	array(
		"type"            => "dropdown",
		"class"           => "",
		"heading"         => esc_html__("Title Type", 'pgs-core'),    
		"param_name"      => "title_type",
		"std"             => "h3",
		'value'           => array_flip(array(
			'h2'  => esc_html__( 'H2', 'pgs-core' ),
			'h3'  => esc_html__( 'H3', 'pgs-core' ),
			'h4'  => esc_html__( 'H4', 'pgs-core' ),
			'h5'  => esc_html__( 'H5', 'pgs-core' ),
			'h6'  => esc_html__( 'H6', 'pgs-core' ),
		)),
		'edit_field_class'=> 'vc_col-sm-3 vc_column',
	),
	array(
		"type"        => "textfield",
		"heading"     => esc_html__("Description", 'pgs-core'),
		"description" => esc_html__("Enter description. Please ensure to add short content.", 'pgs-core'),
		"param_name"  => "description",
		'admin_label' => true,
	),
	array(
		'type'      => 'dropdown',
		'heading'   => esc_html__( 'Icon Size', 'pgs-core' ),
		'param_name'=> 'size',
		'value'     => array(
			esc_html__( 'Large', 'pgs-core' )       => 'large',
			esc_html__( 'Small', 'pgs-core' ) 	 	=> 'small',
			esc_html__( 'Extra Small', 'pgs-core' ) => 'ex-small',
		),
		'description' => esc_html__( 'Select size.', 'pgs-core' ),
		'admin_label' => true,
		'edit_field_class'=> 'vc_col-sm-4 vc_column',
	),
);

// Merge icon fields
$shortcode_fields = array_merge(
	$shortcode_fields,
	pgscore_iconpicker()
);

$shortcode_fields = apply_filters( 'pgscore_shortcode_fields-'.$shortcode_tag, $shortcode_fields, $shortcode_tag );

// Params
$params = array(
	"name"                    => esc_html__( "Feature Text", 'pgs-core' ),
	"description"             => esc_html__( "Display feature text box.", 'pgs-core'),
	"base"                   => $shortcode_tag,
	"class"                  => "pgscore_element_wrapper",
	"controls"               => "full",
	"icon"                   => pgscore_vc_shortcode_icon( $shortcode_tag ),
	"category"               => esc_html__('Potenza Core', 'pgs-core'),
	"show_settings_on_create"=> true,
	"params"                 => $shortcode_fields,
);
if ( function_exists( 'vc_map' ) ) {
	vc_map( $params );
}