<?php
/********************************************************************
 *
 * Front CSS and JS
 * 
 ********************************************************************/ 
add_action( 'wp_enqueue_scripts', 'pgscore_front_styles',5 );
function pgscore_front_styles( $hook ){
	wp_enqueue_style( 'pgscore-front', trailingslashit(PGSCORE_URL) . 'css/pgscore-front.css' );
	
	// Gravity Form - Font Awesome Fix
	if( class_exists('GFForms') ){
		wp_deregister_style( 'gform_font_awesome' );
		wp_register_style( 'gform_font_awesome', trailingslashit(PGSCORE_URL) . "css/font-awesome.min.css", null );
	}
}

add_action( 'wp_enqueue_scripts', 'pgscore_front_scripts' );
function pgscore_front_scripts( $hook ){
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	
	wp_register_script( 'pgscore-front', trailingslashit(PGSCORE_URL) . 'js/pgscore-front'.$suffix.'.js', array('jquery') );
	wp_enqueue_script( 'pgscore-front' );
}

/********************************************************************
 *
 * Admin CSS and JS
 * 
 ********************************************************************/ 
add_action( 'admin_enqueue_scripts', 'pgscore_admin_assets' );
function pgscore_admin_assets( $hook ){
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	
	/*
	 * Stylesheets
	 * */
	
	// Gravity Form - Font Awesome Fix
	if( class_exists('GFForms') ){
		wp_deregister_style( 'gform_font_awesome' );
		wp_register_style( 'gform_font_awesome', trailingslashit(PGSCORE_URL) . "css/font-awesome".$suffix.".css", null );
	}
	
	wp_enqueue_style( 'pgscore-vc-imagepicker'   , trailingslashit(PGSCORE_URL) . 'css/image-picker/image-picker'.$suffix.'.css' );
	wp_enqueue_style( 'jquery-confirm-bootstrap' , trailingslashit(PGSCORE_URL) . 'css/jquery-confirm/jquery-confirm-bootstrap'.$suffix.'.css' );
	wp_enqueue_style( 'jquery-confirm'           , trailingslashit(PGSCORE_URL) . 'css/jquery-confirm/jquery-confirm'.$suffix.'.css' );
	wp_enqueue_style( 'pgscore-admin'            , trailingslashit(PGSCORE_URL) . 'css/pgscore-admin'.$suffix.'.css' );
	
	if($hook == "post.php" || $hook == "post-new.php" || $hook == "edit.php"){
		wp_register_style( 'jquery-ui', trailingslashit(PGSCORE_URL) . 'css/jquery-ui/jquery-ui'.$suffix.'.css');
		wp_enqueue_style( 'pgscore-vc-admin', trailingslashit(PGSCORE_URL) . 'css/vc-admin'.$suffix.'.css', array('jquery-ui') );
	}
	
	/*
	 * Javascripts
	 * */
	wp_register_script( 'pgscore-vc-imagepicker', trailingslashit(PGSCORE_URL) . 'js/image-picker/image-picker'.$suffix.'.js', array('jquery'), false, true);
	wp_register_script( 'jquery-confirm'        , trailingslashit(PGSCORE_URL) . 'js/jquery-confirm/jquery-confirm'.$suffix.'.js', array('jquery') );
	wp_register_script( 'pgscore-admin'         , trailingslashit(PGSCORE_URL) . 'js/pgscore-admin'.$suffix.'.js', array('jquery') );
	
	if($hook == "post.php" || $hook == "post-new.php" || $hook == "edit.php"){
		wp_enqueue_script('pgscore-vc-imagepicker');
	}
	
	wp_enqueue_script( 'jquery-confirm' );
	wp_enqueue_script( 'pgscore-admin' );
}

// Fix FA Icons with Visual composer
add_action('init', 'pgscore_fix_vc_font_awesome', 11);
add_action('admin_init', 'pgscore_fix_vc_font_awesome', 11);
function pgscore_fix_vc_font_awesome(){
    wp_deregister_style( 'font-awesome' );
    wp_register_style( 'font-awesome', trailingslashit(PGSCORE_URL) . "css/font-awesome.min.css", null );
}