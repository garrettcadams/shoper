<?php
define( 'PGSCORE_VC_DIR', trailingslashit(PGSCORE_PATH) . 'includes/vc' );
define( 'PGSCORE_VC_URL', trailingslashit(PGSCORE_URL) . 'includes/vc' );

include( PGSCORE_VC_DIR.'/vc-fallback-functions.php' );

pgscore_vc_helpers_loader();
function pgscore_vc_helpers_loader(){
	$dir = PGSCORE_VC_DIR.'/vc_helpers/';
	
	$helpers = array(
		'pgscore_additional_icons',
		'pgscore_get_shortcode_param_data_helper',
		'vc_shortcode_icon',
		'pgscore_get_terms_helper',
		'pgscore_link_attr_helper',
		'element_classes',
	);
	
	foreach( $helpers as $helper ) {
		$helper_file = trailingslashit( $dir ) . $helper . '.php';
		if( file_exists($helper_file) ) include($helper_file);
	}
}

pgscore_vc_param_loader();
function pgscore_vc_param_loader(){
	$dir = PGSCORE_VC_DIR.'/vc_params/';
	
	$params = array(
		'faq_cats_param',
		'pgscore_datepicker_param',
		'pgscore_divider_param',
		'pgscore_dropdown_form_field',
		'pgscore_heading_param',
		'pgscore_html_param',
		'pgscore_notice_param',
		'pgscore_number_min_max_param',
		'pgscore_radio',
		'pgscore_radio_image_param',
		'pgscore_radio_image_param2',
		'range_slider',
	);
	
	foreach( $params as $param ) {
		$param_file = trailingslashit( $dir ) . $param . '.php';
		if( file_exists($param_file) ) include($param_file);
	}
}

add_action('init','pgscore_vc_fieldsets_loader',12);
function pgscore_vc_fieldsets_loader(){
	
	$dir = PGSCORE_VC_DIR.'/vc_fieldsets/';
	
	$fieldsets = array(
		'css_editor',
		'must_required',
		'iconpicker',
	);
	
	foreach( $fieldsets as $fieldset ) {
		$fieldset_file = trailingslashit( $dir ) . $fieldset . '.php';
		if( file_exists($fieldset_file) ) include($fieldset_file);
	}
}

add_filter( 'vc_custom_heading_template_use_wrapper', 'pgscore_helper_vc_custom_heading_template_use_wrapper' );
function pgscore_helper_vc_custom_heading_template_use_wrapper( $stat ){
	$stat = true;
	return $stat;
}

add_filter( 'vc_base_build_shortcodes_custom_css', 'pgscore_parseShortcodesCustomCss', 11, 2 );
function pgscore_parseShortcodesCustomCss( $content, $recur = false ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	$post_id = ( isset($_POST['post_ID']) ) ? $_POST['post_ID'] : 0;
	
	if( !$recur ){
		$post = get_post( $post_id );
		if( $post ){
			$content = $post->post_content;
		}else{
			$content = '';
		}
		$pgscore_parseShortcodesCustomCss_content[$post_id] = $content;
	}
	
	$css = '';
	if ( ! preg_match( '/\s*(\.[^\{]+)\s*\{\s*([^\}]+)\s*\}\s*/', $content ) ) {
		return $css;
	}
	WPBMap::addAllMappedShortcodes();
	preg_match_all( '/' . get_shortcode_regex() . '/', $content, $shortcodes );
	
	foreach ( $shortcodes[2] as $index => $tag ) {
		$shortcode = WPBMap::getShortCode( $tag );
		$attr_array = shortcode_parse_atts( trim( $shortcodes[3][ $index ] ) );
		
		if ( isset( $shortcode['params'] ) && ! empty( $shortcode['params'] ) ) {
			foreach ( $shortcode['params'] as $param ) {
				if ( isset( $param['type'] ) && 'css_editor' === $param['type'] && isset( $attr_array[ $param['param_name'] ] ) ) {
					if( $param['param_name'] == 'element_css_md' || $param['param_name'] == 'element_css_sm' || $param['param_name'] == 'element_css_xs' ){
						continue;
					}
					$css .= $attr_array[ $param['param_name'] ];
				}
			}
		}
		if( $tag == 'vc_row' && ( isset($attr_array['pgscore_enable_responsive_settings']) && $attr_array['pgscore_enable_responsive_settings'] == 'true' ) ){
			if( isset($attr_array['element_css_md']) && !empty($attr_array['element_css_md']) ){
				$css .= '@media (max-width: 1200px) {'.$attr_array['element_css_md'].'}';
			}
			if( isset($attr_array['element_css_sm']) && !empty($attr_array['element_css_sm']) ){
				$css .= '@media (max-width: 992px) {'.$attr_array['element_css_sm'].'}';
			}
			if( isset($attr_array['element_css_xs']) && !empty($attr_array['element_css_xs']) ){
				$css .= '@media (max-width: 767px) {'.$attr_array['element_css_xs'].'}';
			}
		}
	}
	foreach ( $shortcodes[5] as $shortcode_content ) {
		$css .= pgscore_parseShortcodesCustomCss( $shortcode_content, $recur = true );
	}
	
	return $css;
}