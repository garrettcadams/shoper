<?php
function pgscore_css_editor(){
	return array(
		array(
			'type'      => 'css_editor',
			'heading'   => esc_html__( 'CSS box', 'pgs-core' ),
			'param_name'=> 'element_css',
			'group'     => esc_html__( 'Design Options', 'pgs-core' ),
		),
	);
}