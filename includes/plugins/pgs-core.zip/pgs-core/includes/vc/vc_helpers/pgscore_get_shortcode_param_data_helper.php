<?php
function pgscore_get_shortcode_param_data($shortcode = ''){
	$options = array();
	if( empty($shortcode) ){
		return $options;
	}
	$images_dir = trailingslashit(PGSCORE_PATH).'images/vc_options/'.$shortcode.'/';
	$images_url = trailingslashit(PGSCORE_URL).'images/vc_options/'.$shortcode;
	
	if(is_dir($images_dir)) {
		$images = pgscore_get_file_list( 'png', $images_dir );
		
		if( !empty($images) ){
			foreach( $images as $image ) {
				$image_data = pathinfo($image);
				
				$option_name = $image_data['filename'];
				// $option_name = ucwords(str_replace(array("-","_"), " ", $option_name));
				$option_value = $images_url.'/'.$image_data['basename'];
				$options[ $option_name ] = $option_value;
			}
		}
	}
	return $options;
}