<?php
// Replace {$redux_opt_name} with your opt_name.
// Also be sure to change this function name!

if( !function_exists('pgscore_redux_extensions_loader') ):
	global $pgscore_globals;
	
	function pgscore_redux_extensions_loader($ReduxFramework) {
		$path    = realpath( trailingslashit(PGSCORE_PATH) . 'includes/redux/extensions/' );		
		if( file_exists($path) ){
			$folders = scandir( $path, 1 );
			foreach ( $folders as $folder ) {
				if ( $folder === '.' or $folder === '..' or ! is_dir( trailingslashit($path) . $folder ) ) {
					continue;
				}
				
				$extension_class = 'ReduxFramework_' . $folder;
				
				if ( ! class_exists( $extension_class ) ) {
					// In case you wanted override your override, hah.
					$class_file = trailingslashit($path) . $folder . '/field_' . $folder . '.php';
					if ( $class_file ) {
						require_once( $class_file );
					}
				}
			}
		}
	}
	// Modify {$redux_opt_name} to match your opt_name
	add_action("redux/extensions/{$pgscore_globals['option_opt_name']}/before", 'pgscore_redux_extensions_loader', 0);
endif;