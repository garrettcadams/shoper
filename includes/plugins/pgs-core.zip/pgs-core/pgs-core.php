<?php
/**
 * Plugin Name:       PGS Core
 * Plugin URI:        http://www.potenzaglobalsolutions.com/
 * Description:       This is core plugin for themes by Potenza Global Solutions.
 * Version:           2.1.0
 * Author:            Potenza Global Solutions
 * Author URI:        http://www.potenzaglobalsolutions.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       pgs-core
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'PGSCORE_PATH', plugin_dir_path( __FILE__ ) );
define( 'PGSCORE_URL', plugin_dir_url( __FILE__ ) );

global $pgscore_globals;
$pgscore_globals = array();

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-pgs-core-activator.php
 */
function pgscore_activate() {
	
	// Display admin notice if Visual Composer is not activated.
	add_action( 'admin_notices', 'pgscore_is_vc_active' );
	add_action( 'admin_notices', 'pgscore_plugin_active_notices' );
	
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-pgs-core-deactivator.php
 */
function pgscore_deactivate() {
	// TODO: Add settings for plugin deactivation
}

// Plugin activation/deactivation hooks
register_activation_hook( __FILE__, 'pgscore_activate' );
register_deactivation_hook( __FILE__, 'pgscore_deactivate' );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function pgscore_theme_functions_load_textdomain() {
	load_plugin_textdomain( 'pgs-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
add_action( 'plugins_loaded', 'pgscore_theme_functions_load_textdomain' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/init.php';