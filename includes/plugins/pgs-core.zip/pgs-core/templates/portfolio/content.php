<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_portfolio']);
extract($atts);