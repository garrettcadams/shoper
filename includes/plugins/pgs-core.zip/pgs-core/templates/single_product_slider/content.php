<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_single_product_slider']);
extract($atts);