<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_hotdeal']);
extract($atts);