<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_newsletter']);
extract($atts);