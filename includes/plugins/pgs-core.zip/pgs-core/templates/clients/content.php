<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_clients']);
extract($atts);