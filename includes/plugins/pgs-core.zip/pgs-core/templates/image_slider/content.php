<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_image_slider']);
extract($atts);