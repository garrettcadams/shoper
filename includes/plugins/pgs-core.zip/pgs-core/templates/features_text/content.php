<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_features_text']);
extract($atts);