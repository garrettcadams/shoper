<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_multi_tab_slider']);
extract($atts);