<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_recent_posts_dump']);
extract($atts);