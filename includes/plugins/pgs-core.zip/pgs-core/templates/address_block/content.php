<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_address_block']);
extract($atts);