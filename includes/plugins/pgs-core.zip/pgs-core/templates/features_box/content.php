<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_features_box']);
extract($atts);