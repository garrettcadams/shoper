<?php
global $pgscore_shortcodes;
extract($pgscore_shortcodes['pgscore_elements']);
extract($atts);